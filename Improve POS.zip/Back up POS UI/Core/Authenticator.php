<?php

namespace Core;

class Authenticator
{
    public function attempt($username, $password)
    {
        $user = App::resolve(Database::class)
            ->query('SELECT users.*, roles.is_admin, roles.access_backoffice, 
                    roles.manage_sales, roles.manage_inventory, roles.manage_users 
                    FROM users 
                    LEFT JOIN roles ON users.role_id = roles.id 
                    WHERE users.username = :username 
                    AND users.archived_at IS NULL', [
                ':username' => $username
            ])->find();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $this->login([
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'is_admin' => (bool) $user['is_admin'],
                    'permissions' => [
                        'backoffice' => (bool) $user['access_backoffice'],
                        'manage_sales' => (bool) $user['manage_sales'],
                        'manage_inventory' => (bool) $user['manage_inventory'],
                        'manage_users' => (bool) $user['manage_users']
                    ]
                ]);
                
                // Admin users still default to backoffice but can access POS
                if ($user['is_admin']) {
                    return '/backoffice';
                }
                
                // Record shift for non-admin and redirect to POS
                App::resolve(Database::class)->recordEmployeeShift($user['id'], 'in');
                return '/pos';
            }
        }
        
        return false;
    }

    public function login($user)
    {
        $_SESSION['user'] = [
            'user_id' => $user['user_id'],
            'username' => $user['username'],
            'is_admin' => $user['is_admin'],
            'permissions' => $user['permissions']
        ];
    }

    public function logout()
    {
        // Record shift end if not admin
        if (isset($_SESSION['user']) && !$_SESSION['user']['is_admin']) {
            App::resolve(Database::class)->recordEmployeeShift($_SESSION['user']['user_id'], 'out');
        }

        $_SESSION = [];
        session_destroy();

        $params = session_get_cookie_params();
        setcookie('PHPSESSID', '', time() - 3600, $params['path'], $params['domain']);
    }
}