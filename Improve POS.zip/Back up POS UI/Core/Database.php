<?php

namespace Core;

use PDO;
use PDOException;

class Database
{
    public $connection;
    protected $statement;

    public function __construct($config, $username = 'root', $password = '')
    {
        $dsn = 'mysql:' . http_build_query($config, '', ';');

        $this->connection = new PDO($dsn, $username, $password, [
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
    }

    public function query($query, $params = [])
    {
        $this->statement = $this->connection->prepare($query);

        $this->statement->execute($params);

        return $this;
    }

    public function find()
    {
        return $this->statement->fetch();
    }

    public function findAll()
    {
        return $this->statement->fetchAll();
    }

    public function lastInsertId()
    {
        return $this->connection->lastInsertId();
    }

    public function recordEmployeeShift($userId, $type = 'in')
    {
        try {
            // First get the employee details
            $employee = $this->query('SELECT * FROM employees WHERE user_id = :user_id AND archived_at IS NULL', [
                ':user_id' => $userId
            ])->find();

            if (!$employee) {
                return false;
            }

            $currentDate = date('Y-m-d');
            $currentTime = date('H:i:s');

            if ($type === 'in') {
                // Clock in - Create new shift record
                return $this->query('INSERT INTO employee_shifts (
                    employee_id,
                    shift_date,
                    clock_in_time
                ) VALUES (
                    :employee_id,
                    :shift_date,
                    :clock_in_time
                )', [
                    ':employee_id' => $employee['id'],
                    ':shift_date' => $currentDate,
                    ':clock_in_time' => $currentTime
                ]);
            } else {
                // Clock out - Update the latest shift record
                return $this->query('UPDATE employee_shifts 
                    SET clock_out_time = :clock_out_time 
                    WHERE employee_id = :employee_id 
                    AND shift_date = :shift_date 
                    AND clock_out_time IS NULL 
                    ORDER BY clock_in_time DESC 
                    LIMIT 1', [
                    ':employee_id' => $employee['id'],
                    ':shift_date' => $currentDate,
                    ':clock_out_time' => $currentTime
                ]);
            }
        } catch (PDOException $e) {
            // Log error or handle as needed
            return false;
        }
    }
}