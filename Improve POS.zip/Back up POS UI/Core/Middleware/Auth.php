<?php

namespace Core\Middleware;

class Auth
{
    public function handle()
    {
        // Check if user is logged in
        if (!$_SESSION['user'] ?? false) {   
            header('location: /login');
            exit();
        }

        // If user is admin, allow access to everything
        if ($_SESSION['user']['is_admin'] ?? false) {
            return; // Allow admin to access everything including POS
        }

        // Get current URL path and method
        $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $method = $_POST['_method'] ?? $_SERVER['REQUEST_METHOD'];

        // Allow logout from any page
        if (($currentPath === '/login' || $currentPath === '/') && $method === 'DELETE') {
            return;
        }

        // Allow access to POS, receipts, and checkout pages without additional checks
        if ($currentPath === '/pos' || 
            $currentPath === '/pos/receipts' || 
            str_starts_with($currentPath, '/pos/receipts/') ||
            $currentPath === '/pos/checkout' ||
            str_starts_with($currentPath, '/pos/process-checkout')) {
            return;
        }

        // Get user permissions
        $permissions = $_SESSION['user']['permissions'] ?? [];
        
        // Check if user has any of the required permissions
        $hasBackofficeAccess = $permissions['backoffice'] ?? false;
        $hasSalesAccess = $permissions['manage_sales'] ?? false;
        $hasInventoryAccess = $permissions['manage_inventory'] ?? false;
        $hasUsersAccess = $permissions['manage_users'] ?? false;

        // If none of the permissions are granted, redirect to POS
        if (!$hasBackofficeAccess && !$hasSalesAccess && 
            !$hasInventoryAccess && !$hasUsersAccess) {
            header('location: /pos');
            exit();
        }
    }
}