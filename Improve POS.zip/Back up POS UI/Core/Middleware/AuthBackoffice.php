<?php

namespace Core\Middleware;

class AuthBackoffice
{
    public function handle()
    {
        // If user is admin, allow access
        if ($_SESSION['user']['is_admin'] ?? false) {
            return;
        }

        // Get current URL path
        $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        // Get all permissions
        $permissions = $_SESSION['user']['permissions'] ?? [];
        $hasBackofficeOnly = ($permissions['backoffice'] ?? false) && 
            !($permissions['manage_sales'] ?? false) && 
            !($permissions['manage_inventory'] ?? false) && 
            !($permissions['manage_users'] ?? false);

        // If they only have backoffice access and trying to access dashboard, redirect to POS
        if ($hasBackofficeOnly && 
            ($currentPath === '/backoffice' || $currentPath === '/backoffice/dashboard')) {
            header('location: /pos');
            exit();
        }

        // Check basic backoffice access for other pages
        if (!isset($_SESSION['user']['permissions']['backoffice']) || 
            !$_SESSION['user']['permissions']['backoffice']) {
            $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            if ($currentPath !== '/pos') {
                header('location: /pos');
                exit();
            }
        }
    }
} 