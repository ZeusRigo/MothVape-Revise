<?php

namespace Core\Middleware;

class AuthSales
{
    public function handle()
    {
        // If user is admin, allow access
        if ($_SESSION['user']['is_admin'] ?? false) {
            return;
        }

        // Must have BOTH backoffice access AND sales permission
        $hasRequiredPermissions = 
            ($_SESSION['user']['permissions']['backoffice'] ?? false) && 
            ($_SESSION['user']['permissions']['manage_sales'] ?? false);

        if (!$hasRequiredPermissions) {
            $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            if ($currentPath !== '/pos') {
                header('location: /pos');
                exit();
            }
        }
    }
} 