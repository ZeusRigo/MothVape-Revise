<?php

namespace Core\Middleware;

class AuthUsers
{
    public function handle()
    {
        // If user is admin, allow access
        if ($_SESSION['user']['is_admin'] ?? false) {
            return;
        }

        // Must have BOTH backoffice access AND users permission
        $hasRequiredPermissions = 
            ($_SESSION['user']['permissions']['backoffice'] ?? false) && 
            ($_SESSION['user']['permissions']['manage_users'] ?? false);

        if (!$hasRequiredPermissions) {
            $currentPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            if ($currentPath !== '/pos') {
                header('location: /pos');
                exit();
            }
        }
    }
} 