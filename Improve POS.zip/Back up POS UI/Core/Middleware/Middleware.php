<?php

namespace Core\Middleware;

use Exception;

class Middleware
{
    const MAP = [
        'auth' => Auth::class,
        'guest' => Guest::class,
        'authBackoffice' => AuthBackoffice::class,
        'authSales' => AuthSales::class,
        'authInventory' => AuthInventory::class,
        'authUsers' => AuthUsers::class
    ];

    public static function resolve($key)
    {
        if (!$key) {
            return;
        }

        // Handle multiple middleware keys
        if (is_array($key)) {
            foreach ($key as $middleware) {
                static::resolveMiddleware($middleware);
            }
            return;
        }

        static::resolveMiddleware($key);
    }

    protected static function resolveMiddleware($key)
    {
        $middleware = static::MAP[$key] ?? false;

        if (!$middleware) {
            throw new Exception("No matching middleware found for key {$key}.");
        }
    
        (new $middleware)->handle();
    }
}