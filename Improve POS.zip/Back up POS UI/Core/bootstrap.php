<?php

$router->registerMiddleware('auth', new \Core\Middleware\Auth);
$router->registerMiddleware('authBackoffice', new \Core\Middleware\AuthBackoffice);
$router->registerMiddleware('authSales', new \Core\Middleware\AuthSales);
$router->registerMiddleware('authInventory', new \Core\Middleware\AuthInventory);
$router->registerMiddleware('authUsers', new \Core\Middleware\AuthUsers); 