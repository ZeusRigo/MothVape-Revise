<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

function dd($value)
{
    echo "<pre>";
    var_dump($value);
    echo "</pre>";
    
    die();
}

function urlIs($value)
{
    return $_SERVER['REQUEST_URI'] === $value;
}

function authorize($condition, $status = Response::FORBIDDEN)
{
    if (!$condition)
    {
        abort($status);
    }
}
function fetch_user_role()
{
    if (!isset($_SESSION['user']['role_id']))
    {
        return null;
    }

    $role = App::resolve(Database::class)
        ->query('SELECT * FROM roles WHERE id = :role_id AND archived_at IS NULL', [
            ':role_id' => $_SESSION['user']['role_id']
        ])->find();

    return $role;
}

function abort($code = 404, $error = 'An error has occurred!')
{
    http_response_code($code);

    view("{$code}.php", [
        'error' => $error
    ]);

    die();
}

function base_path($path)
{
    return BASE_PATH . $path;
}

function view($path, $attributes = [])
{
    extract($attributes);

    require base_path('Http/views/' . $path);
}

function redirect($path)
{
    header("location: {$path}");
    exit();
}

function old($key, $default = '')
{
    return Session::get('old')[$key] ?? $default;
}

function get_table_columns($array = []): array
{
    // Retrieve user preferences from session or database
    $userSelectedColumns = $_SESSION['selected_columns'] ?? array_keys($array);

    // Filter only the selected columns
    return array_filter($array, function ($key) use ($userSelectedColumns) {
        return in_array($key, $userSelectedColumns);
    }, ARRAY_FILTER_USE_KEY);
}

function upload_image($form)
{
    if (isset($_FILES['image-url']) && $_FILES['image-url']['error'] === UPLOAD_ERR_OK)
    {
        $uploadDir = base_path('public/uploads/');
        $fileTmpPath = $_FILES['image-url']['tmp_name'];
        $fileName = $_FILES['image-url']['name'];
        $fileSize = $_FILES['image-url']['size'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // Allowed file extensions
        $allowedExtensions = ['jpeg', 'jpg', 'png', 'webp'];

        // Check file extension
        if (!in_array($fileExt, $allowedExtensions)) 
        {
            $form->error(
                'image-url', 
                'Invalid file type. Only JPEG, JPG, PNG, and WEBP are allowed.'
            )->throw();
        }

        // Check file size (optional: 2MB max)
        if ($fileSize > 2 * 1024 * 1024) 
        { 
            $form->error(
                'image-url', 
                'File size exceeds 2MB.'
            )->throw();
        }

        // Unique file name to prevent overwrites
        $newFileName = uniqid('img_', true) . '.' . $fileExt;
        $destination = $uploadDir . $newFileName;

        if (move_uploaded_file($fileTmpPath, $destination)) 
        {
            // Store image path in database if needed
            return 'public/uploads/' . $newFileName;
        } 
        else 
        {
            $form->error(
                'image-url', 
                'Failed to upload the image.'
            )->throw();
        }
    } 
    else 
    {
        $form->error(
            'image-url', 
            'Please select an image to upload.'
        )->throw();
    }

    return false;
}