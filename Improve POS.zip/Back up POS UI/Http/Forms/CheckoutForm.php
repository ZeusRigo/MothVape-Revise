<?php

namespace Http\Forms;

use Core\ValidationException;

class CheckoutForm
{
    protected $errors = [];

    public function __construct(public array $attributes)
    {
        if (empty($attributes['order_items'])) {
            $this->errors['order_items'] = 'No items in order';
        }

        if (empty($attributes['payment_method'])) {
            $this->errors['payment_method'] = 'Payment method is required';
        }

        if (!isset($attributes['payment_amount']) || !is_numeric($attributes['payment_amount'])) {
            $this->errors['payment_amount'] = 'Invalid payment amount';
        }

        if (!isset($attributes['total_amount']) || !is_numeric($attributes['total_amount'])) {
            $this->errors['total_amount'] = 'Invalid total amount';
        }

        if (isset($attributes['payment_amount']) && isset($attributes['total_amount'])) {
            if ($attributes['payment_amount'] < $attributes['total_amount']) {
                $this->errors['payment_amount'] = 'Payment amount must be greater than or equal to the total amount';
            }
        }
    }

    public static function validate($attributes)
    {
        $instance = new static($attributes);

        return $instance->failed() ? $instance->throw() : $instance;
    }

    public function throw()
    {
        ValidationException::throw($this->errors(), $this->attributes);
    }

    public function failed()
    {
        return count($this->errors);
    }

    public function errors()
    {
        return $this->errors;
    }

    public function error($field, $message)
    {
        $this->errors[$field] = $message;

        return $this;
    }
} 