<?php

namespace Http\Forms;

use Core\ValidationException;
use Core\Validator;

class EmployeesForm
{
    protected $errors = [];

    public function __construct(public array $attributes)
    {
        if (!Validator::string($attributes['first-name'], 1, 50))
        {
            $this->errors['first-name'] = 'First name must be between 1 and 50 characters and cannot be empty.';
        }

        // if (!isset($attributes['middle-name']) && !Validator::string($attributes['middle-name'], 1, 50))
        // {
        //     $this->errors['middle-name'] = 'Middle name must be between 1 and 50 characters.';
        // }

        if (!Validator::string($attributes['last-name'], 1, 50))
        {
            $this->errors['last-name'] = 'Last name must be between 1 and 50 characters and cannot be empty.';
        }

        if (!isset($attributes['email']) && !Validator::email($attributes['email']))
        {
            $this->errors['email'] = 'Please provide a valid email address.';
        }

        // if (!isset($attributes['phone-number']) && !Validator::string($attributes['phone-number'], 7, 20))
        // {
        //     $this->errors['phone-number'] = 'Please enter a valid phone number (7-20 digits, numbers only).';
        // }

        // if (!isset($attributes['street-address-line1']) && !Validator::string($attributes['street-address-line1'], 1, 255))
        // {
        //     $this->errors['street-address-line1'] = 'Please provide a valid first street address line.';
        // }

        // if (!isset($attributes['street-address-line2']) && !Validator::string($attributes['street-address-line2'], 1, 255))
        // {
        //     $this->errors['street-address-line2'] = 'Please provide a valid second street address line.';
        // }

        // if (!isset($attributes['city']) && !Validator::string($attributes['city'], 1, 100))
        // {
        //     $this->errors['city'] = 'City must be between 1 and 100 characters.';
        // }

        // if (!isset($attributes['state']) && !Validator::string($attributes['state'], 1, 100))
        // {
        //     $this->errors['state'] = 'State must be between 1 and 100 characters.';
        // }

        // if (!isset($attributes['postal-code']) && !Validator::string($attributes['postal-code'], 1, 20))
        // {
        //     $this->errors['postal-code'] = 'Postal code must be between 1 and 20 characters.';
        // }

        // if (!isset($attributes['country']) && !Validator::string($attributes['country'], 1, 100))
        // {
        //     $this->errors['country'] = 'Country must be between 1 and 100 characters.';
        // }

        if (empty($attributes['role-id']))
        {
            $this->errors['role-id'] = 'Please select a role.';
        }

        if (!Validator::string($attributes['username'], 1, 50))
        {
            $this->errors['username'] = 'Username must be between 1 and 50 characters and cannot be empty.';
        }

        if (!Validator::string($attributes['password'], 7, 255))
        {
            $this->errors['password'] = 'Password must be between 8 and 255 characters and cannot be empty.';
        }

        if ($attributes['verify-password'] !== $attributes['password'])
        {
            $this->errors['verify-password'] = 'Password does not match!';
        }
    }

    public static function validate($attributes)
    {
        $instance = new static($attributes);

        return $instance->failed() ? $instance->throw() : $instance;
    }

    public function throw()
    {
        ValidationException::throw($this->errors(), $this->attributes);
    }

    public function failed()
    {
        return count($this->errors);
    }

    public function errors()
    {
        return $this->errors;
    }

    public function error($field, $message)
    {
        $this->errors[$field] = $message;

        return $this;
    }
}