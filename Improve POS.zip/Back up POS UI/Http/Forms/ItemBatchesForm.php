<?php

namespace Http\Forms;

use Core\App;
use Core\Database;
use Core\ValidationException;
use Core\Validator;

class ItemBatchesForm
{
    protected $errors = [];

    public function __construct(public array $attributes)
    {
        // Check if another batch number already exists
        $result = App::resolve(Database::class)
            ->query('SELECT COUNT(*) FROM item_batches WHERE id != :id AND batch_number = :batch_number', 
            [
                ':id' => $attributes['id'],
                ':batch_number' => trim($attributes['batch-number'])
            ]
        )->find();

        if ($result['COUNT(*)'] > 0)
        {
            $this->errors['batch-number'] = 'Batch number already exists! Please create another.';
        }
    }

    public static function validate($attributes)
    {
        $instance = new static($attributes);

        return $instance->failed() ? $instance->throw() : $instance;
    }

    public function throw()
    {
        ValidationException::throw($this->errors(), $this->attributes);
    }

    public function failed()
    {
        return count($this->errors);
    }

    public function errors()
    {
        return $this->errors;
    }

    public function error($field, $message)
    {
        $this->errors[$field] = $message;

        return $this;
    }
}