<?php

use Core\Session;

view("auth/create.view.php", [
    'title' => 'Moth Vape | Login',
    'errors' => Session::get('errors')
]);