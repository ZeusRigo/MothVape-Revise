<?php

use Core\Authenticator;
use Http\Forms\LoginForm;

$form = LoginForm::validate($attributes = [
    'username' => $_POST['username'],
    'password' => $_POST['password']
]);

$auth = new Authenticator();
$redirect = $auth->attempt($attributes['username'], $attributes['password']);

if (!$redirect) {
    $form->error('username', 'No matching account found for that username and password.')->throw();
}

redirect($redirect);