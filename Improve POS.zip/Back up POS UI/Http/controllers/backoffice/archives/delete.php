<?php

use Core\App;
use Core\Database;
use Core\Response;

function delete($tableName, $ids) 
{
    foreach ($ids as $id) 
    {
        $result = App::resolve(Database::class)
            ->query('DELETE FROM ' . $tableName . ' WHERE id = :id', 
            [
                ':id' => $id
            ]);   

        if (!$result) 
        {
            return false;
        }
    }

    return true;
}

if (!isset($_POST['row-id'])) 
{
    redirect($_POST['home-uri']);
}

$ids = explode(',', $_POST['row-id']);

try 
{
    $result = delete($_POST['table-name'], $ids);
    
    if ($result) 
    {
        redirect($_POST['home-uri']);
    } 
    else 
    {
        abort(Response::INTERNAL_SERVER_ERROR);
    }
} 
catch (PDOException $exception) 
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception);
}

abort(Response::INTERNAL_SERVER_ERROR);