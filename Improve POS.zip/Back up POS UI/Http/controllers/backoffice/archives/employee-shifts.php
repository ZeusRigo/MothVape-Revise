<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                a.*,
                DATE_FORMAT(a.clock_in_time, "%h:%i:%s %p") AS formatted_clock_in_time,
                DATE_FORMAT(a.clock_out_time, "%h:%i:%s %p") AS formatted_clock_out_time,
                CONCAT(b.first_name, " ", b.middle_name, " ", b.last_name) AS full_name
            FROM employee_shifts AS a
            LEFT JOIN employees AS b ON a.employee_id = b.id
            WHERE a.archived_at IS NOT NULL
            ORDER BY a.archived_at DESC',
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/archives/index.view.php", [
    'title' => 'Moth Vape | Back Office - Archives (Employee Shifts)',
    'pageHeading' => 'Archived Employee Shifts',
    'homeURI' => '/backoffice/archives/employee-shifts',
    'result' => $result,
    'tableColumns' => get_table_columns(
        [
            'full_name' => 'Employee',
            'shift_date' => 'Shift Date',
            'formatted_clock_in_time' => 'Clock-in Time',
            'formatted_clock_out_time' => 'Clock-out Time'
        ]
    ),
    'tableName' => 'employee_shifts'
]);