<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                employees.id,
                CONCAT(employees.first_name, " ", IFNULL(employees.middle_name, ""), " ", employees.last_name) AS full_name,
                users.username,
                employees.archived_at
            FROM employees
            LEFT JOIN users ON employees.user_id = users.id
            WHERE employees.archived_at IS NOT NULL
                AND (
                    :searchTerm = ""
                    OR CONCAT(employees.first_name, " ", IFNULL(employees.middle_name, ""), " ", employees.last_name) LIKE :searchTerm
                    OR users.username LIKE :searchTerm
                )
            ORDER BY employees.archived_at DESC
        ', [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

// Define table columns for the view
$tableColumns = [
    'full_name' => 'Name',
    'username' => 'Username'
];

view("backoffice/archives/index.view.php", [
    'title' => 'Moth Vape | Back Office - Archives (Employees)',
    'pageHeading' => 'Archived Employees',
    'homeURI' => '/backoffice/archives/employees',
    'result' => $result,
    'tableName' => 'employees',
    'tableColumns' => $tableColumns,
    'searchTerm' => $originalSearchTerm
]);