<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                a.id,
                a.batch_number,
                a.archived_at,
                b.name AS item_name
            FROM item_batches AS a
            LEFT JOIN items AS b ON a.item_id = b.id
            WHERE a.archived_at IS NOT NULL
            ORDER BY a.archived_at DESC',
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/archives/index.view.php", [
    'title' => 'Moth Vape | Back Office - Archives (Item Batches)',
    'pageHeading' => 'Archived Item Batches',
    'homeURI' => '/backoffice/archives/item-batches',
    'result' => $result,
    'tableColumns' => get_table_columns(
        [
            'item_name' => 'Item',
            'batch_number' => 'Batch Number'
        ]
    ),
    'tableName' => 'item_batches'
]);