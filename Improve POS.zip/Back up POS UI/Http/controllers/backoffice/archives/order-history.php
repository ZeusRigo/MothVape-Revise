<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $result = App::resolve(Database::class)
        ->query('
            SELECT *
            FROM order_receipts AS a
            WHERE archived_at IS NOT NULL
            ORDER BY archived_at DESC',
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/archives/index.view.php", [
    'title' => 'Moth Vape | Back Office - Archives (Order History)',
    'pageHeading' => 'Archived Order History',
    'homeURI' => '/backoffice/archives/order-history',
    'result' => $result,
    'tableColumns' => get_table_columns(
        [
            'reference_number' => 'Reference Number',
            'customer_name' => 'Customer Name',
            'employee_name' => 'Cashier',
            'total_price' => 'Total Price'
        ]
    ),
    'tableName' => 'order_receipts'
]);