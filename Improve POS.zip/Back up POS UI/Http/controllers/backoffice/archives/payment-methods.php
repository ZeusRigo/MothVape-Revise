<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $result = App::resolve(Database::class)
        ->query('
            SELECT *
            FROM payment_methods AS a
            WHERE archived_at IS NOT NULL
            ORDER BY archived_at DESC',
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/archives/index.view.php", [
    'title' => 'Moth Vape | Back Office - Archives (Payment Methods)',
    'pageHeading' => 'Archived Payment Methods',
    'homeURI' => '/backoffice/archives/payment-methods',
    'result' => $result,
    'tableColumns' => get_table_columns(
        [
            'name' => 'Name'
        ]
    ),
    'tableName' => 'payment_methods'
]);