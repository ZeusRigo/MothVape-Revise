<?php

use Core\App;
use Core\Database;
use Core\Response;

if (!isset($_POST['row-id'])) {
    abort(Response::BAD_REQUEST);
}

$ids = $_POST['row-id'];
$table = $_POST['table-name'];

try 
{
    $db = App::resolve(Database::class);
    
    // Start transaction
    $db->connection->beginTransaction();

    // Restore the selected items
    $result = $db->query("UPDATE {$table} SET archived_at = NULL WHERE id IN ({$ids})")->find();

    // If restoring employees, also restore their user accounts
    if ($table === 'employees') {
        // Get user IDs associated with these employees
        $employees = $db->query("SELECT user_id FROM employees WHERE id IN ({$ids})")->findAll();
        
        // Restore associated user accounts
        foreach ($employees as $employee) {
            if ($employee['user_id']) {
                $db->query("UPDATE users SET archived_at = NULL WHERE id = :user_id", [
                    ':user_id' => $employee['user_id']
                ]);
            }
        }
    }

    // Commit transaction
    $db->connection->commit();

    // Return success response
    http_response_code(Response::NO_CONTENT);
    exit();
}
catch (PDOException $exception)
{
    // Rollback on error
    if (isset($db)) {
        $db->connection->rollBack();
    }
    
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}