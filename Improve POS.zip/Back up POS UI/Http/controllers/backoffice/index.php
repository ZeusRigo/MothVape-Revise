<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $db = App::resolve(Database::class);

    // Get total number of sales (orders)
    $result_orderReceipts = $db->query(
        'SELECT 
            COUNT(*) AS total_sales,
            SUM(total_price) AS total_revenue 
        FROM order_receipts 
        WHERE archived_at IS NULL'
    )->find();

    $totalSales = $result_orderReceipts['total_sales'] ?? 0;
    $totalRevenue = $result_orderReceipts['total_revenue'] ?? 0;

    // Get total number of items
    $result_items = $db->query(
        'SELECT COUNT(*) AS total_items 
        FROM items 
        WHERE archived_at IS NULL'
    )->find();

    $totalItems = $result_items['total_items'] ?? 0;

    // Get user information
    $user = null;
    $sessionUser = Session::get('user');
    if ($sessionUser && isset($sessionUser['user_id'])) {
        $user = $db->query(
            'SELECT first_name, last_name 
            FROM employees 
            WHERE user_id = :user_id 
            AND archived_at IS NULL', 
            [':user_id' => $sessionUser['user_id']]
        )->find();
    }
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/index.view.php", [
    'title' => 'Moth Vape | Back Office - Dashboard',
    'pageHeading' => 'Dashboard',
    'totalSales' => $totalSales,
    'totalRevenue' => $totalRevenue,
    'totalItems' => $totalItems,
    'user' => $user
]);