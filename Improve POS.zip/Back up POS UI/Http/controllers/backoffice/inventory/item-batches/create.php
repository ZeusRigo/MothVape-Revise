<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result_items = App::resolve(Database::class)
        ->query('
            SELECT 
                i.id, 
                i.sku, 
                i.name, 
                c.name AS category_name 
            FROM items i 
            LEFT JOIN item_categories c ON i.category_id = c.id 
            WHERE i.archived_at IS NULL
                AND (
                    :searchTerm = ""
                    OR i.sku LIKE :searchTerm
                    OR i.name LIKE :searchTerm
                    OR c.name LIKE :searchTerm
                )
            ORDER BY i.name ASC',
            [
                ':searchTerm' => $searchTerm
            ]
        )->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/inventory/item-batches/create.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Add Item Batch)',
    'pageHeading' => 'Add Item Batch',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/item-batches',
    'result_items' => $result_items,
    'searchTerm' => $originalSearchTerm
]);