 <?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result = App::resolve(Database::class)
        ->query('
        SELECT 
            *,
            DATE_FORMAT(expiration_date, "%m-%d-%Y") AS formatted_expiration_date
        FROM item_batches 
        WHERE id = :id AND archived_at IS NULL',
        [
            ':id' => $_GET['id']
        ])->find();

    $result_items = App::resolve(Database::class)
        ->query('SELECT id, sku, name FROM items WHERE archived_at IS NULL ORDER BY name ASC')->findAll();
    
    $result_suppliers = App::resolve(Database::class)
        ->query('SELECT id, name FROM suppliers WHERE archived_at IS NULL ORDER BY name ASC')->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/inventory/item-batches/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Edit Item Batch)',
    'pageHeading' => 'Edit Item Batch',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/item-batches',
    'result' => $result,
    'result_items' => $result_items,
    'result_suppliers' => $result_suppliers
]);