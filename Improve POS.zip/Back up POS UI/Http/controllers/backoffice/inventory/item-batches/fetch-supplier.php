<?php

header('Content-Type: application/json');

use Core\App;
use Core\Database;

$result = App::resolve(Database::class)
    ->query('SELECT id, name FROM suppliers WHERE archived_at IS NULL ORDER BY name ASC', [])->findAll();

if ($result) 
{
    $suppliers = [];
    foreach ($result as $row) 
    {
        $suppliers[] = $row;
    }

    echo json_encode($suppliers);
} 
else 
{
    echo json_encode([]);
}