<?php

use Core\App;
use Core\Database;

function generate_batch_number() : void
{
    $batchNumber = create_batch_number();
    
    // Return the generated SKU in JSON format
    echo json_encode(['batch_number' => $batchNumber]);
}

function create_batch_number(): string
{
    do 
    {
        $year = date("Y");
        $monthDay = date("md");
        $random = strtoupper(bin2hex(random_bytes(2)));
        
        $batchNumber = "{$year}-{$monthDay}-B{$random}";

        $result = App::resolve(Database::class)->query('SELECT COUNT(*) FROM item_batches WHERE batch_number = :batch_number', ['batch_number' => $batchNumber])->find();
    } 
    while ($result['COUNT(*)'] > 0);

    return $batchNumber;
}

generate_batch_number();