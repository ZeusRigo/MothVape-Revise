<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                a.*,
                b.sku,
                b.name AS item_name,
                b.low_stock_quantity,
                c.name AS supplier_name
                FROM item_batches AS a
                LEFT JOIN items AS b ON a.item_id = b.id
                LEFT JOIN suppliers AS c ON a.supplier_id = c.id
                WHERE a.archived_at IS NULL
                    AND 
                    (
                        :searchTerm = ""
                        OR b.sku LIKE :searchTerm
                        OR b.name LIKE :searchTerm
                        OR a.batch_number LIKE :searchTerm
                        OR c.name LIKE :searchTerm
                    )
                ORDER BY a.modified_at DESC',
        [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/inventory/item-batches/index.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Item Batches)',
    'pageHeading' => 'Item Batches',
    'homeURI' => '/backoffice/inventory/item-batches',
    'result' => $result,
    'tableName' => 'item_batches',
    'searchTerm' => $originalSearchTerm
]);