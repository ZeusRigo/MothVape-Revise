<?php

use Core\App;
use Core\Database;
use Core\Response;

$batchedItems = json_decode($_POST['batched-items'], true);

function get_batch_sku($itemSKU, $supplierId)
{
    $query = "SELECT supplier_code FROM suppliers WHERE id = :supplier_id";
    $result = App::resolve(Database::class)
        ->query($query, [
            ':supplier_id' => $supplierId
        ])->find();

    if (!$result)
    {
        return $itemSKU;
    }

    $batchSku = $itemSKU . '-' . $result['supplier_code'];

    return $batchSku;
}

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    foreach ($batchedItems as $item)
    {
        App::resolve(Database::class)
            ->query('INSERT INTO item_batches
                (
                    item_id,
                    batch_sku,
                    batch_number,
                    quantity,
                    expiration_date,
                    supplier_id,
                    created_at,
                    modified_at
                )
                VALUES
                (
                    :item_id,
                    :batch_sku,
                    :batch_number,
                    :quantity,
                    :expiration_date,
                    :supplier_id,
                    :created_at,
                    :modified_at
                )',
                [
                    ':item_id' => $item['item_id'],
                    ':batch_sku' => get_batch_sku($item['sku'], $item['supplier_id']),
                    ':batch_number' => $item['batch_number'],
                    ':quantity' => isset($item['quantity']) && is_numeric($item['quantity']) ? (int) $item['quantity'] : null,
                    ':expiration_date' => !empty($item['expiration_date']) ? $item['expiration_date'] : null,
                    ':supplier_id' => isset($item['supplier_id']) && is_numeric($item['supplier_id']) ? (int) $item['supplier_id'] : null,
                    ':created_at' => $formattedDateTime,
                    ':modified_at' => $formattedDateTime
                ]
            );
    }
} 
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

redirect('/backoffice/inventory/item-batches');