<?php

use Core\App;
use Core\Database;
use Http\Forms\ItemBatchesForm;
use DateTime;
use DateTimeZone;

$form = ItemBatchesForm::validate($attributes = [
    'id' => $_POST['id'],
    'item-id' => $_POST['item-id'],
    'batch-number' => $_POST['batch-number'],
    'quantity' => $_POST['quantity'],
    'expiration-date' => $_POST['expiration-date'],
    'supplier-id' => $_POST['supplier-id']
]);

function get_batch_sku($itemSKU, $supplierId)
{
    $query = "SELECT supplier_code FROM suppliers WHERE id = :supplier_id";
    $result = App::resolve(Database::class)
        ->query($query, [
            ':supplier_id' => $supplierId
        ])->find();

    if (!$result)
    {
        return $itemSKU;
    }

    $batchSku = $itemSKU . '-' . $result['supplier_code'];

    return $batchSku;
}

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    // Fetch item SKU
    $query = "SELECT sku FROM items WHERE id = :item_id";
    $result_item = App::resolve(Database::class)
        ->query($query, [
            ':item_id' => $_POST['item-id']
        ])->find();

    $result = App::resolve(Database::class)
        ->query('UPDATE item_batches 
        SET 
            item_id = :item_id,
            batch_sku = :batch_sku,
            batch_number = :batch_number,
            quantity = :quantity,
            expiration_date = :expiration_date,
            supplier_id = :supplier_id,
            modified_at = :modified_at
        WHERE id = :id', 
        [
            ':id' => $_POST['id'],
            ':item_id' => $_POST['item-id'],
            ':batch_sku' => get_batch_sku($result_item['sku'], $_POST['supplier-id']),
            ':batch_number' => $_POST['batch-number'],
            ':quantity' => isset($_POST['quantity']) && is_numeric($_POST['quantity']) ? (int) $_POST['quantity'] : null,
            ':expiration_date' => !empty($_POST['expiration-date']) ? $_POST['expiration-date'] : null,
            ':supplier_id' => isset($_POST['supplier-id']) && is_numeric($_POST['supplier-id']) ? (int) $_POST['supplier-id'] : null,
            ':modified_at' => $formattedDateTime
        ]
    );
}
catch (PDOException $exception)
{
    $form->error(
        'form', 
        $exception->getMessage()
    )->throw();
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/inventory/item-batches');