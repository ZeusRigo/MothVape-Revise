<?php

use Core\Session;

view("backoffice/inventory/item-categories/create.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Add Item Category)',
    'pageHeading' => 'Add Item Category',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/item-categories'
]);