<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result = App::resolve(Database::class)
        ->query('SELECT * FROM item_categories WHERE id = :id AND archived_at IS NULL', [
        ':id' => $_GET['id']
    ])->find();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/inventory/item-categories/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Edit Item Categories)',
    'pageHeading' => 'Edit Item Categories',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/item-categories',
    'result' => $result
]);