<?php

use Core\App;
use Core\Database;
use Http\Forms\ItemCategoriesForm;
use DateTime;
use DateTimeZone;

$form = ItemCategoriesForm::validate($attributes = [
    'name' => $_POST['name']
]);

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    $result = App::resolve(Database::class)
        ->query('UPDATE item_categories SET name = :name, modified_at = :modified_at WHERE id = :id', [
        ':id' => $_POST['id'],
        ':name' => $_POST['name'],
        ':modified_at' => $formattedDateTime
    ]);
}
catch (PDOException $exception)
{
    $form->error(
        'form', 
        $exception->getMessage()
    )->throw();
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/inventory/item-categories');