<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result_itemCategories = App::resolve(Database::class)
        ->query('SELECT id, name FROM item_categories WHERE archived_at IS NULL', 
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/inventory/items/create.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Add Items)',
    'pageHeading' => 'Add Items',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/items',
    'result_itemCategories' => $result_itemCategories
]);