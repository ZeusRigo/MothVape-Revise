<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result = App::resolve(Database::class)
        ->query('SELECT * FROM items WHERE id = :id AND archived_at IS NULL', [
        ':id' => $_GET['id']
    ])->find();
    
    $result_itemCategories = App::resolve(Database::class)
        ->query('SELECT id, name FROM item_categories WHERE archived_at IS NULL ORDER BY name ASC', 
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/inventory/items/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Edit Items)',
    'pageHeading' => 'Edit Items',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/items',
    'result' => $result,
    'result_itemCategories' => $result_itemCategories
]);