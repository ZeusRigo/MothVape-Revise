<?php

use Core\App;
use Core\Database;

function auto_generate_sku() : void
{
    $sku = createUniqueSKU();
    
    // Return the generated SKU in JSON format
    echo json_encode(['sku' => $sku]);
}

function createUniqueSKU(): string
{
    do 
    {
        // Define SKU components
        $prefix = "MOTH";
        $yearMonth = date("Ym"); // Example: '202401' for Jan 2024
        $random = strtoupper(bin2hex(random_bytes(2))); // 4-character unique ID
        
        // Combine to generate SKU
        $sku = "{$prefix}-{$yearMonth}-{$random}";

        // Check if SKU already exists in the database
        $result = App::resolve(Database::class)->query('SELECT COUNT(*) FROM items WHERE sku = :sku', ['sku' => $sku])->find();
    } 
    while ($result['COUNT(*)'] > 0);  // If the SKU exists, regenerate

    return $sku;
}

auto_generate_sku();