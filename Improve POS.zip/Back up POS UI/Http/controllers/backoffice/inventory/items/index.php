<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                a.id, 
                a.sku, 
                a.name AS item_name,
                a.price,
                a.low_stock_quantity,
                a.created_at,
                a.modified_at,
                b.name AS category_name
            FROM items AS a
            LEFT JOIN item_categories AS b ON a.category_id = b.id
            WHERE a.archived_at IS NULL
                AND 
                (
                    :searchTerm = "" 
                    OR a.sku LIKE :searchTerm
                    OR a.name LIKE :searchTerm
                    OR b.name LIKE :searchTerm
                )
            ORDER BY a.modified_at DESC',
    [
        ':searchTerm' => $searchTerm
    ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/inventory/items/index.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Items)',
    'pageHeading' => 'Items',
    'homeURI' => '/backoffice/inventory/items',
    'result' => $result,
    'tableName' => 'items',
    'searchTerm' => $originalSearchTerm
]);