<?php

use Core\App;
use Core\Database;
use Http\Forms\ItemsForm;
use DateTime;
use DateTimeZone;

$form = ItemsForm::validate($attributes = [
    'sku' => $_POST['sku'],
    'name' => $_POST['name'],
    'description' => $_POST['description'],
    'category-id' => $_POST['category-id'],
    'price' => $_POST['price'],
    'low-stock-quantity' => $_POST['low-stock-quantity']
]);

// File uploading handling
if (!empty($_FILES['image-url']['name']))
{
    $imagePath = upload_image($form);
}

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    $result = App::resolve(Database::class)
        ->query('INSERT INTO items
        (
            sku,
            name,
            description,
            category_id,
            price,
            image_url,
            low_stock_quantity,
            created_at,
            modified_at
        ) 
        VALUES
        (
            :sku,
            :name,
            :description,
            :category_id,
            :price,
            :image_url,
            :low_stock_quantity,
            :created_at,
            :modified_at
        )', 
        [
            ':sku' => trim($_POST['sku']),
            ':name' => $_POST['name'],
            ':description' => $_POST['description'] ?? null,
            ':category_id' => isset($_POST['category-id']) && is_numeric($_POST['category-id']) ? (int) $_POST['category-id'] : null,
            ':price' => isset($_POST['price']) ? (double) $_POST['price'] : null,
            ':image_url' => $imagePath ?? null,
            ':low_stock_quantity' => isset($_POST['low-stock-quantity']) ? (int) $_POST['low-stock-quantity'] : null,
            ':created_at' => $formattedDateTime,
            ':modified_at' => $formattedDateTime
        ]
    );
}
catch (PDOException $exception)
{
    $form->error(
        'form', 
        $exception->getMessage()
    )->throw();
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/inventory/items');