<?php

use Core\Session;

view("backoffice/inventory/suppliers/create.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Add Supplier)',
    'pageHeading' => 'Add Supplier',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/suppliers'
]);