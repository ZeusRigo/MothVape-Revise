<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT
                id,
                name,
                email,
                phone_number,
                created_at,
                modified_at
            FROM suppliers
            WHERE archived_at IS NULL
                AND 
                (
                    :searchTerm = "" 
                    OR name LIKE :searchTerm
                    OR email LIKE :searchTerm
                    OR phone_number LIKE :searchTerm
                )
            ORDER BY modified_at DESC',
    [
        ':searchTerm' => $searchTerm
    ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/inventory/suppliers/index.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Suppliers)',
    'pageHeading' => 'Suppliers',
    'homeURI' => '/backoffice/inventory/suppliers',
    'result' => $result,
    'tableName' => 'suppliers',
    'searchTerm' => $originalSearchTerm
]);