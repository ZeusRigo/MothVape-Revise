<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try 
{
    $result = App::resolve(Database::class)
        ->query('SELECT * FROM suppliers WHERE id = :id', [
            ':id' => $_GET['id']
    ])->find();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/inventory/suppliers/show.view.php", [
    'title' => 'Moth Vape | Back Office - Inventory (Supplier View: #)',
    'pageHeading' => 'View Supplier: #',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/inventory/suppliers',
    'result' => $result
]);