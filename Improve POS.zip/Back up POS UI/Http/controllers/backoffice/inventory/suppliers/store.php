<?php

use Core\App;
use Core\Database;
use Http\Forms\SuppliersForm;
use DateTime;
use DateTimeZone;

$form = SuppliersForm::validate($attributes = [
    'name' => $_POST['name'],
    'email' => $_POST['email'],
    'phone-number' => $_POST['phone-number'],
    'street-address-line1' => $_POST['street-address-line1'],
    'street-address-line2' => $_POST['street-address-line2'],
    'city' => $_POST['city'],
    'state' => $_POST['state'],
    'postal-code' => $_POST['postal-code'],
    'country' => $_POST['country'],
    'notes' => $_POST['notes']
]);

function get_supplier_code($name) 
{
    $base_code = strtoupper(substr($name, 0, 3));
    
    // Get database instance
    $db = App::resolve(Database::class);
    
    // Check for existing codes with the same prefix
    $existing_codes = $db->query(
        "SELECT supplier_code FROM suppliers WHERE supplier_code REGEXP :pattern",
        [':pattern' => "^{$base_code}[0-9]*$"]
    )->findAll();
    
    if (empty($existing_codes)) {
        return $base_code;
    }
    
    // Find the highest number used
    $highest_num = 0;
    foreach ($existing_codes as $code) {
        if (preg_match("/^{$base_code}([0-9]*)$/", $code['supplier_code'], $matches)) {
            $num = empty($matches[1]) ? 0 : (int)$matches[1];
            $highest_num = max($highest_num, $num);
        }
    }
    
    // Return the next number in sequence
    return $base_code . ($highest_num + 1);
}

try {
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    $result = App::resolve(Database::class)
        ->query('INSERT INTO suppliers
        (
            supplier_code,
            name,
            email,
            phone_number,
            street_address_line1,
            street_address_line2,
            city,
            state,
            postal_code,
            country,
            notes,
            created_at,
            modified_at
        ) 
        VALUES
        (
            :supplier_code,
            :name,
            :email,
            :phone_number,
            :street_address_line1,
            :street_address_line2,
            :city,
            :state,
            :postal_code,
            :country,
            :notes,
            :created_at,
            :modified_at
        )', 
        [
            ':supplier_code' => get_supplier_code($_POST['name']),
            ':name' => $_POST['name'],
            ':email' => $_POST['email'] ?? '',
            ':phone_number' => $_POST['phone-number'] ?? '',
            ':street_address_line1' => $_POST['street-address-line1'] ?? '',
            ':street_address_line2' => $_POST['street-address-line2'] ?? '',
            ':city' => $_POST['city'] ?? '',
            ':state' => $_POST['state'] ?? '',
            ':postal_code' => $_POST['postal-code'] ?? '',
            ':country' => $_POST['country'] ?? '',
            ':notes' => $_POST['notes'] ?? '',
            ':created_at' => $formattedDateTime,
            ':modified_at' => $formattedDateTime
        ]
    );
}
catch (PDOException $exception)
{
    $form->error(
        'form', 
        $exception->getMessage()
    )->throw();
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/inventory/suppliers');