<?php

use Core\App;
use Core\Database;
use Http\Forms\ItemCategoriesForm;
use DateTime;
use DateTimeZone;

$form = ItemCategoriesForm::validate($attributes = [
    'name' => $_POST['name'],
    'email' => $_POST['email'],
    'phone-number' => $_POST['phone-number'],
    'street-address-line1' => $_POST['street-address-line1'],
    'street-address-line2' => $_POST['street-address-line2'],
    'city' => $_POST['city'],
    'state' => $_POST['state'],
    'postal-code' => $_POST['postal-code'],
    'country' => $_POST['country'],
    'notes' => $_POST['notes']
]);

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    $result = App::resolve(Database::class)
        ->query('UPDATE suppliers 
        SET 
            name = :name,
            email = :email,
            phone_number = :phone_number,
            street_address_line1 = :street_address_line1,
            street_address_line2 = :street_address_line2,
            city = :city,
            state = :state,
            postal_code = :postal_code,
            country = :country,
            notes = :notes,
            modified_at = :modified_at
        WHERE id = :id', 
        [
            ':id' => $_POST['id'],
            ':name' => $_POST['name'],
            ':email' => $_POST['email'] ?? '',
            ':phone_number' => $_POST['phone-number'] ?? '',
            ':street_address_line1' => $_POST['street-address-line1'] ?? '',
            ':street_address_line2' => $_POST['street-address-line2'] ?? '',
            ':city' => $_POST['city'] ?? '',
            ':state' => $_POST['state'] ?? '',
            ':postal_code' => $_POST['postal-code'] ?? '',
            ':country' => $_POST['country'] ?? '',
            ':notes' => $_POST['notes'] ?? '',
            ':modified_at' => $formattedDateTime
        ]
    );
}
catch (PDOException $exception)
{
    $form->error(
        'form', 
        $exception->getMessage()
    )->throw();
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/inventory/suppliers');