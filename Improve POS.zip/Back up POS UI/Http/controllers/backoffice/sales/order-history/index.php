<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT
                id,
                reference_number,
                customer_name,
                employee_name,
                total_price,
                payment_amount,
                created_at
            FROM order_receipts
            WHERE archived_at IS NULL
                AND 
                (
                    :searchTerm = ""
                    OR reference_number LIKE :searchTerm
                    OR customer_name LIKE :searchTerm
                    OR employee_name LIKE :searchTerm
                    OR total_price LIKE :searchTerm
                    OR created_at LIKE :searchTerm
                )
            ORDER BY created_at DESC', 
        [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/sales/order-history/index.view.php", [
    'title' => 'Moth Vape | Back Office - Sales (Order Receipts)',
    'pageHeading' => 'Order History',
    'homeURI' => '/backoffice/sales/order-history',
    'result' => $result,
    'tableName' => 'order_receipts',
    'searchTerm' => $originalSearchTerm
]);