<?php

use Core\Session;

view("backoffice/sales/payment-methods/create.view.php", [
    'title' => 'Moth Vape | Back Office - Sales (Add Payment Methods)',
    'pageHeading' => 'Add Payment Method',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/sales/payment-methods'
]);