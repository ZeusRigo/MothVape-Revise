<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result = App::resolve(Database::class)
        ->query('SELECT * FROM payment_methods WHERE id = :id AND archived_at IS NULL', [
        ':id' => $_GET['id']
    ])->find();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/sales/payment-methods/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Sales (Edit Payment Methods)',
    'pageHeading' => 'Edit Payment Method',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/sales/payment-methods',
    'result' => $result
]);