<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT
                id,
                name,
                created_at,
                modified_at
            FROM payment_methods
            WHERE archived_at IS NULL
                AND 
                (
                    :searchTerm = ""
                    OR name LIKE :searchTerm
                )
            ORDER BY modified_at DESC', 
        [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/sales/payment-methods/index.view.php", [
    'title' => 'Moth Vape | Back Office - Sales (Payment Methods)',
    'pageHeading' => 'Payment Methods',
    'homeURI' => '/backoffice/sales/payment-methods',
    'result' => $result,
    'tableName' => 'payment_methods',
    'searchTerm' => $originalSearchTerm
]);