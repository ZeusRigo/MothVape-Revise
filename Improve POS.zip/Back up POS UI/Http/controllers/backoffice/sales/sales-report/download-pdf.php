<?php

use Core\Database;
use Core\App;

// Prevent any output before PDF generation
ob_clean();

$db = App::resolve(Database::class);

// Get period and other parameters from URL
$period = $_GET['period'] ?? 'daily';
$date = $_GET['date'] ?? date('Y-m-d'); // Default to today if no date provided
$start_date = $_GET['start_date'] ?? null;
$end_date = $_GET['end_date'] ?? null;
$searchTerm = $_GET['search'] ?? '';

// Set up date condition and parameters based on period
if ($period === 'weekly') {
    $date_condition = "DATE(r.created_at) BETWEEN :start_date AND :end_date";
    $params = [
        ':start_date' => $start_date,
        ':end_date' => $end_date
    ];
} elseif ($period === 'monthly') {
    $date_condition = "DATE_FORMAT(r.created_at, '%Y-%m') = DATE_FORMAT(:date, '%Y-%m')";
    $params = [':date' => $date];
} elseif ($period === 'annual') {
    $date_condition = "YEAR(r.created_at) = :year";
    $params = [':year' => date('Y', strtotime($date))];
} else {
    $date_condition = "DATE(r.created_at) = :date";
    $params = [':date' => $date];
}

// Copy query logic from show.php
$query = "SELECT 
    r.id,
    " . ($period === 'annual' ? "DATE_FORMAT(r.created_at, '%Y-%m-01')" : "DATE(r.created_at)") . " as date,
    COUNT(*) as transaction_count,
    SUM(r.total_price) as total_sales";

if ($period === 'annual') {
    $query .= ", MONTH(r.created_at) as period_num";
}

$query .= " FROM order_receipts r WHERE {$date_condition}";
$query .= " AND r.archived_at IS NULL";
$query .= " GROUP BY " . ($period === 'annual' ? "MONTH(r.created_at)" : "DATE(r.created_at)");
$query .= " ORDER BY date ASC";

$daily_breakdown = $db->query($query, $params)->findAll();

// Calculate summary totals
$summary = [
    'transaction_count' => array_sum(array_column($daily_breakdown, 'transaction_count')),
    'total_sales' => array_sum(array_column($daily_breakdown, 'total_sales'))
];

// Get products sold data
$products_query = "SELECT 
    i.name,
    ic.name as category,
    SUM(oi.quantity) as quantity_sold,
    oi.price as unit_price,
    SUM(oi.quantity * oi.price) as total_sales
    FROM order_items oi
    JOIN order_receipts r ON oi.order_receipt_id = r.id
    JOIN item_batches ib ON oi.batch_number = ib.batch_number
    JOIN items i ON ib.item_id = i.id
    JOIN item_categories ic ON i.category_id = ic.id
    WHERE {$date_condition}
    AND r.archived_at IS NULL
    GROUP BY i.id, i.name, ic.name, oi.price
    ORDER BY i.name";

$products_sold = $db->query($products_query, $params)->findAll();

// Create new PDF document
$pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Mothvape');
$pdf->SetTitle('Sales Report');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(15, 15, 15);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, 15);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('dejavusans', '', 11);

// Add logo - make it smaller and adjust position
$logo_path = base_path('public/assets/images/moth-vape-logo.png');
$pdf->Image($logo_path, 85, 15, 40, '', 'PNG', '', 'T', true, 300, 'C'); // Changed width from 90 to 40, x from 60 to 85

// Add less space after logo
$pdf->Ln(45); // Reduced from 70 to 45

// Define peso symbol
$peso = '&#8369;';

// Add content
$html = '';

// Header - add some styling to make it more prominent
$html .= '<h1 style="text-align:center; font-size: 20pt; font-weight: bold;">Sales Report</h1>';
$html .= '<h3 style="text-align:center;">Period: ' . ucfirst($period) . '</h3>';
$html .= '<h3 style="text-align:center;">';
if ($period === 'weekly') {
    $html .= date('F j, Y', strtotime($start_date)) . ' to ' . date('F j, Y', strtotime($end_date));
} elseif ($period === 'monthly') {
    $html .= date('F Y', strtotime($date));
} elseif ($period === 'annual') {
    $html .= date('Y', strtotime($date));
} else {
    $html .= date('F j, Y', strtotime($date));
}
$html .= '</h3>';

// Summary
$html .= '<h2>Summary</h2>';
$html .= '<p>Number of Transactions: ' . number_format($summary['transaction_count']) . '</p>';
$html .= '<p>Total Sales: ' . $peso . number_format($summary['total_sales'], 2) . '</p>';

// Daily/Monthly Breakdown Table
if ($daily_breakdown) {
    $html .= '<h2>';
    if ($period === 'monthly') {
        $html .= 'Daily';
    } elseif ($period === 'annual') {
        $html .= 'Monthly';
    } elseif ($period === 'weekly') {
        $html .= 'Weekly';
    }
    $html .= ' Breakdown</h2>';
    
    $html .= '<table border="1" cellpadding="5">
        <thead>
            <tr style="background-color:#f4f4f4;">
                <th>Date</th>
                <th>Transactions</th>
                <th>Total Sales</th>
            </tr>
        </thead>
        <tbody>';
    
    foreach ($daily_breakdown as $row) {
        $html .= '<tr>';
        if ($period === 'annual') {
            $html .= '<td>' . date('F', mktime(0, 0, 0, $row['period_num'], 1)) . '</td>';
        } else {
            $html .= '<td>' . date('F j, Y', strtotime($row['date'])) . '</td>';
        }
        $html .= '<td>' . number_format($row['transaction_count']) . '</td>';
        $html .= '<td>' . $peso . number_format($row['total_sales'], 2) . '</td>';
        $html .= '</tr>';
    }
    
    $html .= '</tbody></table>';
}

// Products Sold Table
if (!empty($products_sold)) {
    $html .= '<h2>Products Sold Summary</h2>';
    $html .= '<table border="1" cellpadding="5">
        <thead>
            <tr style="background-color:#f4f4f4;">
                <th>Product Name</th>
                <th>Category</th>
                <th>Quantity Sold</th>
                <th>Unit Price</th>
                <th>Total Sales</th>
            </tr>
        </thead>
        <tbody>';
    
    foreach ($products_sold as $product) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($product['name']) . '</td>';
        $html .= '<td>' . htmlspecialchars($product['category']) . '</td>';
        $html .= '<td>' . number_format($product['quantity_sold']) . '</td>';
        $html .= '<td>' . $peso . number_format($product['unit_price'], 2) . '</td>';
        $html .= '<td>' . $peso . number_format($product['total_sales'], 2) . '</td>';
        $html .= '</tr>';
    }
    
    $html .= '</tbody></table>';
}

// Write HTML to PDF
$pdf->writeHTML($html, true, false, true, false, '');

// Generate filename
$filename = "sales-report-";
if ($period === 'weekly') {
    $filename .= date('Y-m-d', strtotime($start_date)) . "-to-" . date('Y-m-d', strtotime($end_date));
} elseif ($period === 'monthly') {
    $filename .= date('Y-m', strtotime($date));
} elseif ($period === 'annual') {
    $filename .= date('Y', strtotime($date));
} else {
    $filename .= date('Y-m-d', strtotime($date));
}
$filename .= ".pdf";

// Output PDF
$pdf->Output($filename, 'D'); 