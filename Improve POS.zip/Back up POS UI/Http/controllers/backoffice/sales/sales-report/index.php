<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $period = $_GET['period'] ?? 'all'; // Get selected period
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    // Base query for summarized data
    if ($period === 'weekly') {
        $query = '
            SELECT 
                MIN(DATE(created_at)) as start_date,
                MAX(DATE(created_at)) as end_date,
                COUNT(*) as transaction_count,
                SUM(total_price) as total_sales,
                YEARWEEK(created_at, 1) as week_group
            FROM order_receipts 
            WHERE archived_at IS NULL';
    } elseif ($period === 'monthly') {
        $query = '
            SELECT 
                DATE_FORMAT(created_at, "%Y-%m-01") as date,
                COUNT(*) as transaction_count,
                SUM(total_price) as total_sales,
                EXTRACT(YEAR_MONTH FROM created_at) as month_group
            FROM order_receipts 
            WHERE archived_at IS NULL';
    } elseif ($period === 'annual') {
        $query = '
            SELECT 
                YEAR(created_at) as date,
                COUNT(*) as transaction_count,
                SUM(total_price) as total_sales
            FROM order_receipts 
            WHERE archived_at IS NULL';
    } else {
        $query = '
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as transaction_count,
                SUM(total_price) as total_sales
            FROM order_receipts 
            WHERE archived_at IS NULL';
    }

    // Add period filter
    switch ($period) 
    {
        case 'daily':
            $query .= ' AND DATE(created_at) = CURRENT_DATE';
            break;
        case 'weekly':
            $query .= ' AND created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 1 WEEK)';
            break;
        case 'monthly':
            $query .= ' AND created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)';
            break;
        case 'annual':
            $query .= ' AND created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 1 YEAR)';
            break;
    }

    $params = [];

    // Add search filter if needed
    if ($searchTerm !== '%%') {
        $query .= ' AND (
            reference_number LIKE :searchTerm
            OR customer_name LIKE :searchTerm
            OR employee_name LIKE :searchTerm
            OR total_price LIKE :searchTerm
            OR created_at LIKE :searchTerm
        )';
        $params[':searchTerm'] = $searchTerm;
    }

    // Group by date/week/month and order
    if ($period === 'weekly') {
        $query .= ' GROUP BY week_group ORDER BY start_date DESC';
    } elseif ($period === 'monthly') {
        $query .= ' GROUP BY month_group ORDER BY date DESC';
    } elseif ($period === 'annual') {
        $query .= ' GROUP BY YEAR(created_at) ORDER BY date DESC';
    } else {
        $query .= ' GROUP BY DATE(created_at) ORDER BY date DESC';
    }

    $result = App::resolve(Database::class)
        ->query($query, $params)
        ->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/sales/sales-report/index.view.php", [
    'title' => 'Moth Vape | Back Office - Sales (Sales Report)',
    'pageHeading' => 'Sales Report',
    'homeURI' => '/backoffice/sales/sales-report',
    'result' => $result,
    'searchTerm' => $originalSearchTerm,
    'period' => $period
]);