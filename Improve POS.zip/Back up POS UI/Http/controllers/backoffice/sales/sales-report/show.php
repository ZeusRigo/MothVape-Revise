<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $db = App::resolve(Database::class);
    $period = $_GET['period'] ?? 'daily';
    
    // Set date parameters based on period
    if ($period === 'weekly') {
        $start_date = $_GET['start_date'];
        $end_date = $_GET['end_date'];
        $date_condition = "DATE(or2.created_at) BETWEEN :start_date AND :end_date";
        $date_params = [
            ':start_date' => $start_date,
            ':end_date' => $end_date
        ];
    } elseif ($period === 'monthly') {
        $date = $_GET['date'];
        $date_condition = "DATE_FORMAT(or2.created_at, '%Y-%m') = DATE_FORMAT(:date, '%Y-%m')";
        $date_params = [':date' => $date];
    } elseif ($period === 'annual') {
        $date = $_GET['date'];
        $year = date('Y', strtotime($date));
        $date_condition = "YEAR(or2.created_at) = :year";
        $date_params = [':year' => $year];
    } else {
        $date = $_GET['date'];
        $date_condition = "DATE(or2.created_at) = :date";
        $date_params = [':date' => $date];
    }

    // Get period summary
    $summary = $db->query("
        SELECT 
            COUNT(*) as transaction_count,
            SUM(total_price) as total_sales
        FROM order_receipts or2 
        WHERE {$date_condition} 
        AND or2.archived_at IS NULL", 
        $date_params
    )->find();

    // Get products sold during the period
    $products_sold = $db->query("
        SELECT 
            i.name,
            ic.name as category,
            SUM(oi.quantity) as quantity_sold,
            oi.price as unit_price,
            SUM(oi.quantity * oi.price) as total_sales
        FROM order_items oi
        JOIN order_receipts or2 ON oi.order_receipt_id = or2.id
        JOIN item_batches ib ON oi.batch_number = ib.batch_number
        JOIN items i ON ib.item_id = i.id
        JOIN item_categories ic ON i.category_id = ic.id
        WHERE {$date_condition}
        AND or2.archived_at IS NULL
        GROUP BY i.id, i.name, ic.name, oi.price
        ORDER BY i.name", 
        $date_params
    )->findAll();

    // Get top selling products
    $top_products = $db->query("
        SELECT 
            i.name,
            ic.name as category,
            SUM(oi.quantity) as quantity_sold,
            SUM(oi.quantity * oi.price) as total_sales
        FROM order_items oi
        JOIN order_receipts or2 ON oi.order_receipt_id = or2.id
        JOIN item_batches ib ON oi.batch_number = ib.batch_number
        JOIN items i ON ib.item_id = i.id
        JOIN item_categories ic ON i.category_id = ic.id
        WHERE {$date_condition}
        AND or2.archived_at IS NULL
        GROUP BY i.id, i.name, ic.name
        ORDER BY quantity_sold DESC
        LIMIT 5", 
        $date_params
    )->findAll();

    // Get daily/monthly breakdown based on period
    $daily_breakdown = null;
    if ($period === 'monthly' || $period === 'annual' || $period === 'weekly') {
        if ($period === 'monthly') {
            $groupBy = 'DATE(or2.created_at)';
            $dateFormat = 'F j, Y';
        } elseif ($period === 'annual') {
            $groupBy = 'MONTH(or2.created_at)';
            $dateFormat = 'F';
        } elseif ($period === 'weekly') {
            $groupBy = 'DATE(or2.created_at)';
            $dateFormat = 'F j, Y';
        }
        
        $daily_breakdown = $db->query("
            SELECT 
                {$groupBy} as date,
                " . ($period === 'annual' ? 'MONTH(or2.created_at)' : 'DAYOFWEEK(or2.created_at)') . " as period_num,
                COUNT(*) as transaction_count,
                SUM(total_price) as total_sales
            FROM order_receipts or2
            WHERE {$date_condition}
            AND or2.archived_at IS NULL
            GROUP BY {$groupBy}
            ORDER BY date ASC", 
            $date_params
        )->findAll();
    }

    if (!$summary || !$products_sold) {
        abort(Response::NOT_FOUND);
    }
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/sales/sales-report/show.view.php", [
    'title' => 'Moth Vape | Back Office - Sales Report Details',
    'pageHeading' => 'Sales Report Details',
    'homeURI' => '/backoffice/sales/sales-report',
    'period' => $period,
    'date' => $date ?? null,
    'start_date' => $start_date ?? null,
    'end_date' => $end_date ?? null,
    'summary' => $summary,
    'products_sold' => $products_sold,
    'top_products' => $top_products,
    'daily_breakdown' => $daily_breakdown
]);