<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result_employees = App::resolve(Database::class)
        ->query('
            SELECT 
                id, 
                CONCAT(first_name, " ", IFNULL(middle_name, ""), " ", last_name) AS full_name
            FROM employees
            WHERE archived_at IS NULL
            ORDER BY full_name ASC', 
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/users/employee-shifts/create.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Add Employee Shifts)',
    'pageHeading' => 'Add Employee Shifts',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/users/employee-shifts',
    'result_employees' => $result_employees
]);