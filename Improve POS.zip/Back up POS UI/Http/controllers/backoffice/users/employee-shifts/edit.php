<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try 
{
    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                id,
                employee_id,
                DATE_FORMAT(shift_date, "%m-%d-%Y") AS formatted_shift_date,
                DATE_FORMAT(clock_in_time, "%h:%i:%s %p") AS formatted_clock_in_time,
                DATE_FORMAT(clock_out_time, "%h:%i:%s %p") AS formatted_clock_out_time
            FROM employee_shifts
            WHERE id = :id AND archived_at IS NULL', [
                ':id' => $_GET['id']
        ])->find();

    $result_employees = App::resolve(Database::class)
        ->query('
            SELECT 
                id, 
                CONCAT(first_name, " ", IFNULL(middle_name, ""), " ", last_name) AS full_name
            FROM employees
            WHERE archived_at IS NULL
            ORDER BY full_name ASC', 
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/users/employee-shifts/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Edit Employees)',
    'pageHeading' => 'Edit Employee Shift',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/users/employee-shifts',
    'result' => $result,
    'result_employees' => $result_employees
]);