<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';
    
    $result = App::resolve(Database::class)
        ->query('
            SELECT 
                a.*,
                DATE_FORMAT(a.clock_in_time, "%h:%i:%s %p") AS formatted_clock_in_time,
                DATE_FORMAT(a.clock_out_time, "%h:%i:%s %p") AS formatted_clock_out_time,
                CONCAT(b.first_name, " ", IFNULL(b.middle_name, ""), " ", b.last_name) AS full_name
            FROM employee_shifts AS a
            LEFT JOIN employees AS b ON a.employee_id = b.id
            WHERE a.archived_at IS NULL
                AND (
                    :searchTerm = "" 
                    OR CONCAT(b.first_name, " ", IFNULL(b.middle_name, ""), " ", b.last_name) LIKE :searchTerm
                    OR shift_date LIKE :searchTerm
                )
            ORDER BY a.shift_date DESC
        ', 
        [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/users/employee-shifts/index.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Employee Shifts)',
    'pageHeading' => 'Employee Shifts',
    'homeURI' => '/backoffice/users/employee-shifts',
    'result' => $result,
    'tableName' => 'employee_shifts',
    'searchTerm' => $originalSearchTerm
]);