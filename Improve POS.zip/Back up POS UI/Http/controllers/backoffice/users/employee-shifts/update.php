<?php

use Core\App;
use Core\Database;
use Http\Forms\EmployeeShiftsForm;
use DateTime;
use DateTimeZone;

$form = EmployeeShiftsForm::validate($attributes = [
    'employee-id' => $_POST['employee-id'],
    'shift-date' => $_POST['shift-date'],
    'clock-in-time' => $_POST['clock-in-time'],
    'clock-out-time' => $_POST['clock-out-time']
]);

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');
    $currentDate = $currentDateTime->format('Y-m-d');
    $currentTime = $currentDateTime->format('H:i:s');

    $result = App::resolve(Database::class)
        ->query('UPDATE employee_shifts
        SET
            employee_id = :employee_id,
            shift_date = :shift_date,
            clock_in_time = STR_TO_DATE(:clock_in_time, "%H:%i:%s"),
            clock_out_time = STR_TO_DATE(:clock_out_time, "%H:%i:%s"),
            modified_at = :modified_at
        WHERE id = :id', 
        [
            ':id' => $_POST['id'],
            ':employee_id' => isset($_POST['employee-id']) && is_numeric($_POST['employee-id']) ? (int) $_POST['employee-id'] : null,
            ':shift_date' => !empty($_POST['shift-date']) ? $_POST['shift-date'] : $currentDate,
            ':clock_in_time' => !empty($_POST['clock-in-time']) ? $_POST['clock-in-time'] : $currentTime,
            ':clock_out_time' => !empty($_POST['clock-out-time']) ? $_POST['clock-out-time'] : null,
            ':modified_at' => $formattedDateTime
        ]
    );
}
catch (PDOException $exception)
{
    $form->error(
        'form', 
        $exception->getMessage()
    )->throw();
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/users/employee-shifts');