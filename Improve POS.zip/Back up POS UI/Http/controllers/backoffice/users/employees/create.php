<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try
{
    $result_roles = App::resolve(Database::class)
        ->query('SELECT id, name FROM roles WHERE archived_at IS NULL AND is_admin IS NULL ORDER BY name ASC', 
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/users/employees/create.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Add Employee)',
    'pageHeading' => 'Add Employee',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/users/employees',
    'result_roles' => $result_roles
]);