<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try 
{
    $result = App::resolve(Database::class)
        ->query('SELECT * FROM employees WHERE id = :id AND archived_at IS NULL', [
            ':id' => $_GET['id']
    ])->find();

    $result_user = App::resolve(Database::class)
        ->query('SELECT username, password, role_id FROM users WHERE id = :id AND archived_at IS NULL', [
            ':id' => $result['user_id']
    ])->find();

    $result_roles = App::resolve(Database::class)
        ->query('SELECT id, name FROM roles WHERE archived_at IS NULL AND is_admin IS NULL ORDER BY name ASC', 
    [])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/users/employees/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Edit Employees)',
    'pageHeading' => 'Edit Employee',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/users/employees',
    'result' => $result,
    'result_user' => $result_user,
    'result_roles' => $result_roles
]);