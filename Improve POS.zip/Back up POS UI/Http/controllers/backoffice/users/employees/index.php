<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT
                a.id,
                CONCAT(a.first_name, " ", IFNULL(a.middle_name, ""), " ", a.last_name) AS full_name,
                a.email,
                a.phone_number,
                a.created_at,
                a.modified_at,
                b.username,
                b.password,
                c.name AS role_name
            FROM employees AS a
            LEFT JOIN users AS b ON a.user_id = b.id
            LEFT JOIN roles AS c ON b.role_id = c.id
            WHERE a.archived_at IS NULL
                AND 
                (
                    :searchTerm = "" 
                    OR CONCAT(a.first_name, " ", IFNULL(a.middle_name, ""), " ", a.last_name) LIKE :searchTerm
                    OR a.email LIKE :searchTerm
                    OR a.phone_number LIKE :searchTerm
                    OR b.username LIKE :searchTerm
                    OR c.name LIKE :searchTerm
                )
            ORDER BY a.modified_at DESC
        ', 
        [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/users/employees/index.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Employees)',
    'pageHeading' => 'Employees',
    'homeURI' => '/backoffice/users/employees',
    'result' => $result,
    'tableName' => 'employees',
    'searchTerm' => $originalSearchTerm
]);