<?php

use Core\App;
use Core\Database;
use Http\Forms\EmployeesForm;
use DateTime;
use DateTimeZone;

$form = EmployeesForm::validate($attributes = [
    'first-name' => $_POST['first-name'],
    'middle-name' => $_POST['middle-name'],
    'last-name' => $_POST['last-name'],
    'email' => $_POST['email'],
    'phone-number' => $_POST['phone-number'],
    'street-address-line1' => $_POST['street-address-line1'],
    'street-address-line2' => $_POST['street-address-line2'],
    'city' => $_POST['city'],
    'state' => $_POST['state'],
    'postal-code' => $_POST['postal-code'],
    'country' => $_POST['country'],
    'role-id' => $_POST['role-id'],
    'username' => $_POST['username'],
    'password' => $_POST['password'],
    'verify-password' => $_POST['verify-password']
]);

// Verify password
if ($_POST['verify-password'] === $_POST['password'])
{
    try 
    {
        // Get current datetime with timezone
        $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
        $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

        // Fetch user ID
        $result_employee_userId = App::resolve(Database::class)
            ->query('SELECT user_id FROM employees WHERE id = :id', [
                ':id' => $_POST['id']
            ])->find();

        // Update user
        $result_user = App::resolve(Database::class)
            ->query('UPDATE users
            SET
                username = :username,
                password = :password,
                role_id = :role_id,
                modified_at = :modified_at
            WHERE id = :id',
            [
                ':id' => $result_employee_userId['user_id'],
                ':username' => $_POST['username'],
                ':password' => password_hash($_POST['password'], PASSWORD_BCRYPT),
                ':role_id' => isset($_POST['role-id']) && is_numeric($_POST['role-id']) ? (int) $_POST['role-id'] : null,
                ':modified_at' => $formattedDateTime
            ]);

        // Update employee
        $result = App::resolve(Database::class)
            ->query('UPDATE employees
            SET
                first_name = :first_name,
                middle_name = :middle_name,
                last_name = :last_name,
                email = :email,
                phone_number = :phone_number,
                street_address_line1 = :street_address_line1,
                street_address_line2 = :street_address_line2,
                city = :city,
                state = :state,
                postal_code = :postal_code,
                country = :country,
                modified_at = :modified_at
            WHERE id = :id',
            [
                ':id' => $_POST['id'],
                ':first_name' => $_POST['first-name'],
                ':middle_name' => $_POST['middle-name'] !== '' ? $_POST['middle-name'] : null,
                ':last_name' => $_POST['last-name'],
                ':email' => $_POST['email'] !== '' ? $_POST['email'] : null,
                ':phone_number' => $_POST['phone-number'] !== '' ? $_POST['phone-number'] : null,
                ':street_address_line1' => $_POST['street-address-line1'] !== '' ? $_POST['street-address-line1'] : null,
                ':street_address_line2' => $_POST['street-address-line2'] !== '' ? $_POST['street-address-line2'] : null,
                ':city' => $_POST['city'] !== '' ? $_POST['city'] : null,
                ':state' => $_POST['state'] !== '' ? $_POST['state'] : null,
                ':postal_code' => $_POST['postal-code'] !== '' ? $_POST['postal-code'] : null,
                ':country' => $_POST['country'] !== '' ? $_POST['country'] : null,
                ':modified_at' => $formattedDateTime
            ]
        );
    }
    catch (PDOException $exception)
    {
        $form->error(
            'form', 
            $exception->getMessage()
        )->throw();
    }
}

if (!$result)
{
    $form->error(
        'form', 
        'An error occurred while submitting the form. Please try again.'
    )->throw();
}

redirect('/backoffice/users/employees');