<?php

use Core\Session;

view("backoffice/users/roles/create.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Add Role)',
    'pageHeading' => 'Add Role',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/users/roles'
]);