<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try 
{
    $result = App::resolve(Database::class)
        ->query('SELECT * FROM roles WHERE id = :id AND archived_at IS NULL AND is_admin IS NULL', [
            ':id' => $_GET['id']
    ])->find();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("backoffice/users/roles/edit.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Edit Roles)',
    'pageHeading' => 'Edit Role',
    'errors' => Session::get('errors'),
    'homeURI' => '/backoffice/users/roles',
    'result' => $result
]);