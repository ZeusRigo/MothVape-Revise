<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $result = App::resolve(Database::class)
        ->query('
            SELECT
                id,
                name,
                manage_sales,
                manage_inventory,
                manage_users,
                created_at,
                modified_at
            FROM roles
            WHERE archived_at IS NULL AND is_admin IS NULL
                AND 
                (
                    :searchTerm = "" 
                    OR name LIKE :searchTerm
                )
            ORDER BY modified_at DESC
        ', 
        [
            ':searchTerm' => $searchTerm
        ])->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("backoffice/users/roles/index.view.php", [
    'title' => 'Moth Vape | Back Office - Users (Roles)',
    'pageHeading' => 'Roles',
    'homeURI' => '/backoffice/users/roles',
    'result' => $result,
    'tableName' => 'roles',
    'searchTerm' => $originalSearchTerm
]);