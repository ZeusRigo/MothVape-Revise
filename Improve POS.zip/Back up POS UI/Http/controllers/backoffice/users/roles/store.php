<?php

use Core\App;
use Core\Database;
use Http\Forms\RolesForm;
use DateTime;
use DateTimeZone;

$form = RolesForm::validate($attributes = [
    'name' => $_POST['name'],
    'manage-sales' => $_POST['manage-sales'] ?? '',
    'manage-inventory' => $_POST['manage-inventory'] ?? '',
    'manage-users' => $_POST['manage-users'] ?? ''
]);

// Determine backoffice access based on other permissions
$hasManagementPermissions = 
    (isset($_POST['manage-sales']) && $_POST['manage-sales'] === 'on') ||
    (isset($_POST['manage-inventory']) && $_POST['manage-inventory'] === 'on') ||
    (isset($_POST['manage-users']) && $_POST['manage-users'] === 'on');

try 
{
    // Get current datetime with timezone
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $formattedDateTime = $currentDateTime->format('Y-m-d H:i:s');

    $result = App::resolve(Database::class)
        ->query('INSERT INTO roles
        (
            name,
            access_backoffice,
            manage_sales,
            manage_inventory,
            manage_users,
            created_at,
            modified_at
        ) 
        VALUES
        (
            :name,
            :access_backoffice,
            :manage_sales,
            :manage_inventory,
            :manage_users,
            :created_at,
            :modified_at
        )', 
        [
            ':name' => $_POST['name'],
            ':access_backoffice' => $hasManagementPermissions ? 1 : 0,
            ':manage_sales' => isset($_POST['manage-sales']) && $_POST['manage-sales'] === 'on' ? 1 : 0,
            ':manage_inventory' => isset($_POST['manage-inventory']) && $_POST['manage-inventory'] === 'on' ? 1 : 0,
            ':manage_users' => isset($_POST['manage-users']) && $_POST['manage-users'] === 'on' ? 1 : 0,
            ':created_at' => $formattedDateTime,
            ':modified_at' => $formattedDateTime
        ]
    );
}
catch (PDOException $exception)
{
    $form->error('form', $exception->getMessage())->throw();
}

if (!$result)
{
    $form->error('form', 'An error occurred while submitting the form. Please try again.')->throw();
}

redirect('/backoffice/users/roles');