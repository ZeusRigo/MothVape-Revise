<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $db = App::resolve(Database::class);
    
    $query = "SELECT id, name FROM payment_methods WHERE archived_at IS NULL ORDER BY name ASC";
    $result_paymentMethods = $db->query($query)->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

$order_data = json_decode($_POST['order_data'], true);

if (!$order_data) 
{
    redirect('/pos');
}

view("pos/checkout.view.php", [
    'title' => 'Moth Vape | Checkout',
    'result_paymentMethods' => $result_paymentMethods,
    'order_data' => $order_data
]);