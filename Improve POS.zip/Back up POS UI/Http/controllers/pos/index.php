<?php

use Core\App;
use Core\Database;
use Core\Response;

try
{
    $searchTerm = $_GET['search'] ?? '';
    $originalSearchTerm = $searchTerm;
    $searchTerm = '%' . $searchTerm . '%';

    $db = App::resolve(Database::class);
    
    $items = $db->query(
        "SELECT 
            b.id as item_id,
            b.sku,
            b.name,
            b.image_url,
            b.price,
            c.name as category,
            SUM(a.quantity) as total_quantity,
            MIN(a.expiration_date) as nearest_expiration,
            GROUP_CONCAT(a.id) as batch_ids,
            GROUP_CONCAT(a.quantity) as batch_quantities
        FROM items AS b
        INNER JOIN item_batches as a ON a.item_id = b.id
        LEFT JOIN item_categories c ON b.category_id = c.id
        WHERE a.archived_at IS NULL
            AND b.archived_at IS NULL
            AND (
                :searchTerm = ''
                OR b.sku LIKE :searchTerm
                OR b.name LIKE :searchTerm
                OR c.name LIKE :searchTerm
            )
            AND a.quantity > 0
            AND (
                a.expiration_date IS NULL 
                OR a.expiration_date > CURRENT_DATE()
            )
        GROUP BY b.id, b.sku, b.name, b.image_url, b.price, c.name
        ORDER BY b.name ASC",
        [
            ':searchTerm' => $searchTerm
        ]
    )->findAll();

    // Transform the items to include batch information
    $items = array_map(function($item) {
        $batch_ids = explode(',', $item['batch_ids']);
        $batch_quantities = explode(',', $item['batch_quantities']);
        
        // Create batches array with id and quantity pairs
        $batches = array_combine($batch_ids, $batch_quantities);
        
        // Add batches to item and remove the concatenated strings
        $item['batches'] = $batches;
        unset($item['batch_ids']);
        unset($item['batch_quantities']);
        
        return $item;
    }, $items);

    // Fetch all active categories
    $categories = $db->query(
        "SELECT id, name 
        FROM item_categories 
        WHERE archived_at IS NULL 
        ORDER BY name ASC"
    )->findAll();
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

view("pos/index.view.php", [
    'title' => 'Moth Vape | Point of Sale',
    'items' => $items,
    'categories' => $categories
]);