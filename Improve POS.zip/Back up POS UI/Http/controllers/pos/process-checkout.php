<?php

use Core\App;
use Core\Database;
use Http\Forms\CheckoutForm;

$orderItems = json_decode($_POST['order-items'], true);
$priceSummary = json_decode($_POST['price-summary'], true);
$customerName = !empty($_POST['customer-name']) ? trim($_POST['customer-name']) : null;
$employeeName = !empty($_POST['employee-name']) ? trim($_POST['employee-name']) : null;
$paymentMethod = $_POST['payment-method'];
$paymentAmount = filter_var($_POST['payment-amount'], FILTER_VALIDATE_FLOAT);
$totalAmount = filter_var($priceSummary['total'], FILTER_VALIDATE_FLOAT);

try 
{
    // Validate the checkout form
    $form = CheckoutForm::validate([
        'order_items' => $orderItems,
        'payment_method' => $paymentMethod,
        'payment_amount' => $paymentAmount,
        'total_amount' => $totalAmount
    ]);

    $db = App::resolve(Database::class);
    
    // Fetch employee name
    $employee = App::resolve(Database::class)
        ->query('SELECT * FROM employees WHERE user_id = :user_id AND archived_at IS NULL', [
        ':user_id' => $_SESSION['user']['user_id']
    ])->find();

    // Update where you're inserting/creating records
    $currentDateTime = new DateTime('now', new DateTimeZone(date_default_timezone_get()));
    $created_at = $currentDateTime->format('Y-m-d H:i:s');

    // Insert order receipt
    $sql = "INSERT INTO order_receipts (
        reference_number,
        customer_name, 
        employee_name,
        discount,
        total_price,
        payment_method, 
        payment_amount,
        created_at
    ) 
    VALUES 
    (
        :reference_number,
        :customer_name, 
        :employee_name,
        :discount,
        :total_price,
        :payment_method, 
        :payment_amount,
        :created_at
    )";

    $db->query($sql, 
    [
        ':reference_number' => createUniqueReferenceNumber(),
        ':customer_name' => !empty($employee) ? $customerName : null, 
        ':employee_name' => !empty($employee) ? $employee['first_name'] . " " . $employee['last_name'] : null,
        ':discount' =>  $priceSummary['discountPercentage'],
        ':total_price' => $totalAmount,
        ':payment_method' => $paymentMethod, 
        ':payment_amount' => $paymentAmount,
        ':created_at' => $created_at
    ]);

    $receiptId = $db->lastInsertId();

    // Insert order items
    $itemSql = "INSERT INTO order_items (
        order_receipt_id,
        sku,
        batch_number,
        name,
        category,
        price,
        quantity
    ) 
    VALUES 
    (
        :order_receipt_id,
        :sku,
        :batch_number,
        :name,
        :category,
        :price,
        :quantity
    )";

    foreach ($orderItems as $item) 
    {
        // Find the item in the database
        $result_item = $db->query("SELECT * FROM items WHERE id = :id", 
        [
            ':id' => $item['item_id']
        ])->find();

        // Find the item category in the database
        $result_itemCategory = $db->query("SELECT * FROM item_categories WHERE id = :id", 
        [
            ':id' => $result_item['category_id']
        ])->find();

        // Get available batches for this item ordered by expiration date (FIFO)
        $available_batches = $db->query(
            "SELECT id, quantity, batch_number 
            FROM item_batches 
            WHERE item_id = :item_id 
                AND quantity > 0 
                AND archived_at IS NULL
                AND (expiration_date IS NULL OR expiration_date > CURRENT_DATE())
            ORDER BY 
                CASE WHEN expiration_date IS NULL THEN 1 ELSE 0 END,
                expiration_date ASC,
                created_at ASC",
            [
                ':item_id' => $item['item_id']
            ]
        )->findAll();

        $remaining_quantity = $item['quantity'];
        $batch_details = [];

        // Deduct quantities from batches using FIFO
        foreach ($available_batches as $batch) {
            if ($remaining_quantity <= 0) break;

            $deduct_quantity = min($batch['quantity'], $remaining_quantity);
            
            // Update the batch quantity
            $db->query(
                "UPDATE item_batches 
                SET quantity = quantity - :quantity 
                WHERE id = :id",
                [
                    ':quantity' => $deduct_quantity,
                    ':id' => $batch['id']
                ]
            );

            $batch_details[] = [
                'batch_number' => $batch['batch_number'],
                'quantity' => $deduct_quantity
            ];

            $remaining_quantity -= $deduct_quantity;
        }

        // For each batch used, create a separate order item record
        foreach ($batch_details as $batch) {
            $db->query($itemSql, 
            [
                ':order_receipt_id' => $receiptId,
                ':sku' => $item['sku'],
                ':batch_number' => $batch['batch_number'],
                ':name' => $item['name'],
                ':category' => $result_itemCategory['name'],
                ':price' => $item['price'],
                ':quantity' => $batch['quantity']
            ]);
        }

        // Verify if we were able to fulfill the entire order
        if ($remaining_quantity > 0) {
            throw new Exception("Insufficient stock for item: {$item['name']}");
        }
    }

    redirect('/pos');
} catch (PDOException $exception) {
    // Store the current order data in the session
    $_SESSION['order_data'] = [
        'items' => $orderItems,
        'summary' => $priceSummary
    ];
    
    return redirect('/pos/checkout');
}

function createUniqueReferenceNumber(): string
{
    do 
    {
        // Define SKU components
        $prefix = "REF";
        $yearMonth = date("Ym"); // Example: '202401' for Jan 2024
        $random = strtoupper(bin2hex(random_bytes(2))); // 4-character unique ID
        
        // Combine to generate SKU
        $referenceNumber = "{$prefix}-{$yearMonth}-{$random}";

        // Check if SKU already exists in the database
        $result = App::resolve(Database::class)->query('SELECT COUNT(*) FROM order_receipts WHERE reference_number = :reference_number', 
        [':reference_number' => $referenceNumber])->find();
    } 
    while ($result['COUNT(*)'] > 0);  // If the SKU exists, regenerate

    return $referenceNumber;
}