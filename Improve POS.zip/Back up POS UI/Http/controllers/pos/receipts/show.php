<?php

use Core\App;
use Core\Database;
use Core\Response;
use Core\Session;

try 
{
    $db = App::resolve(Database::class);
    
    // Get order receipt details with discount percentage
    $result = $db->query('SELECT 
        order_receipts.*,
        COALESCE(discount, 0) as discount_percentage 
        FROM order_receipts 
        WHERE id = :id AND archived_at IS NULL', [
        ':id' => $_GET['id']
    ])->find();

    // Get order items
    $result_orderItems = $db->query('SELECT * FROM order_items WHERE order_receipt_id = :order_receipt_id', [
        ':order_receipt_id' => $result['id']
    ])->findAll();

    // Price breakdown calculations
    $VAT = 12; // 12% VAT
    $discountPercentage = $result['discount_percentage'] ?? 0;
    $discountRate = $discountPercentage / 100;

    // Calculate totals
    $totalPriceWithVAT = 0;
    $totalPriceBeforeVAT = 0;
    $totalVAT = 0;
    $subtotal = 0;

    // Calculate subtotal and VAT for each item
    foreach ($result_orderItems as $item) 
    {
        $priceWithVAT = (float) $item['price'];
        $quantity = (int) $item['quantity'];
        
        // Add to total price with VAT
        $totalPriceWithVAT += $priceWithVAT * $quantity;
        
        // Calculate price before VAT (priceWithVAT / 1.12)
        $priceBeforeVAT = $priceWithVAT / (1 + ($VAT / 100));
        $totalPriceBeforeVAT += $priceBeforeVAT * $quantity;
        
        // VAT is the difference between price with VAT and price before VAT
        $vat = $priceWithVAT - $priceBeforeVAT;
        $totalVAT += $vat * $quantity;
        
        // Add to subtotal
        $subtotal += $priceWithVAT * $quantity;
    }

    $subtotalBeforeDiscount = $totalPriceWithVAT;
    $discountAmount = ($subtotalBeforeDiscount * $discountRate);
    $subtotalVATWithDiscount = $subtotalBeforeDiscount - $discountAmount;
    $totalAmount = $subtotalVATWithDiscount;

    // Add price breakdown to result array
    $result['price_breakdown'] = [
        'subtotal' => round($subtotalBeforeDiscount, 2),
        'discount' => round($discountAmount, 2),
        'price_before_vat' => round($totalPriceBeforeVAT, 2),
        'vat' => round($totalVAT, 2),
        'total_amount' => round($totalAmount, 2)
    ];
}
catch (PDOException $exception)
{
    abort(Response::INTERNAL_SERVER_ERROR, $exception->getMessage());
}

authorize($result);

view("pos/receipts/show.view.php", [
    'title' => 'Moth Vape | POS - Receipts',
    'pageHeading' => 'View Receipts: #',
    'errors' => Session::get('errors'),
    'homeURI' => '/pos/receipts',
    'result' => $result,
    'result_orderItems' => $result_orderItems
]);