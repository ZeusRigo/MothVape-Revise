<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>403 - Page Not Found!</title>
</head>
<body>
    <h1>403</h1>
    <p>Unauthorized access!</p>
</body>
</html>