<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>404 - Page Not Found!</title>
</head>
<body>
    <h1>404</h1>
    <p>Page Not Found!</p>
</body>
</html>