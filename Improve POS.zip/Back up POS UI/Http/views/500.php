<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>505 - Page Not Found!</title>
</head>
<body>
    <h1>505</h1>
    <p>Internal server occurred!</p>
    <p><?= $error ?></p>
</body>
</html>