<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="public/assets/css/main.css">
    <link rel="stylesheet" href="public/assets/css/customs/auth/auth.css">
</head>
<body>
    <div class="panel">
        <div class="panel__container">
            <img src="/assets/images/moth-vape-logo.webp" class="panel__logo" loading="lazy">
            <div>
                <p class="txt-white txt-center fs-3 fw-bold mb-3">Welcome!</p>
                <p class="txt-white txt-center fs-6">Please enter your credentials.</p>
            </div>
            <form action="/login" method="POST" class="panel__form w-75">
                <div class="mb-3">
                    <label for="username" class="form-label txt-white fw-bold">Username</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        class="form-control mt-2 mb-2 w-100"
                        placeholder="Enter username..."
                        value="<?= old('username') ?>"
                        required
                    >
                    <?php if (isset($errors['username'])) : ?>
                        <p class="txt-danger fw-bold mb-3"><?= $errors['username'] ?></p>
                    <?php endif; ?>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label txt-white fw-bold">Password</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        class="form-control mt-2 mb-2 w-100"
                        placeholder="Enter password..."
                        value="<?= $_POST['password'] ?? '' ?>"
                        required
                    >
                    <?php if (isset($errors['password'])) : ?>
                        <p class="txt-danger fw-bold mb-3"><?= $errors['password'] ?></p>
                    <?php endif; ?>
                </div>
                <?php if (isset($errors['login'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['login'] ?></p>
                <?php endif; ?>
                <button type="submit" class="panel__login-btn btn btn-success btn-lg fw-bold w-100">Log In</button>
            </form>
        </div>
    </div>
</body>
</html>