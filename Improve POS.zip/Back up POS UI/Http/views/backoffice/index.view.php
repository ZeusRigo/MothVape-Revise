<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-2">
            Hello, <?= ($user && isset($user['first_name'])) ? 
                htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) : 
                'Guest' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <div class="row mb-3">
        <div class="col">
            <a href="/backoffice/sales/order-history" class="card">
                <div class="card__body">
                    <div class="card__container-left">
                        <p class="fw-bold">Total Sales</p>
                        <div class="card__content-container">
                            <img src="/assets/images/cart-icon.webp" alt="Cart Icon" class="card__content-icon" loading="lazy">
                            <p class="card__content_txt fs-1"><?= number_format($totalSales) ?></p>
                        </div>
                    </div>
                    <div class="card__container-right">
                        <img src="/assets/images/arrow-right-icon.webp" alt="Arrow Right Icon" class="card__nav-icon" loading="lazy">
                    </div>
                </div>
            </a>
        </div>
        <div class="col">
            <a href="/backoffice/sales/sales-report" class="card">
                <div class="card__body">
                    <div class="card__container-left">
                        <p class="fw-bold">Total Revenue</p>
                        <div class="card__content-container">
                            <img src="/assets/images/money-icon.webp" alt="Money Icon" class="card__content-icon" loading="lazy">
                            <p class="card__content_txt fs-1">₱<?= number_format($totalRevenue, 2) ?></p>
                        </div>
                    </div>
                    <div class="card__container-right">
                        <img src="/assets/images/arrow-right-icon.webp" alt="Arrow Right Icon" class="card__nav-icon" loading="lazy">
                    </div>
                </div>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <a href="/backoffice/inventory/items" class="card">
                <div class="card__body">
                    <div class="card__container-left">
                        <p class="fw-bold">Total Items</p>
                        <div class="card__content-container">
                            <img src="/assets/images/package-icon.webp" alt="Package Icon" class="card__content-icon" loading="lazy">
                            <p class="card__content_txt fs-1"><?= number_format($totalItems) ?></p>
                        </div>
                    </div>
                    <div class="card__container-right">
                        <img src="/assets/images/arrow-right-icon.webp" alt="Arrow Right Icon" class="card__nav-icon" loading="lazy">
                    </div>
                </div>
            </a>
        </div>
        <div class="col">
            <a href="/backoffice/inventory/item-batches/add" class="card">
                <div class="card__body">
                    <div class="card__container-left">
                        <p class="fw-bold">Add New Batch</p>
                        <div class="card__content-container">
                            <img src="/assets/images/package-icon.webp" alt="Package Icon" class="card__content-icon" loading="lazy">
                        </div>
                    </div>
                    <div class="card__container-right">
                        <img src="/assets/images/arrow-right-icon.webp" alt="Arrow Right Icon" class="card__nav-icon" loading="lazy">
                    </div>
                </div>
            </a>
        </div>
        <div class="col">
            <a href="/pos" class="card">
                <div class="card__body">
                    <div class="card__container-left">
                        <p class="fw-bold">Enter POS</p>
                        <div class="card__content-container">
                            <img src="/assets/images/money-icon.webp" alt="Money Icon" class="card__content-icon" loading="lazy">
                        </div>
                    </div>
                    <div class="card__container-right">
                        <img src="/assets/images/arrow-right-icon.webp" alt="Arrow Right Icon" class="card__nav-icon" loading="lazy">
                    </div>
                </div>
            </a>
        </div>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>