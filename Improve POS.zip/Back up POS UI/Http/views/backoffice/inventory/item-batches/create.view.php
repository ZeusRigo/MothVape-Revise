<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <p class="fw-bold fs-5 mb-0">Select items to batch:</p>
            <div class="controls__search-container" style="width: 300px;">
                <input 
                    type="text"
                    id="search" 
                    class="form-control"
                    placeholder="Search by SKU, name or category..."
                >
                <button 
                    type="button"
                    class="btn btn-dark btn-has-icon"
                >
                    <img src="/assets/images/search-icon.webp" alt="Search Icon" class="btn__icon btn__icon--invert" loading="lazy">
                </button>
            </div>
        </div>
        <!-- Items Table -->
        <div class="table-container" style="max-height: 300px;">
            <table class="table">
                <thead class="table__header">
                    <tr>
                        <th scope="col" class="table__cell" style="width: 15%">SKU</th>
                        <th scope="col" class="table__cell">Item</th>
                        <th scope="col" class="table__cell">Category</th>
                        <th scope="col" class="table__cell" style="width: 5%">Actions</th>
                    </tr>
                </thead>
                <tbody class="table__body">
                    <?php if (!empty($result_items)) : ?>
                        <?php foreach ($result_items as $row) : ?>
                            <tr 
                                class="table__row" 
                                onclick="addBatchedItem(
                                    <?= htmlspecialchars($row['id']) ?>, 
                                    '<?= htmlspecialchars($row['sku']) ?>',
                                    '<?= htmlspecialchars($row['name']) ?>'
                                )"
                            >
                                <td class="table__cell"><?= htmlspecialchars($row['sku']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($row['name']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($row['category_name'] ?? 'N/A') ?></td>
                                <td class="table__cell table__cell--actions">
                                    <div class="table__actions-container">
                                        <button
                                            type="button"
                                            class="btn btn-success btn-has-icon"
                                            data-id="<?php echo htmlspecialchars($row['id']); ?>"
                                        >
                                            <img src="/assets/images/add-icon.webp" alt="Add Icon" class="btn__icon btn__icon--invert" loading="lazy">
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">No items found</td>
                        </tr>
                    <?php endif ?>
                </tbody>
            </table>
        </div>
        <p class="fw-bold fs-5">Items to batch:</p>
        <!-- Batched Items Table -->
        <div class="table-container">
            <table class="table">
                <thead class="table__header">
                    <tr>
                        <th scope="col" class="table__cell" style="width: 5%">SKU</th>
                        <th scope="col" class="table__cell">Item</th>
                        <th scope="col" class="table__cell" style="width: 5%">Batch Number</th>
                        <th scope="col" class="table__cell" style="width: 5%">Quantity</th>
                        <th scope="col" class="table__cell">Expiration Date</th>
                        <th scope="col" class="table__cell">Supplier</th>
                        <th scope="col" class="table__cell" style="width: 5%">Actions</th>
                    </tr>
                </thead>
                <tbody id="batched-items-table" class="table__body">
                </tbody>
            </table>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form'); clearBatchedItems();">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="panel__login-btn btn btn-success btn-has-icon fw-bold" onclick="submitBatchedItems()">
                Add
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<!-- Custom Scripts -->
<script src="public/assets/js/customs/backoffice/item-batches.js" defer></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize search with custom filter function
        initializeSearch('search', '.table__body tr', function(row, searchTerm) {
            const sku = row.children[0].textContent.toLowerCase();
            const name = row.children[1].textContent.toLowerCase();
            const category = row.children[2].textContent.toLowerCase();
            searchTerm = searchTerm.toLowerCase();
            
            return sku.includes(searchTerm) || 
                   name.includes(searchTerm) || 
                   category.includes(searchTerm);
        });
    });
</script>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>