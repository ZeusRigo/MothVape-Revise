<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <input type="hidden" name="_method" value="PATCH">
        <input type="hidden" name="id" value="<?= $result['id'] ?>">
        <!-- Item -->
        <div class="mb-4">
            <label for="item-id" class="form-label fw-bold">
                Item
                <span class="txt-danger">*</span>
            </label>
            <!-- Fetch items from database and populate options -->
            <select id="item-id" name="item-id" class="form-control mt-2" required>
                <?php if ($result_items) : ?>
                    <option value="">--- Select Item ---</option>
                    <?php foreach ($result_items as $row) : ?>
                        <option 
                            value="<?= htmlspecialchars($row['id']) ?>"
                            <?= (int) htmlspecialchars($row['id']) === $result['item_id'] ? 'selected' : '' ?>
                        >
                            <?= htmlspecialchars($row['name']) ?>
                        </option>
                    <?php endforeach ?>
                <?php elseif (empty($result_items)) : ?>
                    <option value="" selected>No Items Available</option>
                <?php else : ?>
                    <option value="" selected>Error Fetching Data!</option>
                <?php endif ?>
            </select>
            <?php if (isset($errors['item-id'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['item-id'] ?></p>
            <?php endif; ?>
        </div>
        <!-- Batch Number -->
        <div class="mb-3">
            <label for="name" class="form-label fw-bold">
                Batch Number
                <span class="txt-danger">*</span>
            </label>
            <div style="display: flex; align-items: center; gap: 0.5rem">
                <input 
                    type="text" 
                    id="batch-number" 
                    name="batch-number" 
                    class="form-control mt-2"
                    placeholder="Enter batch number"
                    value="<?= $result['batch_number'] ?>"
                    maxlength="50"
                    required
                >
                <button type="button" class="btn btn-info mt-2" onclick="generateBatchNumber('batch-number')">Generate</button>
            </div>
            <?php if (isset($errors['batch-number'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['batch-number'] ?></p>
            <?php endif; ?>
        </div>
        <!-- Quantity -->
        <div class="mb-3">
            <label for="name" class="form-label fw-bold">
                Quantity
                <span class="txt-danger">*</span>
            </label>
            <input 
                type="number" 
                id="quantity" 
                name="quantity" 
                class="form-control mt-2 mb-2"
                placeholder="0"
                value="<?= $result['quantity'] ?>"
                min="0"
                required
            >
            <?php if (isset($errors['quantity'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['quantity'] ?></p>
            <?php endif; ?>
        </div>
        <!-- Expiration Date -->
        <div class="mb-3">
            <label for="expiration-date" class="form-label fw-bold">
                Expiration Date
            </label>
            <input 
                type="date" 
                id="expiration-date" 
                name="expiration-date" 
                class="form-control mt-2" 
                value="<?= !empty($result['formatted_expiration_date']) ? DateTime::createFromFormat('m-d-Y', htmlspecialchars($result['formatted_expiration_date']))->format('Y-m-d') : '' ?>"
            >
            <?php if (isset($errors['expiration-date'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['expiration-date'] ?></p>
            <?php endif; ?>
        </div>
        <!-- Supplier -->
        <div class="mb-4">
            <label for="supplier-id" class="form-label fw-bold">
                Supplier
                <span class="txt-danger">*</span>
            </label>
            <!-- Fetch suppliers from database and populate options -->
            <select id="supplier-id" name="supplier-id" class="form-control mt-2" required>
                <?php if ($result_suppliers) : ?>
                    <option value="">--- Select Supplier ---</option>
                    <?php foreach ($result_suppliers as $row) : ?>
                        <option 
                            value="<?= htmlspecialchars($row['id']) ?>"
                            <?= (int) htmlspecialchars($row['id']) === $result['supplier_id'] ? 'selected' : '' ?>
                        >
                            <?= htmlspecialchars($row['name']) ?>
                        </option>
                    <?php endforeach ?>
                <?php elseif (empty($result_suppliers)) : ?>
                    <option value="" selected>No Suppliers Available</option>
                <?php else : ?>
                    <option value="" selected>Error Fetching Data!</option>
                <?php endif ?>
            </select>
            <?php if (isset($errors['supplier-id'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['supplier-id'] ?></p>
            <?php endif; ?>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="panel__login-btn btn btn-success btn-has-icon fw-bold">
                Update
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<!-- Custom Scripts -->
<script src="public/assets/js/customs/backoffice/item-batches.js" defer></script>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>