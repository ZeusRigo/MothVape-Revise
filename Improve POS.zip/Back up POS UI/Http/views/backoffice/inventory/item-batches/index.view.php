<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/modal-archive.php')) ?>
<!-- Page Content -->
<main class="main">
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-2">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <div class="controls">
        <div class="controls__container-left">
            <a href="<?= $homeURI ?>/add" class="btn btn-success btn-has-icon">
                <p>Add Item Batch</p>
                <img src="/assets/images/add-icon.webp" alt="Add Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </a>
            <button 
                class="btn btn-danger btn-has-icon js-control-btn"
                onclick="openModalMultiple(
                    '<?= $tableName ?>',
                    '<?= $homeURI ?>', 
                    'modal-archive'
                )"
            >
                <p>Archive</p>
                <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
        <div class="controls__container-right">
            <div class="controls__search-container">
                <input 
                    type="text"
                    id="search" 
                    class="form-control"
                    placeholder="Search..."
                >
                <button 
                    type="button"
                    class="btn btn-dark btn-has-icon"
                >
                    <img src="/assets/images/search-icon.webp" alt="Search Icon" class="btn__icon btn__icon--invert" loading="lazy">
                </button>
            </div>
        </div>
    </div>
    <!-- Table -->
    <div class="table-container">
        <table class="table">
            <thead class="table__header">
                <tr>
                    <th class="table__cell table__cell--select">
                        <input type="checkbox" id="select-all-checkbox" class="table__select-all-checkbox" onchange="selectAllRows()">
                    </th>
                    <th scope="col" class="table__cell">SKU</th>
                    <th scope="col" class="table__cell">Item</th>
                    <th scope="col" class="table__cell">Batch Number</th>
                    <th scope="col" class="table__cell">Quantity</th>
                    <th scope="col" class="table__cell">Supplier</th>
                    <th scope="col" class="table__cell">Expiration Date</th>
                    <th scope="col" class="table__cell">Status</th>
                    <th scope="col" class="table__cell">Created At</th>
                    <th scope="col" class="table__cell">Modified At</th>
                    <th scope="col" class="table__cell table__cell--actions">Actions</th>
                </tr>
            </thead>
            <tbody class="table__body">
                <?php if (!empty($result)) : ?>
                    <?php foreach ($result as $row) : ?>
                        <?php
                        $quantity = htmlspecialchars($row['quantity'] ?? 0);
                        $lowStockQuantity = htmlspecialchars($row['low_stock_quantity'] ?? 0);
                        $expirationDate = htmlspecialchars($row['expiration_date'] ?? 0);

                        $currentDate = date('Y-m-d');
                        $thresholdDate = date('Y-m-d', strtotime('+7 days'));

                        // Default visibility for all status divs
                        $inStockClass = 'table__status--hidden';
                        $lowStockClass = 'table__status--hidden';
                        $outOfStockClass = 'table__status--hidden';

                        $statusClasses = [];
                        $statusTexts = [];
                        $statusTextClasses = [];
                        $statusIcons = [];
                        $statusIconClasses = [];

                        // Check Out of Stock first (Highest Priority)
                        if ($quantity <= 0) 
                        {
                            $statusClasses[] = 'table__status--danger';
                            $statusTexts[] = 'Out of Stock';
                            $statusTextClasses[] = 'txt-white';
                            $statusIcons[] = 'cancel-icon.webp';
                            $statusIconClasses[] = 'table__status-icon--invert';
                        }
                        // Then check other conditions only if there is stock
                        else 
                        {
                            // Expiration Status
                            if (!empty($expirationDate) && $expirationDate < $currentDate) 
                            {
                                $statusClasses[] = 'table__status--danger';
                                $statusTexts[] = 'Expired';
                                $statusTextClasses[] = 'txt-white';
                                $statusIcons[] = 'cancel-icon.webp';
                                $statusIconClasses[] = 'table__status-icon--invert';
                            } 
                            elseif (!empty($expirationDate) && $expirationDate >= $currentDate && $expirationDate <= $thresholdDate) 
                            {
                                $statusClasses[] = 'table__status--warning';
                                $statusTexts[] = 'Expiring Soon';
                                $statusIcons[] = 'warning-icon.webp';
                            }
                            // Low Stock Status
                            elseif ($quantity < $lowStockQuantity) 
                            {
                                $statusClasses[] = 'table__status--warning';
                                $statusTexts[] = 'Low Stock';
                                $statusIcons[] = 'warning-icon.webp';
                            }
                            // In Stock Status (if no other conditions met)
                            else
                            {
                                $statusClasses[] = 'table__status--success';
                                $statusTexts[] = 'In Stock';
                                $statusTextClasses[] = 'txt-white';
                                $statusIcons[] = 'check-icon.webp';
                                $statusIconClasses[] = 'table__status-icon--invert';
                            }
                        }
                        ?>
                        <tr class="table__row">
                            <td class="table__cell table__cell--select">
                                <input type="checkbox" class="table__select js-table__select" data-id="<?= htmlspecialchars($row['id']) ?>" onchange="selectRow(this)">
                            </td>
                            <td class="table__cell"><?= htmlspecialchars($row['batch_sku']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['item_name']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['batch_number']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['quantity']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['supplier_name']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['expiration_date'] ?? 'N/A') ?></td>
                            <td class="table__cell table__cell--status">
                                <?php foreach ($statusClasses as $index => $class) : ?>
                                    <div class="table__status <?= $class ?>">
                                        <p class="<?= $statusTextClasses[$index] ?>"><?= $statusTexts[$index] ?></p>
                                        <img src="/assets/images/<?= $statusIcons[$index]; ?>" alt="Status Icon" class="table__status-icon <?= $statusIconClasses[$index] ?>" loading="lazy">
                                    </div>
                                <?php endforeach; ?>
                            </td>
                            <td class="table__cell" style="width: 10%"><?= htmlspecialchars($row['created_at']) ?></td>
                            <td class="table__cell" style="width: 10%"><?= htmlspecialchars($row['modified_at']) ?></td>
                            <td class="table__cell table__cell--actions" style="width: 5%">
                                <div class="table__actions-container">
                                    <a href="<?= $homeURI ?>/edit?id=<?= htmlspecialchars($row['id']) ?>" class="btn btn-primary btn-has-icon">
                                        <img src="/assets/images/pencil-icon.webp" alt="Pencil Icon" class="btn__icon btn__icon--invert" loading="lazy">
                                    </a>
                                    <button
                                        class="btn btn-danger btn-has-icon js-table__select"
                                        data-id="<?= htmlspecialchars($row['id']) ?>"
                                        data-action="archive-<?= $dataAction ?>"
                                        onclick="openModalSingle(
                                            '<?= $tableName ?>', 
                                            <?= htmlspecialchars($row['id']) ?>,
                                            '<?= $homeURI ?>', 
                                            'modal-archive'
                                        )"
                                    >
                                        <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="btn__icon btn__icon--invert">
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php endif ?>
            </tbody>
        </table>
    </div>
</main>
<script>
    // Initialize search when the page loads
    document.addEventListener('DOMContentLoaded', function() {
        initializeSearch('search');
    });
</script>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>