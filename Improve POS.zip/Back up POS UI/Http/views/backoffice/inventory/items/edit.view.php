<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100" enctype="multipart/form-data">
        <input type="hidden" name="_method" value="PATCH">
        <input type="hidden" name="id" value="<?= $result['id'] ?>">
        <!-- I. Basic Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">I. Item Information</p>
            <hr class="my-4">
            <!-- SKU -->
            <div class="mb-4">
                <label for="sku" class="form-label fw-bold">
                    SKU
                    <span class="txt-danger">*</span>
                </label>
                <div style="display: flex; align-items: center; gap: 0.5rem">
                    <input 
                        type="text" 
                        id="sku" 
                        name="sku" 
                        class="form-control mt-2 mb-2"
                        placeholder="Auto-generate or manually enter SKU"
                        value="<?= $result['sku'] ?>"
                        maxlength="50"
                        required
                    >
                    <button type="button" class="btn btn-info" onclick="autoGenerateSKU()">Generate</button>
                </div>
                <?php if (isset($errors['sku'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['sku'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Item Name -->
            <div class="mb-4">
                <label for="name" class="form-label fw-bold">
                    Name
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="text"
                    id="name" 
                    name="name" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter item name"
                    value="<?= $result['name'] ?>"
                    required
                >
                <?php if (isset($errors['name'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['name'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Description -->
            <div class="mb-4">
                <label for="description" class="form-label fw-bold">
                    Description
                </label>
                <textarea 
                    id="description"
                    name="description"
                    class="form-control mt-2 mb-2"
                    placeholder="Enter description"
                    maxlength="500"
                    rows="4"
                ><?= $result['description'] ?></textarea>
                <?php if (isset($errors['description'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['description'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Item Category -->
            <div class="mb-4">
                <label for="category-id" class="form-label fw-bold">
                    Category
                </label>
                <!-- Fetch categories from database and populate options -->
                <select id="category-id" name="category-id" class="form-control mt-2">
                    <?php if ($result_itemCategories) : ?>
                        <option value="" <?= $result['category_id'] == '' ? 'selected' : '' ?>>--- Select Category ---</option>
                        <?php foreach ($result_itemCategories as $row) : ?>
                            <option 
                                value="<?= htmlspecialchars($row['id']) ?>"
                                <?= $result['category_id'] == $row['id'] ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($row['name']) ?>
                            </option>
                        <?php endforeach ?>
                    <?php elseif (empty($result_itemCategories)) : ?>
                        <option value="" selected>No Categories Available</option>
                    <?php else : ?>
                        <option value="" selected>Error Fetching Data!</option>
                    <?php endif ?>
                </select>
                <?php if (isset($errors['category-id'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['category-id'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Item Price -->
            <div class="mb-4">
                <label for="price" class="form-label fw-bold">
                    Price
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="number"
                    id="price" 
                    name="price" 
                    class="form-control mt-2 mb-2"
                    placeholder="0.00"
                    value="<?= $result['price'] ?>"
                    step="0.01"
                    required
                >
                <?php if (isset($errors['price'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['price'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Item Image -->
            <div class="mb-4">
                <label for="image-url" class="form-label fw-bold">
                    Image
                </label>
                <!-- Display Current Image -->
                <div class="mb-3">
                    <img id="preview-image" src="<?= htmlspecialchars($result['image_url']) ?>" 
                        alt="Preview Image" class="img-fluid" 
                        style="width: 200px; height: 200px; object-fit: cover;">
                </div>
                <!-- Hidden input to store existing image URL -->
                <input 
                    type="hidden" 
                    id="existing-image-url" 
                    name="existing-image-url" 
                    value="<?= htmlspecialchars($result['image_url'] ?? '') ?>"
                >
                <input 
                    type="file"
                    id="image-url" 
                    name="image-url" 
                    class="form-control mt-2 mb-2"
                    accept="image/jpeg, image/png, image/webp"
                    onchange="previewImage(event)"
                >
                <?php if (isset($errors['image-url'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['image-url'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- II. Inventory Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">II. Inventory Information</p>
            <hr class="my-4">
            <!-- Low Stock Quantity -->
            <div class="mb-4">
                <label for="low-stock-quantity" class="form-label fw-bold">
                    Low Stock Quantity
                </label>
                <input 
                    type="number"
                    id="low-stock-quantity" 
                    name="low-stock-quantity" 
                    class="form-control mt-2 mb-2"
                    placeholder="0"
                    value="<?= $result['low_stock_quantity'] ?>"
                    min="0"
                >
                <?php if (isset($errors['low-stock-quantity'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['low-stock-quantity'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="btn btn-success btn-has-icon fw-bold">
                Update
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<!-- Custom Scripts -->
<script src="/assets/js/customs/backoffice/items.js" defer></script>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>