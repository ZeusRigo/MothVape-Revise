<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container mb-5">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon">
            Back
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- I. Basic Information -->
    <div class="mb-2">
        <p class="fw-bold fs-5">I. Item Information</p>
        <hr class="my-4">
        <!-- SKU -->
        <div class="mb-4">
            <p class="fw-bold">
                SKU:
                <span class="fw-normal"><?= htmlspecialchars($result['sku']) ?></span>
            </p>
        </div>
        <!-- Name -->
        <div class="mb-4">
            <p class="fw-bold">
                Name:
                <span class="fw-normal"><?= htmlspecialchars($result['name'])?></span>
            </p>
        </div>
        <!-- Description -->
        <div class="mb-4">
            <p class="fw-bold">
                Description:
                <span class="fw-normal">
                    <pre><?= htmlspecialchars($result['description']) ?></pre>
                </span>
            </p>
        </div>
        <!-- Item Category -->
        <div class="mb-4">
            <p class="fw-bold">
                Category:
                <span class="fw-normal"><?= htmlspecialchars($result_itemCategory['name'] ?? '')?></span>
            </p>
        </div>
        <!-- Price -->
        <div class="mb-4">
            <p class="fw-bold">
                Price:
                <span class="fw-normal"><?= htmlspecialchars($result['price'])?></span>
            </p>
        </div>
        <!-- Item Image -->
        <div class="mb-4">
            <p class="fw-bold mb-3">Image</p>
            <img src="<?= htmlspecialchars($result['image_url'] ?? '')?>" alt="Item Image" style="height: 200px; object-fit: contain; width: 200px;">
        </div>
    </div>
    <!-- II. Inventory Information -->
    <div class="mb-2">
        <p class="fw-bold fs-5">II. Inventory Information</p>
        <hr class="my-4">
        <!-- Low Stock Quantity -->
        <div class="mb-4">
            <p class="fw-bold">
                Low Stock Quantity:
                <span class="fw-normal"><?= htmlspecialchars($result['low_stock_quantity']) ?></span>
            </p>
        </div>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>