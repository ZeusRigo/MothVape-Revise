<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <input type="hidden" name="_method" value="PATCH">
        <input type="hidden" name="id" value="<?= $result['id'] ?>">
        <!-- I. Basic Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">I. Basic Information</p>
            <hr class="my-4">
            <!-- Supplier Name -->
            <div class="mb-4">
                <label for="name" class="form-label fw-bold">
                    Supplier Name
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter supplier name"
                    value="<?= $result['name'] ?>"
                    maxlength="50"
                    required
                >
                <?php if (isset($errors['name'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['name'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Email Address -->
            <div class="mb-4">
                <label for="email" class="form-label fw-bold">
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    class="form-control mt-2 mb-2"
                    placeholder="e.g., name@example.com"
                    value="<?= $result['email'] ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['email'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['email'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Phone Number -->
            <div class="mb-4">
                <label for="phone-number" class="form-label fw-bold">
                    Phone Number
                </label>
                <input 
                    type="text"
                    id="phone-number" 
                    name="phone-number" 
                    class="form-control mt-2 mb-2"
                    placeholder="+1 (123) 456-7890"
                    value="<?= $result['phone_number'] ?>"
                >
                <?php if (isset($errors['phone-number'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['phone-number'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- II. Address Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">II. Address Information</p>
            <hr class="my-4">
            <!-- Street Address Line 1 -->
            <div class="mb-4">
                <label for="street-address-line1" class="form-label fw-bold">
                    Street Address Line 1
                </label>
                <input 
                    type="text" 
                    id="street-address-line1" 
                    name="street-address-line1" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter first street address"
                    value="<?= $result['street_address_line1'] ?>"
                    maxlength="255"
                >
                <?php if (isset($errors['street-address-line1'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['street-address-line1'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Street Address Line 2-->
            <div class="mb-4">
                <label for="street-address-line2" class="form-label fw-bold">
                    Street Address Line 2
                </label>
                <input 
                    type="text" 
                    id="street-address-line2" 
                    name="street-address-line2" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter second street address"
                    value="<?= $result['street_address_line2'] ?>"
                    maxlength="255"
                >
                <?php if (isset($errors['street-address-line2'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['street-address-line2'] ?></p>
                <?php endif; ?>
            </div>
            <!-- City -->
            <div class="mb-4">
                <label for="city" class="form-label fw-bold">
                    City
                </label>
                <input 
                    type="text"
                    id="city" 
                    name="city" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter city"
                    value="<?= $result['city'] ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['city'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['city'] ?></p>
                <?php endif; ?>
            </div>
            <!-- State -->
            <div class="mb-4">
                <label for="state" class="form-label fw-bold">
                    State
                </label>
                <input 
                    type="text"
                    id="state" 
                    name="state" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter state"
                    value="<?= $result['state'] ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['state'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['state'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Postal Code -->
            <div class="mb-4">
                <label for="postal-code" class="form-label fw-bold">
                    Postal Code
                </label>
                <input 
                    type="text"
                    id="postal-code" 
                    name="postal-code" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter postal code"
                    value="<?= $result['postal_code'] ?>"
                    maxlength="20"
                >
                <?php if (isset($errors['postal-code'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['postal-code'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Country -->
            <div class="mb-4">
                <label for="country" class="form-label fw-bold">
                    Country
                </label>
                <input 
                    type="text"
                    id="country" 
                    name="country" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter country"
                    value="<?= $result['country'] ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['country'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['country'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- III. Additional Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">III. Additional Information</p>
            <hr class="my-4">
            <!-- Notes-->
            <div class="mb-4">
                <label for="notes" class="form-label fw-bold">
                    Notes
                </label>
                <textarea 
                    id="notes"
                    name="notes"
                    class="form-control mt-2 mb-2"
                    placeholder="Enter any additional notes..."
                    maxlength="500"
                    rows="4"
                ><?= $result['notes'] ?></textarea>
                <?php if (isset($errors['notes'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['notes'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="panel__login-btn btn btn-success btn-has-icon fw-bold">
                Update
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>