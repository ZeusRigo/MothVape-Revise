<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container mb-5">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon">
            Back
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- I. Basic Information -->
    <div class="mb-2">
        <p class="fw-bold fs-5">I. Basic Information</p>
        <hr class="my-4">
        <!-- Supplier Name -->
        <div class="mb-4">
            <p class="fw-bold">
                Supplier Name:
                <span class="fw-normal"><?= htmlspecialchars($result['name']) ?></span>
            </p>
        </div>
        <!-- Email Address -->
        <div class="mb-4">
            <p class="fw-bold">
                Email Address:
                <span class="fw-normal"><?= htmlspecialchars($result['email']) ?></span>
            </p>
        </div>
        <!-- Phone Number -->
        <div class="mb-4">
            <p class="fw-bold">
                Phone Number:
                <span class="fw-normal"><?= htmlspecialchars($result['phone_number']) ?></span>
            </p>
        </div>
    </div>
    <!-- II. Address Information -->
    <div class="mb-2">
        <p class="fw-bold fs-5">II. Address Information</p>
        <hr class="my-4">
        <!-- Street Address Line 1 -->
        <div class="mb-4">
            <p class="fw-bold">
                Street Address Line 1:
                <span class="fw-normal"><?= htmlspecialchars($result['street_address_line1']) ?></span>
            </p>
        </div>
        <!-- Street Address Line 2 -->
        <div class="mb-4">
            <p class="fw-bold">
                Street Address Line 2:
                <span class="fw-normal"><?= htmlspecialchars($result['street_address_line2']) ?></span>
            </p>
        </div>
        <!-- City -->
        <div class="mb-4">
            <p class="fw-bold">
                City:
                <span class="fw-normal"><?= htmlspecialchars($result['city']) ?></span>
            </p>
        </div>
        <!-- State -->
        <div class="mb-4">
            <p class="fw-bold">
                State:
                <span class="fw-normal"><?= htmlspecialchars($result['state']) ?></span>
            </p>
        </div>
        <!-- Postal Code -->
        <div class="mb-4">
            <p class="fw-bold">
                Postal Code:
                <span class="fw-normal"><?= htmlspecialchars($result['postal_code']) ?></span>
            </p>
        </div>
        <!-- Country -->
        <div class="mb-4">
            <p class="fw-bold">
                Country:
                <span class="fw-normal"><?= htmlspecialchars($result['country']) ?></span>
            </p>
        </div>
    </div>
    <!-- III. Additional Information -->
    <div class="mb-2">
        <p class="fw-bold fs-5">III. Additional Information</p>
        <hr class="my-4">
        <!-- Notes -->
        <div class="mb-4">
            <p class="fw-bold">
                Notes:
                <span class="fw-normal">
                    <pre><?= htmlspecialchars($result['notes']) ?></pre>
                </span>
            </p>
        </div>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>