<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'Backoffice' ?></title>
    
    <?php
    if (!defined('PUBLIC_PATH')) {
        define('PUBLIC_PATH', dirname(dirname(dirname(dirname(__DIR__)))) . '/public');
    }
    
    $combinedCssFile = PUBLIC_PATH . '/assets/css/combined.min.css';
    $combinedJsFile = PUBLIC_PATH . '/assets/js/combined.min.js';
    
    // Always include original files for now
    ?>
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/customs/backoffice/main.css">
    
    <?php if (file_exists($combinedCssFile)): ?>
        <!-- Combined CSS file -->
        <link rel="stylesheet" href="/assets/css/combined.min.css?v=<?= filemtime($combinedCssFile) ?>">
    <?php endif; ?>
    
    <!-- Original JS files -->
    <script src="/assets/js/utilities/tables.js" defer></script>
    <script src="/assets/js/utilities/forms.js" defer></script>
    <script src="/assets/js/utilities/search.js" defer></script>
    <script src="/assets/js/customs/backoffice/partials/nav.js" defer></script>
    <script src="/assets/js/customs/backoffice/partials/modals.js" defer></script>
    
    <?php if (file_exists($combinedJsFile)): ?>
        <!-- Combined JS file -->
        <script src="/assets/js/combined.min.js?v=<?= filemtime($combinedJsFile) ?>" defer></script>
    <?php endif; ?>
</head>
<body>