<div id="modal-restore" class="modal">
    <div class="modal__content">
        <div class="modal__head">
            <p class="modal__title txt-white fw-bold">Confirm Restore</p>
        </div>
        <div class="modal__body">
            <p class="modal__message-txt">Are you sure you want to restore the following item(s)?</p>
            <div class="modal__information">
                <ul id="modal-item-list" class="modal__item-list">
                    <!-- The selected items will be dynamically appended here -->
                </ul>
            </div>
            <div class="modal__actions">
                <button id="modal-close-btn" class="btn btn-dark btn-has-icon">
                    <p class="btn__txt">Cancel</p>
                    <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert">
                </button>
                <form action="/backoffice/archives/restore" method="POST">
                    <input type="hidden" id="table-name" name="table-name">
                    <input type="hidden" id="row-id" name="row-id">
                    <input type="hidden" id="home-uri" name="home-uri">
                    <button id="modal-confirm-btn" class="btn btn-primary btn-has-icon">
                        <p class="btn__txt">Restore</p>
                        <img src="/assets/images/restore-icon.webp" alt="Restore Icon" class="btn__icon btn__icon--invert">
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>