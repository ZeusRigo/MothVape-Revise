<?php
// Get user permissions
$permissions = $_SESSION['user']['permissions'] ?? [];
$isAdmin = $_SESSION['user']['is_admin'] ?? false;

// Check individual permissions
$canManageSales = $isAdmin || ($permissions['manage_sales'] ?? false);
$canManageInventory = $isAdmin || ($permissions['manage_inventory'] ?? false);
$canManageUsers = $isAdmin || ($permissions['manage_users'] ?? false);

// Check if they can access backoffice at all
$canAccessBackoffice = $isAdmin || $canManageSales || $canManageInventory || $canManageUsers;

// Redirect to POS if they don't have backoffice access
if (!$canAccessBackoffice) {
    header('location: /pos');
    exit();
}
?>

<!-- Add this before the sidebar -->
<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<!-- Sidebar -->
<aside class="sidebar">
    <div class="sidebar__container-top">
        <img src="/assets/images/moth-vape-logo.webp" alt="Moth Vape Logo" class="sidebar__logo" loading="lazy">
        <div class="sidebar__date-time-container">
            <span class="txt-white fw-bold">Date:</span>
            <span id="date-txt" class="txt-white">00/00/0000</span>
        </div>
        <div class="sidebar__date-time-container">
            <span class="txt-white fw-bold">Time:</span>
            <span id="time-txt" class="txt-white">00:00:00 XX</span>
        </div>
    </div>
    <div class="sidebar__container-center">
        <nav class="sidebar__nav">
            <ul class="sidebar__nav-menu">
                <!-- Dashboard - show if they have any management permission -->
                <?php if ($canManageSales || $canManageInventory || $canManageUsers) : ?>
                    <li class="sidebar__nav-menu-item <?= (urlIs('/backoffice') || urlIs('/backoffice/dashboard')) ? 'active' : '' ?>">
                        <a href="/backoffice/dashboard" class="sidebar__nav-menu-item-link">
                            <img src="/assets/images/home-icon.webp" alt="Home Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                            Dashboard
                        </a>
                    </li>
                <?php endif; ?>

                <!-- Sales Menu - only show if they have sales permission -->
                <?php if ($canManageSales) : ?>
                    <li class="sidebar__nav-menu-item">
                        <button class="sidebar__nav-menu-item-btn" onclick="toggleSubmenu(this)">
                            <img src="/assets/images/money-icon.webp" alt="Money Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                            <p class="sidebar__nav-menu-item-txt">Sales</p>
                            <img src="/assets/images/arrow-filled-right-icon.webp" alt="Arrow Right Icon" class="sidebar__nav-menu-item-btn-icon" loading="lazy">
                        </button>
                        <ul class="sidebar__nav-submenu
                            <?= 
                            (
                                urlIs('/backoffice/sales/order-history') || 
                                urlIs('/backoffice/sales/sales-report') || 
                                urlIs('/backoffice/sales/payment-methods')
                            ) ? 'show show-active' : '' ?>
                        ">
                            <div>
                                <!-- Order History -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/sales/order-history') ? 'active' : '' ?>">
                                    <a href="/backoffice/sales/order-history" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/clock-icon.webp" alt="Clock Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Order History</p>
                                    </a>
                                </li>
                                <!-- Sales Report -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/sales/sales-report') ? 'active' : '' ?>">
                                    <a href="/backoffice/sales/sales-report" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/stats-icon.webp" alt="Stats Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Sales Report</p>
                                    </a>
                                </li>
                                <!-- Payment Methods -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/sales/payment-methods') ? 'active' : '' ?>">
                                    <a href="/backoffice/sales/payment-methods" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/money-icon.webp" alt="Money Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Payment Methods</p>
                                    </a>
                                </li>
                            </div>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- Inventory Menu - only show if they have inventory permission -->
                <?php if ($canManageInventory) : ?>
                    <li class="sidebar__nav-menu-item">
                        <button class="sidebar__nav-menu-item-btn" onclick="toggleSubmenu(this)">
                            <img src="/assets/images/package-icon.webp" alt="Package Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                            <p class="sidebar__nav-menu-item-txt">Inventory</p>
                            <img src="/assets/images/arrow-filled-right-icon.webp" alt="Arrow Right Icon" class="sidebar__nav-menu-item-btn-icon" loading="lazy">
                        </button>
                        <ul class="sidebar__nav-submenu
                            <?= 
                            (
                                urlIs('/backoffice/inventory/items') || 
                                urlIs('/backoffice/inventory/item-batches') || 
                                urlIs('/backoffice/inventory/item-categories') ||
                                urlIs('/backoffice/inventory/suppliers')
                            ) ? 'show show-active' : '' ?>
                        ">
                            <div>
                                <!--Items -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/inventory/items') ? 'active' : '' ?>">
                                    <a href="/backoffice/inventory/items" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/package-icon.webp" alt="Package Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Items</p>
                                    </a>
                                </li>
                                <!--Item Batches -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/inventory/item-batches') ? 'active' : '' ?>">
                                    <a href="/backoffice/inventory/item-batches" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/package-icon.webp" alt="Package Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Item Batches</p>
                                    </a>
                                </li>
                                <!-- Item Categories -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/inventory/item-categories') ? 'active' : '' ?>">
                                    <a href="/backoffice/inventory/item-categories" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/package-icon.webp" alt="Package Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Item Categories</p>
                                    </a>
                                </li>
                                <!-- Suppliers -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/inventory/suppliers') ? 'active' : '' ?>">
                                    <a href="/backoffice/inventory/suppliers" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/package-icon.webp" alt="Package Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Suppliers</p>
                                    </a>
                                </li>
                            </div>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- Users Menu - only show if they have users permission -->
                <?php if ($canManageUsers) : ?>
                    <li class="sidebar__nav-menu-item">
                        <button class="sidebar__nav-menu-item-btn" onclick="toggleSubmenu(this)">
                            <img src="/assets/images/users-icon.webp" alt="Users Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                            <p class="sidebar__nav-menu-item-txt">Users</p>
                            <img src="/assets/images/arrow-filled-right-icon.webp" alt="Arrow Right Icon" class="sidebar__nav-menu-item-btn-icon" loading="lazy">
                        </button>
                        <ul class="sidebar__nav-submenu
                            <?= 
                            (
                                urlIs('/backoffice/users/employees') || 
                                urlIs('/backoffice/users/employee-shifts') || 
                                urlIs('/backoffice/users/roles')
                            ) ? 'show show-active' : '' ?>
                        ">
                            <div>
                                <!-- Employees -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/users/employees') ? 'active' : '' ?>">
                                    <a href="/backoffice/users/employees" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/person-id-icon.webp" alt="Person ID Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Employees</p>
                                    </a>
                                </li>
                                <!-- Employee Shifts -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/users/employee-shifts') ? 'active' : '' ?>">
                                    <a href="/backoffice/users/employee-shifts" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/clock-icon.webp" alt="Clock Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Employee Shifts</p>
                                    </a>
                                </li>
                                <!-- Roles -->
                                <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/users/roles') ? 'active' : '' ?>">
                                    <a href="/backoffice/users/roles" class="sidebar__nav-menu-item-link">
                                        <img src="/assets/images/gear-icon.webp" alt="Gear Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                        <p class="sidebar__nav-menu-item-txt">Roles</p>
                                    </a>
                                </li>
                            </div>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- Archives Menu - show if they have any management permission -->
                <?php if ($canManageSales || $canManageInventory || $canManageUsers) : ?>
                    <li class="sidebar__nav-menu-item">
                        <button class="sidebar__nav-menu-item-btn" onclick="toggleSubmenu(this)">
                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                            <p class="sidebar__nav-menu-item-txt">Archives</p>
                            <img src="/assets/images/arrow-filled-right-icon.webp" alt="Arrow Right Icon" class="sidebar__nav-menu-item-btn-icon" loading="lazy">
                        </button>
                        <ul class="sidebar__nav-submenu
                            <?= 
                            (
                                urlIs('/backoffice/archives/employees') ||
                                urlIs('/backoffice/archives/employee-shifts') || 
                                urlIs('/backoffice/archives/items') ||
                                urlIs('/backoffice/archives/item-batches') ||
                                urlIs('/backoffice/archives/item-categories') ||
                                urlIs('/backoffice/archives/order-history') ||
                                urlIs('/backoffice/archives/payment-methods') ||
                                urlIs('/backoffice/archives/roles') ||
                                urlIs('/backoffice/archives/suppliers')
                            ) ? 'show show-active' : '' ?>
                        ">
                            <div>
                                <!-- Show archive items based on permissions -->
                                <?php if ($canManageUsers) : ?>
                                    <!-- Employees archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/employees') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/employees" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Employees</p>
                                        </a>
                                    </li>

                                    <!-- Employee Shifts archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/employee-shifts') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/employee-shifts" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Employee Shifts</p>
                                        </a>
                                    </li>

                                    <!-- Roles archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/roles') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/roles" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Roles</p>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if ($canManageInventory) : ?>
                                    <!-- Items archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/items') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/items" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Items</p>
                                        </a>
                                    </li>

                                    <!-- Item Batches archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/item-batches') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/item-batches" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Item Batches</p>
                                        </a>
                                    </li>

                                    <!-- Item Categories archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/item-categories') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/item-categories" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Item Categories</p>
                                        </a>
                                    </li>

                                    <!-- Suppliers archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/suppliers') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/suppliers" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Suppliers</p>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if ($canManageSales) : ?>
                                    <!-- Order History archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/order-history') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/order-history" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Order History</p>
                                        </a>
                                    </li>

                                    <!-- Payment Methods archive -->
                                    <li class="sidebar__nav-submenu-item <?= urlIs('/backoffice/archives/payment-methods') ? 'active' : '' ?>">
                                        <a href="/backoffice/archives/payment-methods" class="sidebar__nav-menu-item-link">
                                            <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                                            <p class="sidebar__nav-menu-item-txt">Payment Methods</p>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </div>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- Enter POS -->
                <li class="sidebar__nav-menu-item">
                    <a href="/pos" class="sidebar__nav-menu-item-link">
                        <img src="/assets/images/money-icon.webp" alt="Money Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                        Enter POS
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    <div class="sidebar__container-bottom">
        <form action="/login" method="POST" class="w-100">
            <input type="hidden" name="_method" value="DELETE">
    
            <button class="btn btn-danger btn-has-icon fw-bold w-100">
                <img src="/assets/images/logout-icon.webp" alt="Logout Icon" class="btn__icon btn__icon--invert" loading="lazy">
                Log Out
            </button>
        </form>
    </div>
</aside>

<!-- Topbar -->
<header class="topbar">
    <button class="topbar__toggle-btn" onclick="toggleSidebar()">
        <img src="/assets/images/hamburger-icon.webp" alt="Hamburger Icon" class="topbar__icon" loading="lazy">
    </button>
    <img src="/assets/images/bell-icon.webp" alt="Bell Icon" class="topbar__icon">
    <div class="topbar__user-group">
        <img src="/assets/images/user-profile-icon.webp" alt="Bell Icon" class="topbar__icon" loading="lazy">
        <p class="topbar__user-username-txt txt-white fw-bold">
        <?php

        if (isset($_SESSION['user']) && isset($_SESSION['user']['is_admin']) && $_SESSION['user']['is_admin'] == true)
        {
            echo "Admin";
        }
        else
        {
            if (isset($_SESSION['user']) && isset($_SESSION['user']['user_id']))
            {
                $employee = \Core\App::resolve(\Core\Database::class)
                    ->query('SELECT * FROM employees WHERE user_id = :user_id AND archived_at IS NULL', [
                    ':user_id' => $_SESSION['user']['user_id']
                ])->find();
    
                if ($employee)
                {
                    echo htmlspecialchars($employee['first_name'] . " " .$employee['last_name']);
                }
                else
                {
                    echo "Guest";
                }
            }
            else
            {
                echo "Guest";
            }
        }

        ?>
        </p>
    </div>
</header>