<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/modal-archive.php')) ?>
<!-- Page Content -->
<main class="main">
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-2">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <div class="controls">
        <div class="controls__container-left">
        </div>
        <div class="controls__container-right">
            <div class="controls__search-container">
                <input 
                    type="text"
                    id="search" 
                    class="form-control"
                    placeholder="Search..."
                >
                <button 
                    type="button"
                    class="btn btn-dark btn-has-icon"
                >
                    <img src="/assets/images/search-icon.webp" alt="Search Icon" class="btn__icon btn__icon--invert" loading="lazy">
                </button>
            </div>
        </div>
    </div>
    <!-- Table -->
    <div class="table-container">
        <table class="table">
            <thead class="table__header">
                <tr>
                    <th class="table__cell table__cell--select">
                        <input type="checkbox" id="select-all-checkbox" class="table__select-all-checkbox" onchange="selectAllRows()">
                    </th>
                    <th scope="col" class="table__cell">Reference Number</th>
                    <th scope="col" class="table__cell">Customer Name</th>
                    <th scope="col" class="table__cell">Cashier</th>
                    <th scope="col" class="table__cell">Total Price</th>
                    <th scope="col" class="table__cell">Payment Amount</th>
                    <th scope="col" class="table__cell">Created At</th>
                    <th scope="col" class="table__cell table__cell--actions">Actions</th>
                </tr>
            </thead>
            <tbody class="table__body">
                <?php if (!empty($result)) : ?>
                    <?php foreach ($result as $row) : ?>
                        <tr class="table__row">
                            <td class="table__cell table__cell--select">
                                <input type="checkbox" class="table__select js-table__select" data-id="<?= htmlspecialchars($row['id']) ?>" onchange="selectRow(this)">
                            </td>
                            <td class="table__cell"><?= htmlspecialchars($row['reference_number']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['customer_name'] ?? 'N/A') ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['employee_name'] ?? 'N/A') ?></td>
                            <td class="table__cell">&#x20B1;<?= htmlspecialchars($row['total_price']) ?></td>
                            <td class="table__cell">&#x20B1;<?= htmlspecialchars($row['payment_amount']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['created_at']) ?></td>
                            <td class="table__cell table__cell--actions">
                                <div class="table__actions-container">
                                    <a href="<?= $homeURI ?>/show?id=<?= htmlspecialchars($row['id']) ?>" class="btn btn-dark btn-has-icon">
                                        <img src="/assets/images/eye-icon.webp" alt="Eye Icon" class="btn__icon btn__icon--invert" loading="lazy">
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php endif ?>
            </tbody>
        </table>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        initializeSearch('search');
    });
</script>