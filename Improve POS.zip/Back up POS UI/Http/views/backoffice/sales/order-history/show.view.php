<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container mb-5">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon">
            Back
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Sales Invoice -->
    <div class="mb-2">
        <p class="fw-bold fs-5">Sales Invoice</p>
        <hr class="my-4">
        <!-- Reference Number -->
        <div class="mb-4">
            <p class="fw-bold">
                Reference No. #:
                <span class="fw-normal"><?= htmlspecialchars($result['reference_number']) ?></span>
            </p>
        </div>
        <!-- Date & Time -->
        <div class="mb-4">
            <p class="fw-bold">
                Date & Time:
                <span class="fw-normal"><?= htmlspecialchars($result['created_at']) ?></span>
            </p>
        </div>
        <!-- Payment Method -->
        <div class="mb-4">
            <p class="fw-bold">
                Payment Method:
                <span class="fw-normal"><?= htmlspecialchars($result['payment_method']) ?></span>
            </p>
        </div>
        <!-- Cashier: -->
        <div class="mb-4">
            <p class="fw-bold">
                Cashier:
                <span class="fw-normal"><?= htmlspecialchars($result['employee_name'] ?? 'N/A') ?></span>
            </p>
        </div>
        <!-- Customer Name: -->
        <div class="mb-4">
            <p class="fw-bold">
                Customer Name:
                <span class="fw-normal"><?= htmlspecialchars($result['customer_name'] ?? 'N/A') ?></span>
            </p>
        </div>
    </div>
    <!-- Purchased Items -->
    <div class="mb-5">
        <p class="fw-bold fs-5">Purchased Items</p>
        <hr class="my-4">
        <!-- Table -->
        <div class="table-container">
            <table class="table">
                <thead class="table__header">
                    <tr>
                        <th scope="col" class="table__cell">SKU</th>
                        <th scope="col" class="table__cell">Batch Number</th>
                        <th scope="col" class="table__cell">Name</th>
                        <th scope="col" class="table__cell">Category</th>
                        <th scope="col" class="table__cell">Price</th>
                        <th scope="col" class="table__cell">Qty</th>
                        <th scope="col" class="table__cell">Total</th>
                    </tr>
                </thead>
                <tbody class="table__body">
                    <?php if (!empty($result_orderItems)) : ?>
                        <?php foreach ($result_orderItems as $row) : ?>
                            <tr class="table__row">
                                <td class="table__cell"><?= htmlspecialchars($row['sku']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($row['batch_number']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($row['name']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($row['category'] ?? '') ?></td>
                                <td class="table__cell">&#x20B1;<?= number_format(htmlspecialchars($row['price']), 2) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($row['quantity']) ?></td>

                                <td class="table__cell">&#x20B1;<?= number_format(htmlspecialchars($row['price'] * $row['quantity']), 2) ?></td>
                            </tr>
                        <?php endforeach ?>
                    <?php endif ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Price Breakdown -->
    <div class="mb-2">
        <p class="fw-bold fs-5">Price Breakdown</p>
        <hr class="my-4">
        <!-- Payment Amount -->
        <div class="mb-4">
            <p class="fw-bold">
                Payment Amount:
                <span class="fw-normal">&#x20B1;<?= htmlspecialchars($result['payment_amount']) ?></span>
            </p>
        </div>
        <!-- Subtotal -->
        <div class="mb-4">
            <p class="fw-bold">
                Subtotal:
                <span class="fw-normal">₱<?= number_format($result['price_breakdown']['subtotal'], 2) ?></span>
            </p>
        </div>
        <!-- Discount -->
        <div class="mb-4">
            <p class="fw-bold">
                Discount (<?= number_format($result['discount_percentage'] ?? 0) ?>%):
                <span class="fw-normal">-₱<?= number_format($result['price_breakdown']['discount'], 2) ?></span>
            </p>
        </div>
        <!-- Price Before VAT -->
        <div class="mb-4">
            <p class="fw-bold">
                Price Before VAT:
                <span class="fw-normal">₱<?= number_format($result['price_breakdown']['price_before_vat'], 2) ?></span>
            </p>
        </div>
        <!-- VAT (12%) -->
        <div class="mb-4">
            <p class="fw-bold">
                VAT (12%):
                <span class="fw-normal">₱<?= number_format($result['price_breakdown']['vat'], 2) ?></span>
            </p>
        </div>
        <!-- Total Amount -->
        <div class="mb-4">
            <p class="fw-bold fs-5">
                Total Amount:
                <span class="fw-normal">₱<?= number_format($result['price_breakdown']['total_amount'], 2) ?></span>
            </p>
        </div>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>