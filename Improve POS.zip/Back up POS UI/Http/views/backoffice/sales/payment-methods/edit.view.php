<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <input type="hidden" name="_method" value="PATCH">
        <input type="hidden" name="id" value="<?= $result['id'] ?>">
        <div class="mb-3">
            <label for="name" class="form-label fw-bold">
                Name
                <span class="txt-danger">*</span>
            </label>
            <input 
                type="text" 
                id="name" 
                name="name" 
                class="form-control mt-2 mb-2"
                placeholder="Enter payment method name"
                value="<?= htmlspecialchars($result['name']) ?>"
                maxlength="50"
                required
            >
            <?php if (isset($errors['name'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['name'] ?></p>
            <?php endif; ?>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="panel__login-btn btn btn-success btn-has-icon fw-bold">
                Update
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>