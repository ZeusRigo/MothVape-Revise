<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/modal-archive.php')) ?>
<!-- Page Content -->
<main class="main">
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-2">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <div class="controls">
        <div class="controls__container-left">
            <!-- Add period tabs -->
            <div class="period-tabs">
                <a href="<?= $homeURI ?>?period=all<?= $searchTerm ? "&search={$searchTerm}" : "" ?>" 
                   class="btn <?= ($period === 'all') ? 'btn-dark' : 'btn-outline-dark' ?>">All Time</a>
                <a href="<?= $homeURI ?>?period=daily<?= $searchTerm ? "&search={$searchTerm}" : "" ?>" 
                   class="btn <?= ($period === 'daily') ? 'btn-dark' : 'btn-outline-dark' ?>">Daily</a>
                <a href="<?= $homeURI ?>?period=weekly<?= $searchTerm ? "&search={$searchTerm}" : "" ?>" 
                   class="btn <?= ($period === 'weekly') ? 'btn-dark' : 'btn-outline-dark' ?>">Weekly</a>
                <a href="<?= $homeURI ?>?period=monthly<?= $searchTerm ? "&search={$searchTerm}" : "" ?>" 
                   class="btn <?= ($period === 'monthly') ? 'btn-dark' : 'btn-outline-dark' ?>">Monthly</a>
                <a href="<?= $homeURI ?>?period=annual<?= $searchTerm ? "&search={$searchTerm}" : "" ?>" 
                   class="btn <?= ($period === 'annual') ? 'btn-dark' : 'btn-outline-dark' ?>">Annual</a>
            </div>
        </div>
        <div class="controls__container-right">
            <form method="GET" class="controls__search-container">
                <!-- Add hidden period input to maintain period when searching -->
                <input type="hidden" name="period" value="<?= htmlspecialchars($period) ?>">
                <input 
                    type="text"
                    id="search" 
                    name="search" 
                    class="form-control mt-2 mb-2"
                    placeholder="Search"
                    value="<?= htmlspecialchars($searchTerm ?? '') ?>"
                >
                <button 
                    type="submit"
                    class="btn btn-dark btn-has-icon"
                >
                    <img src="/assets/images/search-icon.webp" alt="Search Icon" class="btn__icon btn__icon--invert" loading="lazy">
                </button>
            </form>
        </div>
    </div>
    <!-- Table -->
    <div class="table-container">
        <table class="table">
            <thead class="table__header">
                <tr>
                    <th scope="col" class="table__cell">
                        <?php if ($period === 'monthly'): ?>
                            Month
                        <?php elseif ($period === 'annual'): ?>
                            Year
                        <?php else: ?>
                            Date
                        <?php endif; ?>
                    </th>
                    <th scope="col" class="table__cell">No. of Transactions</th>
                    <th scope="col" class="table__cell">Total Sales</th>
                    <th scope="col" class="table__cell table__cell--actions">Actions</th>
                </tr>
            </thead>
            <tbody class="table__body">
                <?php if (!empty($result)) : ?>
                    <?php foreach ($result as $row) : ?>
                        <tr class="table__row">
                            <td class="table__cell">
                                <?php if ($period === 'weekly'): ?>
                                    <?= date('F j, Y', strtotime($row['start_date'])) ?> to 
                                    <?= date('F j, Y', strtotime($row['end_date'])) ?>
                                <?php elseif ($period === 'monthly'): ?>
                                    <?= date('F Y', strtotime($row['date'])) ?>
                                <?php elseif ($period === 'annual'): ?>
                                    <?= $row['date'] ?>
                                <?php else: ?>
                                    <?= date('F j, Y', strtotime($row['date'])) ?>
                                <?php endif; ?>
                            </td>
                            <td class="table__cell">
                                <?= number_format($row['transaction_count']) ?>
                            </td>
                            <td class="table__cell">
                                &#x20B1;<?= number_format($row['total_sales'], 2) ?>
                            </td>
                            <td class="table__cell table__cell--actions">
                                <div class="table__actions-container">
                                    <a href="<?= $homeURI ?>/show?period=<?= $period ?>&<?= $period === 'weekly' ? 
                                        "start_date={$row['start_date']}&end_date={$row['end_date']}" : 
                                        "date={$row['date']}" ?>" 
                                       class="btn btn-dark btn-has-icon">
                                        <img src="/assets/images/eye-icon.webp" 
                                             alt="View Details" 
                                             class="btn__icon btn__icon--invert" 
                                             loading="lazy">
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php endif ?>
            </tbody>
            <tfoot class="table__footer">
                <tr>
                    <td class="table__cell"><strong>Total</strong></td>
                    <td class="table__cell">
                        <strong>
                            <?= number_format(array_sum(array_column($result, 'transaction_count'))) ?>
                        </strong>
                    </td>
                    <td class="table__cell">
                        <strong>
                            &#x20B1;<?= number_format(array_sum(array_column($result, 'total_sales')), 2) ?>
                        </strong>
                    </td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>