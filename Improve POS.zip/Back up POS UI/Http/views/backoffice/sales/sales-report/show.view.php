<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container mb-5">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon">
            Back
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
        <!-- Add Download PDF button -->
        <a href="<?= $homeURI ?>/download-pdf?period=<?= $period ?><?= isset($date) ? "&date={$date}" : "" ?><?= isset($start_date) ? "&start_date={$start_date}&end_date={$end_date}" : "" ?>" 
           class="btn btn-primary btn-has-icon">
            <p>Download PDF</p>
            <img src="/assets/images/download-icon.webp" alt="Download Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Period Information -->
    <div class="mb-2">
        <p class="fw-bold fs-5">Period Information</p>
        <hr class="my-4">
        <!-- Period Type -->
        <div class="mb-4">
            <p class="fw-bold">
                Period Type:
                <span class="fw-normal"><?= ucfirst(htmlspecialchars($period)) ?></span>
            </p>
        </div>
        <!-- Date Range -->
        <div class="mb-4">
            <p class="fw-bold">
                Date Range:
                <span class="fw-normal">
                    <?php if ($period === 'weekly'): ?>
                        <?= date('F j, Y', strtotime($start_date)) ?> to 
                        <?= date('F j, Y', strtotime($end_date)) ?>
                    <?php elseif ($period === 'monthly'): ?>
                        <?= date('F Y', strtotime($date)) ?>
                    <?php elseif ($period === 'annual'): ?>
                        <?= date('Y', strtotime($date)) ?>
                    <?php else: ?>
                        <?= date('F j, Y', strtotime($date)) ?>
                    <?php endif; ?>
                </span>
            </p>
        </div>
        <!-- Summary Statistics -->
        <div class="mb-4">
            <p class="fw-bold">
                Number of Transactions:
                <span class="fw-normal"><?= number_format($summary['transaction_count']) ?></span>
            </p>
        </div>
        <div class="mb-4">
            <p class="fw-bold">
                Total Sales:
                <span class="fw-normal">₱<?= number_format($summary['total_sales'], 2) ?></span>
            </p>
        </div>
    </div>

    <?php if ($daily_breakdown): ?>
    <!-- Daily/Monthly Breakdown -->
    <div class="mb-5">
        <p class="fw-bold fs-5">
            <?php 
            if ($period === 'monthly') {
                echo 'Daily';
            } elseif ($period === 'annual') {
                echo 'Monthly';
            } elseif ($period === 'weekly') {
                echo 'Weekly';
            }
            ?> Breakdown
        </p>
        <hr class="my-4">
        <div class="table-container">
            <table class="table">
                <thead class="table__header">
                    <tr>
                        <th scope="col" class="table__cell">
                            <?php if ($period === 'monthly'): ?>
                                Date
                            <?php elseif ($period === 'annual'): ?>
                                Month
                            <?php elseif ($period === 'weekly'): ?>
                                Day
                            <?php endif; ?>
                        </th>
                        <th scope="col" class="table__cell">No. of Transactions</th>
                        <th scope="col" class="table__cell">Total Sales</th>
                    </tr>
                </thead>
                <tbody class="table__body">
                    <?php if ($period === 'annual'): ?>
                        <?php 
                        // Create array for all months
                        $months = array_fill(1, 12, [
                            'transaction_count' => 0,
                            'total_sales' => 0
                        ]);
                        
                        // Fill in actual data
                        foreach ($daily_breakdown as $day) {
                            $months[$day['period_num']] = $day;
                        }
                        
                        // Display all months
                        foreach ($months as $month_num => $data): 
                        ?>
                            <tr class="table__row">
                                <td class="table__cell">
                                    <?= date('F', mktime(0, 0, 0, $month_num, 1)) ?>
                                </td>
                                <td class="table__cell">
                                    <?= number_format($data['transaction_count']) ?>
                                </td>
                                <td class="table__cell">
                                    ₱<?= number_format($data['total_sales'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php elseif ($period === 'weekly'): ?>
                        <?php 
                        // Create array for all days of the week
                        $days = array_fill(1, 7, [
                            'transaction_count' => 0,
                            'total_sales' => 0,
                            'date' => null
                        ]);
                        
                        // Fill in actual data
                        foreach ($daily_breakdown as $day) {
                            $dayNum = $day['period_num'];
                            $days[$dayNum] = $day;
                        }
                        
                        // Day names
                        $dayNames = [
                            1 => 'Sunday',
                            2 => 'Monday',
                            3 => 'Tuesday',
                            4 => 'Wednesday',
                            5 => 'Thursday',
                            6 => 'Friday',
                            7 => 'Saturday'
                        ];
                        
                        // Display all days
                        foreach ($days as $dayNum => $data): 
                        ?>
                            <tr class="table__row">
                                <td class="table__cell">
                                    <?= $dayNames[$dayNum] ?>
                                    <?php if ($data['date']): ?>
                                        (<?= date('M j', strtotime($data['date'])) ?>)
                                    <?php endif; ?>
                                </td>
                                <td class="table__cell">
                                    <?= number_format($data['transaction_count']) ?>
                                </td>
                                <td class="table__cell">
                                    ₱<?= number_format($data['total_sales'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <?php foreach ($daily_breakdown as $day): ?>
                            <tr class="table__row">
                                <td class="table__cell">
                                    <?= date('F j, Y', strtotime($day['date'])) ?>
                                </td>
                                <td class="table__cell">
                                    <?= number_format($day['transaction_count']) ?>
                                </td>
                                <td class="table__cell">
                                    ₱<?= number_format($day['total_sales'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
                <tfoot class="table__footer">
                    <tr>
                        <td class="table__cell"><strong>Total</strong></td>
                        <td class="table__cell">
                            <strong><?= number_format(array_sum(array_column($daily_breakdown, 'transaction_count'))) ?></strong>
                        </td>
                        <td class="table__cell">
                            <strong>₱<?= number_format(array_sum(array_column($daily_breakdown, 'total_sales')), 2) ?></strong>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- Products Sold Summary -->
    <div class="mb-5">
        <p class="fw-bold fs-5">Products Sold Summary</p>
        <hr class="my-4">
        <!-- Table -->
        <div class="table-container">
            <table class="table">
                <thead class="table__header">
                    <tr>
                        <th scope="col" class="table__cell">Product Name</th>
                        <th scope="col" class="table__cell">Category</th>
                        <th scope="col" class="table__cell">Quantity Sold</th>
                        <th scope="col" class="table__cell">Unit Price</th>
                        <th scope="col" class="table__cell">Total Sales</th>
                    </tr>
                </thead>
                <tbody class="table__body">
                    <?php if (!empty($products_sold)) : ?>
                        <?php foreach ($products_sold as $product) : ?>
                            <tr class="table__row">
                                <td class="table__cell"><?= htmlspecialchars($product['name']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($product['category']) ?></td>
                                <td class="table__cell"><?= number_format($product['quantity_sold']) ?></td>
                                <td class="table__cell">₱<?= number_format($product['unit_price'], 2) ?></td>
                                <td class="table__cell">₱<?= number_format($product['total_sales'], 2) ?></td>
                            </tr>
                        <?php endforeach ?>
                    <?php endif ?>
                </tbody>
                <tfoot class="table__footer">
                    <tr>
                        <td colspan="2" class="table__cell"><strong>Total</strong></td>
                        <td class="table__cell">
                            <strong><?= number_format(array_sum(array_column($products_sold, 'quantity_sold'))) ?></strong>
                        </td>
                        <td class="table__cell"></td>
                        <td class="table__cell">
                            <strong>₱<?= number_format(array_sum(array_column($products_sold, 'total_sales')), 2) ?></strong>
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- Top Selling Products -->
    <div class="mb-2">
        <p class="fw-bold fs-5">Top Selling Products</p>
        <hr class="my-4">
        <div class="table-container">
            <table class="table">
                <thead class="table__header">
                    <tr>
                        <th scope="col" class="table__cell">Rank</th>
                        <th scope="col" class="table__cell">Product Name</th>
                        <th scope="col" class="table__cell">Category</th>
                        <th scope="col" class="table__cell">Quantity Sold</th>
                        <th scope="col" class="table__cell">Total Sales</th>
                    </tr>
                </thead>
                <tbody class="table__body">
                    <?php if (!empty($top_products)) : ?>
                        <?php foreach ($top_products as $index => $product) : ?>
                            <tr class="table__row">
                                <td class="table__cell"><?= $index + 1 ?></td>
                                <td class="table__cell"><?= htmlspecialchars($product['name']) ?></td>
                                <td class="table__cell"><?= htmlspecialchars($product['category']) ?></td>
                                <td class="table__cell"><?= number_format($product['quantity_sold']) ?></td>
                                <td class="table__cell">₱<?= number_format($product['total_sales'], 2) ?></td>
                            </tr>
                        <?php endforeach ?>
                    <?php endif ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>