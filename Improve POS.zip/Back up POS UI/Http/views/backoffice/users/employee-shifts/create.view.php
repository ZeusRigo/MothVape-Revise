<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <!-- Employee -->
        <div class="mb-4">
            <label for="employee-id" class="form-label fw-bold">
                Employee
                <span class="txt-danger">*</span>
            </label>
            <!-- Fetch employees from database and populate options -->
            <select id="employee-id" name="employee-id" class="form-control mt-2" required>
                <?php if ($result_employees) : ?>
                    <option value="">--- Select Employee ---</option>
                    <?php foreach ($result_employees as $row) : ?>
                        <option 
                            value="<?= htmlspecialchars($row['id']) ?>"
                            <?= old('employee-id') == $row['id'] ? 'selected' : '' ?>
                        >
                            <?= htmlspecialchars($row['full_name']) ?>
                        </option>
                    <?php endforeach ?>
                <?php elseif (empty($result_roles)) : ?>
                    <option value="" selected>No Roles Available</option>
                <?php else : ?>
                    <option value="" selected>Error Fetching Data!</option>
                <?php endif ?>
            </select>
            <?php if (isset($errors['role-id'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['role-id'] ?></p>
            <?php endif; ?>
        </div>
        <!-- Shift Date -->
        <div class="mb-4">
            <label for="shift-date" class="form-label fw-bold">
                Shift Date
            </label>
            <input 
                type="date"
                id="shift-date" 
                name="shift-date" 
                class="form-control mt-2 mb-2"
                value="<?= old('shift-date') ?>"
            >
            <?php if (isset($errors['shift-date'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['shift-date'] ?></p>
            <?php endif; ?>
        </div>
        <!-- Clock-in Time -->
        <div class="mb-4">
            <label for="clock-in-time" class="form-label fw-bold">
                Clock-in Time
            </label>
            <div style="display: flex; align-items: center; gap: 0.5rem">
                <input 
                    type="time"
                    id="clock-in-time" 
                    name="clock-in-time" 
                    class="form-control mt-2 mb-2"
                    value="<?= old('clock-in-time') ?>"
                    step="1"
                >
                <button type="button" class="btn btn-info" onclick="getCurrentTime('clock-in-time')">Get Current Time</button>
            </div>
            <?php if (isset($errors['clock-in-time'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['clock-in-time'] ?></p>
            <?php endif; ?>
        </div>
         <!-- Clock-out Time -->
         <div class="mb-4">
            <label for="clock-out-time" class="form-label fw-bold">
                Clock-out Time
            </label>
            <div style="display: flex; align-items: center; gap: 0.5rem">
                <input 
                    type="time"
                    id="clock-out-time" 
                    name="clock-out-time" 
                    class="form-control mt-2 mb-2"
                    value="<?= old('clock-out-time') ?>"
                    step="1"
                >
                <button type="button" class="btn btn-info" onclick="getCurrentTime('clock-out-time')">Get Current Time</button>
            </div>
            <?php if (isset($errors['clock-out-time'])) : ?>
                <p class="txt-danger fw-bold mb-3"><?= $errors['clock-out-time'] ?></p>
            <?php endif; ?>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="btn btn-success btn-has-icon fw-bold">
                Add
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>