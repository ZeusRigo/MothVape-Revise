<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <!-- I. Basic Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">I. Basic Information</p>
            <hr class="my-4">
            <!-- First Name -->
            <div class="mb-4">
                <label for="first-name" class="form-label fw-bold">
                    First Name
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="text" 
                    id="first-name" 
                    name="first-name" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter first name"
                    value="<?= old('first-name') ?>"
                    maxlength="50"
                    required
                >
                <?php if (isset($errors['first-name'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['first-name'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Middle Name -->
            <div class="mb-4">
                <label for="middle-name" class="form-label fw-bold">
                    Middle Name
                </label>
                <input 
                    type="text" 
                    id="middle-name" 
                    name="middle-name" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter middle name"
                    value="<?= old('middle-name') ?>"
                    maxlength="50"
                >
                <?php if (isset($errors['middle-name'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['middle-name'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Last Name -->
            <div class="mb-4">
                <label for="last-name" class="form-label fw-bold">
                    Last Name
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="text" 
                    id="last-name" 
                    name="last-name" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter last name"
                    value="<?= old('last-name') ?>"
                    maxlength="50"
                    required
                >
                <?php if (isset($errors['last-name'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['last-name'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Email Address -->
            <div class="mb-4">
                <label for="email" class="form-label fw-bold">
                    Email Address
                </label>
                <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    class="form-control mt-2 mb-2"
                    placeholder="e.g., name@example.com"
                    value="<?= old('email') ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['email'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['email'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Phone Number -->
            <div class="mb-4">
                <label for="phone-number" class="form-label fw-bold">
                    Phone Number
                </label>
                <input 
                    type="text"
                    id="phone-number" 
                    name="phone-number" 
                    class="form-control mt-2 mb-2"
                    placeholder="+1 (123) 456-7890"
                    value="<?= old('phone-number') ?>"
                >
                <?php if (isset($errors['phone-number'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['phone-number'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- II. Address Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">II. Address Information</p>
            <hr class="my-4">
            <!-- Street Address Line 1 -->
            <div class="mb-4">
                <label for="address1" class="form-label fw-bold">
                    Street Address Line 1
                </label>
                <input 
                    type="text" 
                    id="street-address-line1" 
                    name="street-address-line1" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter first street address"
                    value="<?= old('street-address-line1') ?>"
                    maxlength="255"
                >
                <?php if (isset($errors['street-address-line1'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['street-address-line1'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Street Address Line 2-->
            <div class="mb-4">
                <label for="street-address-line2" class="form-label fw-bold">
                    Street Address Line 2
                </label>
                <input 
                    type="text" 
                    id="street-address-line2" 
                    name="street-address-line2" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter second street address"
                    value="<?= old('street-address-line2') ?>"
                    maxlength="255"
                >
                <?php if (isset($errors['street-address-line2'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['street-address-line2'] ?></p>
                <?php endif; ?>
            </div>
            <!-- City -->
            <div class="mb-4">
                <label for="city" class="form-label fw-bold">
                    City
                </label>
                <input 
                    type="text"
                    id="city" 
                    name="city" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter city"
                    value="<?= old('city') ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['city'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['city'] ?></p>
                <?php endif; ?>
            </div>
            <!-- State -->
            <div class="mb-4">
                <label for="state" class="form-label fw-bold">
                    State
                </label>
                <input 
                    type="text"
                    id="state" 
                    name="state" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter state"
                    value="<?= old('state') ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['state'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['state'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Postal Code -->
            <div class="mb-4">
                <label for="postal-code" class="form-label fw-bold">
                    Postal Code
                </label>
                <input 
                    type="text"
                    id="postal-code" 
                    name="postal-code" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter postal code"
                    value="<?= old('postal-code') ?>"
                    maxlength="20"
                >
                <?php if (isset($errors['postal-code'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['postal-code'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Country -->
            <div class="mb-4">
                <label for="country" class="form-label fw-bold">
                    Country
                </label>
                <input 
                    type="text"
                    id="country" 
                    name="country" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter country"
                    value="<?= old('country') ?>"
                    maxlength="100"
                >
                <?php if (isset($errors['country'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['country'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- III. User Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">III. User Information</p>
            <hr class="my-4">
            <!-- Role -->
            <div class="mb-4">
                <label for="role-id" class="form-label fw-bold">
                    Role
                    <span class="txt-danger">*</span>
                </label>
                <!-- Fetch roles from database and populate options -->
                <select id="role-id" name="role-id" class="form-control mt-2" required>
                    <?php if ($result_roles) : ?>
                        <option value="">--- Select Role ---</option>
                        <?php foreach ($result_roles as $row) : ?>
                            <option 
                                value="<?= htmlspecialchars($row['id']) ?>"
                                <?= old('role-id') == $row['id'] ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($row['name']) ?>
                            </option>
                        <?php endforeach ?>
                    <?php elseif (empty($result_roles)) : ?>
                        <option value="" selected>No Roles Available</option>
                    <?php else : ?>
                        <option value="" selected>Error Fetching Data!</option>
                    <?php endif ?>
                </select>
                <?php if (isset($errors['role-id'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['role-id'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Username -->
            <div class="mb-4">
                <label for="username" class="form-label fw-bold">
                    Username
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="text"
                    id="username" 
                    name="username" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter username"
                    value="<?= old('username') ?>"
                    maxlength="50"
                    required
                >
                <?php if (isset($errors['username'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['username'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Password -->
            <div class="mb-4">
                <label for="password" class="form-label fw-bold">
                    Password
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="password"
                    id="password" 
                    name="password" 
                    class="form-control mt-2 mb-2"
                    placeholder="Enter password"
                    value="<?= old('password') ?>"
                    maxlength="255"
                    required
                >
                <?php if (isset($errors['password'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['password'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Verify Password -->
            <div class="mb-4">
                <label for="verify-password" class="form-label fw-bold">
                    Re-enter Password
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="password"
                    id="verify-password" 
                    name="verify-password" 
                    class="form-control mt-2 mb-2"
                    placeholder="Re-enter password"
                    value="<?= old('verify-password') ?>"
                    maxlength="255"
                    required
                >
                <?php if (isset($errors['verify-password'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['verify-password'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="btn btn-success btn-has-icon fw-bold">
                Add
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>