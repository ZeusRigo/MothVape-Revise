<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/modal-archive.php')) ?>
<!-- Page Content -->
<main class="main">
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-2">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <div class="controls">
        <div class="controls__container-left">
            <a href="<?= $homeURI ?>/add" class="btn btn-success btn-has-icon">
                <p>Add Employee</p>
                <img src="/assets/images/add-icon.webp" alt="Add Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </a>
            <button 
                class="btn btn-danger btn-has-icon js-control-btn"
                onclick="openModalMultiple(
                    '<?= $tableName ?>',
                    '<?= $homeURI ?>', 
                    'modal-archive'
                )"
            >
                <p>Archive</p>
                <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
        <div class="controls__container-right">
            <div class="controls__search-container">
                <input 
                    type="text"
                    id="search" 
                    class="form-control"
                    placeholder="Search..."
                >
                <button 
                    type="button"
                    class="btn btn-dark btn-has-icon"
                >
                    <img src="/assets/images/search-icon.webp" alt="Search Icon" class="btn__icon btn__icon--invert" loading="lazy">
                </button>
            </div>
        </div>
    </div>
    <!-- Table -->
    <div class="table-container">
        <table class="table">
            <thead class="table__header">
                <tr>
                    <th class="table__cell table__cell--select">
                        <input type="checkbox" id="select-all-checkbox" class="table__select-all-checkbox" onchange="selectAllRows()">
                    </th>
                    <th scope="col" class="table__cell">Full Name</th>
                    <th scope="col" class="table__cell">Email</th>
                    <th scope="col" class="table__cell">Phone No.</th>
                    <th scope="col" class="table__cell">Username</th>
                    <th scope="col" class="table__cell">Role</th>
                    <th scope="col" class="table__cell">Created At</th>
                    <th scope="col" class="table__cell">Modified At</th>
                    <th scope="col" class="table__cell table__cell--actions">Actions</th>
                </tr>
            </thead>
            <tbody class="table__body">
                <?php if (!empty($result)) : ?>
                    <?php foreach ($result as $row) : ?>
                        <tr class="table__row">
                            <td class="table__cell table__cell--select">
                                <input type="checkbox" class="table__select js-table__select" data-id="<?= htmlspecialchars($row['id']) ?>" onchange="selectRow(this)">
                            </td>
                            <td class="table__cell"><?= htmlspecialchars($row['full_name']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['email'] ?? 'N/A') ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['phone_number'] ?? 'N/A') ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['username']) ?></td>
                            <td class="table__cell"><?= htmlspecialchars($row['role_name'] ?? 'N/A') ?></td>
                            <td class="table__cell" style="width: 10%"><?= htmlspecialchars($row['created_at']) ?></td>
                            <td class="table__cell" style="width: 10%"><?= htmlspecialchars($row['modified_at']) ?></td>
                            <td class="table__cell table__cell--actions" style="width: 5%">
                                <div class="table__actions-container">
                                    <a href="<?= $homeURI ?>/show?id=<?= htmlspecialchars($row['id']) ?>" class="btn btn-dark btn-has-icon">
                                        <img src="/assets/images/eye-icon.webp" alt="Eye Icon" class="btn__icon btn__icon--invert" loading="lazy">
                                    </a>
                                    <a href="<?= $homeURI ?>/edit?id=<?= htmlspecialchars($row['id']) ?>" class="btn btn-primary btn-has-icon">
                                        <img src="/assets/images/pencil-icon.webp" alt="Pencil Icon" class="btn__icon btn__icon--invert" loading="lazy">
                                    </a>
                                    <button
                                        class="btn btn-danger btn-has-icon js-table__select"
                                        data-id="<?= htmlspecialchars($row['id']) ?>"
                                        data-action="archive-<?= $dataAction ?>"
                                        onclick="openModalSingle(
                                            '<?= $tableName ?>', 
                                            <?= htmlspecialchars($row['id']) ?>,
                                            '<?= $homeURI ?>', 
                                            'modal-archive'
                                        )"
                                    >
                                        <img src="/assets/images/archive-icon.webp" alt="Archive Icon" class="btn__icon btn__icon--invert">
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach ?>
                <?php endif ?>
            </tbody>
        </table>
    </div>
</main>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        initializeSearch('search');
    });
</script>