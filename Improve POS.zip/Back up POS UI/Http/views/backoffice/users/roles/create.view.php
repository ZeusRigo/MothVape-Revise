<?php require(base_path('Http/views/backoffice/partials/head.php')) ?>
<?php require(base_path('Http/views/backoffice/partials/nav.php')) ?>
<!-- Page Content -->
<main class="main">
    <div class="form__actions-container">
        <a href="<?= $homeURI ?>" class="btn btn-danger btn-has-icon mb-5">
            Cancel
            <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert" loading="lazy">
        </a>
    </div>
    <!-- Page Header -->
    <div class="page-heading">
        <p class="fw-bold fs-5">
            <?= $pageHeading ?? 'Page' ?>
        </p>
    </div>
    <!-- Divider -->
    <hr class="my-4">
    <form id="_form" action="<?= $homeURI ?>" method="POST" class="form w-100">
        <!-- I. Basic Information -->
        <div class="mb-2">
            <p class="fw-bold fs-5">I. Basic Information</p>
            <hr class="my-4">
            <!-- Role Name -->
            <div class="mb-4">
                <label for="name" class="form-label fw-bold">
                    Name
                    <span class="txt-danger">*</span>
                </label>
                <input 
                    type="text" 
                    id="name" 
                    name="name"
                    class="form-control mt-2 mb-2"
                    placeholder="Enter role name"
                    value="<?= old('name') ?>"
                    maxlength="50"
                    required
                >
                <?php if (isset($errors['name'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['name'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- II. Configure Permissions -->
        <div class="mb-2">
            <p class="fw-bold fs-5">II. Configure Permissions</p>
            <hr class="my-4">
            <!-- Manage Sales? -->
            <div class="mb-4">
                <label for="manage-sales" class="form-label fw-bold">
                    Manage Sales?
                </label>
                <input 
                    type="checkbox" 
                    id="manage-sales" 
                    name="manage-sales"
                    <?= old('manage-sales') !== '' ? 'checked' : '' ?>
                >
                <?php if (isset($errors['manage-sales'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['manage-sales'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Manage Inventory? -->
            <div class="mb-4">
                <label for="manage-inventory" class="form-label fw-bold">
                    Manage Inventory?
                </label>
                <input 
                    type="checkbox" 
                    id="manage-inventory" 
                    name="manage-inventory"
                    <?= old('manage-inventory') !== '' ? 'checked' : '' ?>
                >
                <?php if (isset($errors['manage-inventory'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['manage-inventory'] ?></p>
                <?php endif; ?>
            </div>
            <!-- Manage Users? -->
            <div class="mb-4">
                <label for="manage-users" class="form-label fw-bold">
                    Manage Users?
                </label>
                <input 
                    type="checkbox" 
                    id="manage-users" 
                    name="manage-users"
                    <?= old('manage-users') !== '' ? 'checked' : '' ?>
                >
                <?php if (isset($errors['manage-users'])) : ?>
                    <p class="txt-danger fw-bold mb-3"><?= $errors['manage-users'] ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php if (isset($errors['form'])) : ?>
            <p class="txt-danger fw-bold mb-3"><?= $errors['form'] ?></p>
        <?php endif; ?>
        <div class="form__actions-container">
            <button type="button" class="btn btn-dark btn-has-icon" onclick="clearForm('_form')">
                Clear
                <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
            <button type="submit" class="btn btn-success btn-has-icon fw-bold">
                Add
                <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert" loading="lazy">
            </button>
        </div>
    </form>
</main>
<script>
    // Get all management permission checkboxes
    const managementCheckboxes = document.querySelectorAll('[id^="manage-"]');

    // Function to check if any management checkbox is checked
    function isAnyManagementChecked() {
        return Array.from(managementCheckboxes).some(checkbox => checkbox.checked);
    }

    // Add event listeners to all management checkboxes
    managementCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            // No need to affect other checkboxes
            // Just let the checkbox handle its own state
        });
    });
</script>
<?php require(base_path('Http/views/backoffice/partials/foot.php')) ?>