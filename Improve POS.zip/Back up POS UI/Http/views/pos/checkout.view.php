<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="public/assets/css/main.css">
    <link rel="stylesheet" href="public/assets/css/customs/pos/_checkout.css">
</head>
<body>

<main class="main">
    <div class="pos__main-content">
        <!-- Left Panel - Order Summary -->
        <div class="pos__panel-left">
            <p class="txt txt--1p5em txt--bold">Order Ticket</p>
            
            <!-- Order Items -->
            <div class="pos__order-items-container">
                <?php foreach ($order_data['items'] as $item): ?>
                    <div class="pos__order-item" data-id="<?= htmlspecialchars($item['item_id']) ?>">
                        <div class="pos__order-item-details">
                            <p class="txt txt--bold"><?= htmlspecialchars($item['name']) ?></p>
                            <p class="txt">Quantity: <?= htmlspecialchars($item['quantity']) ?></p>
                            <p class="txt">Price per item: &#x20B1;<?= number_format($item['price'], 2) ?></p>
                        </div>
                        <p class="txt txt--bold">&#x20B1;<?= number_format($item['total_price'], 2) ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Price Breakdown -->
            <div class="pos__order-ticket-info">
                <p class="txt txt--bold">Price Breakdown:</p>
                <div class="pos__order-ticket-section">
                    <p class="txt">Subtotal (Before Discount)</p>
                    <p class="txt">&#x20B1;<?= number_format((float)$order_data['summary']['subtotal'], 2) ?></p>
                </div>
                <div class="pos__order-ticket-section">
                    <p class="txt">Discount (<?= number_format((float)$order_data['summary']['discountPercentage'], 0) ?>%)</p>
                    <p class="txt">&#x20B1;<?= number_format((float)$order_data['summary']['discountAmount'], 2) ?></p>
                </div>
                <div class="pos__order-ticket-section">
                    <p class="txt">Price Before VAT</p>
                    <p class="txt">&#x20B1;<?= number_format((float)$order_data['summary']['beforeVAT'], 2) ?></p>
                </div>
                <div class="pos__order-ticket-section">
                    <p class="txt">VAT (12%)</p>
                    <p class="txt">&#x20B1;<?= number_format((float)$order_data['summary']['VAT'], 2) ?></p>
                </div>
                <hr>
                <div class="pos__order-ticket-section">
                    <p class="txt txt--1p5em txt--bold">Total</p>
                    <p class="txt txt--1p5em txt--bold">&#x20B1;<?= number_format((float)$order_data['summary']['total'], 2) ?></p>
                </div>
                <hr>
            </div>

            <div class="pos__order-ticket-actions-group">
                <a href="/pos" class="btn btn-danger btn-has-icon">
                    <p class="btn__txt">Cancel</p>
                    <img src="/assets/images/cancel-icon.webp" alt="Cancel Icon" class="btn__icon btn__icon--invert">
                </a>
            </div>
        </div>

        <!-- Right Panel - Payment Details -->
        <div class="pos__panel-right">
            <form id="payment-form" class="backoffice__form-body" method="POST" action="/pos/process-checkout">
                <!-- Order Items Hidden Input -->
                <input type="hidden" id="order-items" name="order-items" value="<?= htmlspecialchars(json_encode($order_data['items'])) ?>">
                <input type="hidden" id="price-summary" name="price-summary" value="<?= htmlspecialchars(json_encode($order_data['summary'])) ?>">

                <!-- Order Details Section -->
                <section class="backoffice__form-section">
                    <div>
                        <p class="txt txt--1p5em txt--bold">Order Details</p>
                        <hr>
                    </div>

                    <!-- Customer Name -->
                    <div class="form__form-group form__form-group--column">
                        <label for="customer-name" class="form__label">Customer Name</label>
                        <input type="text" id="customer-name" name="customer-name" class="form__input" 
                            placeholder="Enter customer name">
                    </div>
                </section>

                <!-- Payment Details Section -->
                <section class="backoffice__form-section">
                    <div>
                        <p class="txt txt--1p5em txt--bold">Payment Details</p>
                        <hr>
                    </div>

                    <!-- Payment Amount -->
                    <div class="form__form-group form__form-group--column">
                        <label for="payment-amount" class="form__label form__label--required">Received Amount <span>*</span></label>
                        <input type="text" required id="payment-amount" name="payment-amount" class="form__input <?= isset($errors['payment_amount']) ? 'form__input--invalid' : '' ?>" 
                            placeholder="Enter payment amount..." 
                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');"
                            value="<?= old('payment_amount') ?? '' ?>">
                        <?php if (isset($errors['payment_amount'])) : ?>
                            <p class="form__error-message"><?= $errors['payment_amount'] ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- Change -->
                    <div class="form__form-group form__form-group--column">
                        <label for="change-amount" class="form__label">Change</label>
                        <input type="text" id="change-amount" name="change_amount" 
                            class="form__input form__input--disabled" placeholder="₱0.00" disabled>
                    </div>

                    <!-- Payment Method -->
                    <div class="form__form-group form__form-group--column">
                        <label for="payment-method" class="form__label">Payment Method <span class="txt-danger">*</span></label>
                        <select id="payment-method" name="payment-method" class="form__input form__dropdown" required>
                            <option value="" selected>--- Select Payment Method ---</option>
                            <?php foreach ($result_paymentMethods as $method): ?>
                                <option value="<?= htmlspecialchars($method['name']) ?>">
                                    <?= htmlspecialchars($method['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </section>

                <!-- Action Buttons -->
                <div class="pos__panel-right-actions">
                    <button type="button" id="clear-btn" class="btn btn-dark btn-has-icon" onclick="clearInputs();">
                        <p class="btn__txt">Clear</p>
                        <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert">
                    </button>
                    <button type="submit" id="checkout-btn" class="btn btn-success btn-has-icon">
                        <p class="btn__txt">Checkout</p>
                        <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert">
                    </button>
                </div>
            </form>
        </div>
    </div>
</main>

<!-- Custom Scripts -->
<script src="public/assets/js/customs/pos/checkout.js"></script>

<?php require(base_path('Http/views/pos/partials/foot.php')) ?> 