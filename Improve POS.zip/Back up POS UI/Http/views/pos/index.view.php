<?php require(base_path('Http/views/pos/partials/head.php')) ?>
<?php require(base_path('Http/views/pos/partials/nav.php')) ?>

<main class="main">
    <div class="pos__main-content">
        <div class="pos__panel-left">
            <div class="pos__panel-left-container-top">
                <div class="category-section">
                    <div class="category-header">
                        <div class="category-header__content">
                            <h2 class="category-title fs-4 fw-bold">Categories</h2>
                            <div class="controls__search-container">
                                <input 
                                    type="text"
                                    id="search" 
                                    class="form-control"
                                    placeholder="Search by Name, SKU or Category..."
                                >
                                <button 
                                    type="button"
                                    class="btn btn-dark btn-has-icon"
                                >
                                    <img src="/assets/images/search-icon.webp" alt="Search Icon" class="btn__icon btn__icon--invert" loading="lazy">
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="category-nav">
                        <button class="category-nav__scroll-btn category-nav__scroll-btn--left category-nav__scroll-btn--hidden">
                            <img src="/assets/images/left.png" alt="Scroll Left" width="16" height="16">
                        </button>
                        <button class="category-nav__scroll-btn category-nav__scroll-btn--right">
                            <img src="/assets/images/right.png" alt="Scroll Right" width="16" height="16">
                        </button>
                        <div class="category-nav__scroll">
                            <button class="category-btn category-btn--active">
                                <span class="category-btn__text">All</span>
                            </button>
                            <?php foreach ($categories as $category) : ?>
                                <button class="category-btn">
                                    <span class="category-btn__text"><?= htmlspecialchars($category['name']) ?></span>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pos__panel-left-container-middle">
                <div id="item-grid" class="pos__item-grid">
                    <?php foreach ($items as $batch): ?>
                        <div 
                            class="item-card js-item-card" 
                            data-category="<?= htmlspecialchars($batch['category'] ?? '') ?>"
                        >
                            <div class="item-card__image-container">
                                <img
                                    data-src="<?= $batch['image_url'] ?>"
                                    src="/assets/images/placeholder.webp"
                                    alt="<?= htmlspecialchars($batch['name']) ?>" 
                                    class="item-card__image"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </div>
                            <div class="item-card__info">
                                <h3 class="item-card__name"><?= htmlspecialchars($batch['name']) ?></h3>
                                <p class="item-card__price">₱<?= number_format($batch['price'], 2) ?></p>
                            </div>
                            <button 
                                class="item-card__add-button"
                                onclick='addItemToOrder(<?= htmlspecialchars(json_encode($batch, JSON_HEX_APOS | JSON_HEX_QUOT)) ?>)'
                            >
                                <img 
                                    src="/assets/images/add-icon.webp" 
                                    alt="Add" 
                                    class="item-card__add-icon invert--100"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Add overlay for mobile order panel -->
        <div class="order-panel-overlay" onclick="toggleOrderPanel()"></div>
        
        <!-- Modified panel-right with toggle button -->
        <button class="order-panel__toggle-btn" onclick="toggleOrderPanel()">
            <img 
                src="/assets/images/cart-icon.webp" 
                alt="Cart Icon" 
                class="order-panel__toggle-icon"
                loading="lazy"
                decoding="async"
            >
            <span class="hamburger-line"></span>
            <span class="hamburger-line"></span>
            <span class="hamburger-line"></span>
        </button>
        
        <div class="pos__panel-right">
            <p class="fs-5 fw-bold">Order Ticket</p>
            <div id="order-items-container" class="pos__order-items-container">
                <!-- Order Items will be dynamically populated here -->
            </div>
            <div class="pos__order-ticket-info">
                <div class="pos__order-ticket-section mb-2">
                    <p class="fw-bold">Apply Discount (%)</p>
                    <div class="pos__discount">
                        <input 
                            type="number" 
                            required 
                            id="discount" 
                            name="discount" 
                            class="form-control" 
                            value="0" 
                            min="0" 
                            max="20"
                            oninput="this.value = this.value > 20 ? 20 : Math.abs(this.value)"
                            onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                        >
                        <p>%</p>
                    </div>
                </div>
                <hr>
                <p class="fw-bold my-2">Price Breakdown:</p>
                <div class="pos__order-ticket-section my-2">
                    <p>Subtotal:</p>
                    <p id="subtotal-txt">₱0.00</p>
                </div>
                <div class="pos__order-ticket-section my-2">
                    <p>Discount (<span id="discount-percentage-txt">0</span>%)</p>
                    <p id="discount-price-txt">-₱0.00</p>
                </div>
                <div class="pos__order-ticket-section my-2">
                    <p>VATable/Price Before VAT</p>
                    <p id="before-vat-txt">₱0.00</p>
                </div>
                <div class="pos__order-ticket-section my-2">
                    <p>VAT (12%)</p>
                    <p id="after-vat-txt">₱0.00</p>
                </div>
                <hr>
                <div class="pos__order-ticket-section my-2">
                    <p class="fs-5 fw-bold">Total</p>
                    <p id="total-price-txt" class="fs-5 fw-bold">₱0.00</p>
                </div>
                <hr>
            </div>
            <div class="pos__order-ticket-actions-group">
                <button id="clear-btn" class="btn btn-dark btn-has-icon btn--disabled" onclick="clearOrder()" disabled>
                    <p class="btn__txt">Clear</p>
                    <img src="/assets/images/eraser-icon.webp" alt="Eraser Icon" class="btn__icon btn__icon--invert">
                </button>
                <button id="checkout-btn" class="btn btn-success btn-has-icon btn--disabled" onclick="confirmOrder()" disabled>
                    <p class="btn__txt">Confirm Order</p>
                    <img src="/assets/images/check-icon.webp" alt="Check Icon" class="btn__icon btn__icon--invert">
                </button>
            </div>
        </div>
    </div>
</main>
<!-- Custom Scripts -->
<script src="/assets/js/customs/pos/order-ticket.js" defer></script>
<script src="/assets/js/customs/pos/image-loader.js" defer></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize search with category support
        initializeSearch('search', '.item-card', function(item, searchTerm) {
            const itemName = item.querySelector('.item-card__name').textContent.toLowerCase();
            const itemCategory = item.dataset.category.toLowerCase();
            searchTerm = searchTerm.toLowerCase();
            
            return itemName.includes(searchTerm) || 
                   itemCategory.includes(searchTerm);
        });

        // Initialize drag scroll for order items container
        const orderContainer = document.getElementById('order-items-container');
        let isDown = false;
        let startY;
        let scrollTop;

        orderContainer.addEventListener('mousedown', (e) => {
            isDown = true;
            orderContainer.style.cursor = 'grabbing';
            startY = e.pageY - orderContainer.offsetTop;
            scrollTop = orderContainer.scrollTop;
        });

        orderContainer.addEventListener('mouseleave', () => {
            isDown = false;
            orderContainer.style.cursor = 'grab';
        });

        orderContainer.addEventListener('mouseup', () => {
            isDown = false;
            orderContainer.style.cursor = 'grab';
        });

        orderContainer.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const y = e.pageY - orderContainer.offsetTop;
            const walk = (y - startY) * 2;
            orderContainer.scrollTop = scrollTop - walk;
        });

        // Initialize category filtering
        const categoryButtons = document.querySelectorAll('.category-btn');
        const itemCards = document.querySelectorAll('.item-card');

        function filterByCategory(category) {
            const normalizedCategory = category.toLowerCase().trim();
            itemCards.forEach(card => {
                const cardCategory = (card.dataset.category || '').toLowerCase().trim();
                if (normalizedCategory === 'all' || cardCategory === normalizedCategory) {
                    card.style.display = '';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Add click event listeners to category buttons
        categoryButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                categoryButtons.forEach(btn => btn.classList.remove('category-btn--active'));
                
                // Add active class to clicked button
                button.classList.add('category-btn--active');
                
                // Get category from button text
                const category = button.querySelector('.category-btn__text').textContent;
                
                // Filter items
                if (category === 'All') {
                    filterByCategory('all');
                } else {
                    filterByCategory(category);
                }
            });
        });

        // Handle category navigation scrolling
        const categoryNav = document.querySelector('.category-nav__scroll');
        const leftScrollBtn = document.querySelector('.category-nav__scroll-btn--left');
        const rightScrollBtn = document.querySelector('.category-nav__scroll-btn--right');
        
        // Add mouse wheel horizontal scrolling
        categoryNav.addEventListener('wheel', (e) => {
            e.preventDefault(); // Prevent vertical scrolling
            
            // Increased scroll sensitivity (from 100 to 200)
            const scrollAmount = e.deltaY > 0 ? 200 : -200;
            categoryNav.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
            
            // Update scroll buttons visibility
            updateScrollButtons();
        });
        
        function updateScrollButtons() {
            const { scrollLeft, scrollWidth, clientWidth } = categoryNav;
            
            // Show/hide left button
            if (scrollLeft > 0) {
                leftScrollBtn.classList.remove('category-nav__scroll-btn--hidden');
            } else {
                leftScrollBtn.classList.add('category-nav__scroll-btn--hidden');
            }
            
            // Show/hide right button
            if (scrollLeft + clientWidth < scrollWidth) {
                rightScrollBtn.classList.remove('category-nav__scroll-btn--hidden');
            } else {
                rightScrollBtn.classList.add('category-nav__scroll-btn--hidden');
            }
        }
        
        // Scroll left/right when buttons are clicked
        leftScrollBtn.addEventListener('click', () => {
            categoryNav.scrollBy({ left: -200, behavior: 'smooth' });
        });
        
        rightScrollBtn.addEventListener('click', () => {
            categoryNav.scrollBy({ left: 200, behavior: 'smooth' });
        });
        
        // Scroll left/right when scrolling
        categoryNav.addEventListener('scroll', updateScrollButtons);
        
        // Initial check for scroll buttons
        updateScrollButtons();
        
        // Update on window resize
        window.addEventListener('resize', updateScrollButtons);

        // Initialize ImageLoader
        new ImageLoader();
    });
</script>
<?php require(base_path('Http/views/pos/partials/foot.php')) ?>