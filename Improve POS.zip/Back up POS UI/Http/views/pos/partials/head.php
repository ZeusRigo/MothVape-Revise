<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?></title>
    <script>
        // Register Service Worker
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/assets/js/utilities/service-worker.js')
                    .then(registration => {
                        console.log('ServiceWorker registered');
                    })
                    .catch(err => {
                        console.log('ServiceWorker registration failed: ', err);
                    });
            });
        }
    </script>
    <!-- Preload critical images -->
    <link rel="preload" as="image" href="/assets/images/no-image.webp" type="image/webp">
    <link rel="preload" as="image" href="/assets/images/cart-icon.webp" type="image/webp">
    <link rel="preload" as="image" href="/assets/images/add-icon.webp" type="image/webp">
    
    <!-- Cache control -->
    <meta http-equiv="Cache-Control" content="public, max-age=31536000">
    <link rel="stylesheet" href="public/assets/css/main.css">
    <link rel="stylesheet" href="public/assets/css/customs/pos/main.css">
    <script src="/assets/js/utilities/search.js" defer></script>
    <?php if (strpos($_SERVER['REQUEST_URI'], '/pos/checkout') === false): ?>
        <script src="public/assets/js/customs/backoffice/partials/nav.js" defer></script>
    <?php endif; ?>
</head>
<body>