<?php
// Get user permissions
$permissions = $_SESSION['user']['permissions'] ?? [];
$isAdmin = $_SESSION['user']['is_admin'] ?? false;

// Check if user has any management permissions
$canManageSales = $isAdmin || ($permissions['manage_sales'] ?? false);
$canManageInventory = $isAdmin || ($permissions['manage_inventory'] ?? false);
$canManageUsers = $isAdmin || ($permissions['manage_users'] ?? false);

// Determine if they can access backoffice
$canAccessBackoffice = $isAdmin || $canManageSales || $canManageInventory || $canManageUsers;
?>

<!-- Add this before the sidebar -->
<div class="sidebar-overlay" onclick="toggleSidebar()"></div>

<!-- Sidebar -->
<aside class="sidebar">
    <div class="sidebar__container-top">
        <img src="/assets/images/moth-vape-logo.webp" alt="Moth Vape Logo" class="sidebar__logo" loading="lazy">
        <div class="sidebar__date-time-container">
            <span class="txt-white fw-bold">Date:</span>
            <span id="date-txt" class="txt-white">00/00/0000</span>
        </div>
        <div class="sidebar__date-time-container">
            <span class="txt-white fw-bold">Time:</span>
            <span id="time-txt" class="txt-white">00:00:00 XX</span>
        </div>
    </div>
    <div class="sidebar__container-center">
        <nav class="sidebar__nav">
            <ul class="sidebar__nav-menu">
                <!-- POS -->
                <li class="sidebar__nav-menu-item <?= (urlIs('/pos') || urlIs('/pos')) ? 'active' : '' ?>">
                    <a href="/pos" class="sidebar__nav-menu-item-link">
                        <img src="/assets/images/cart-icon.webp" alt="Cart Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                        POS
                    </a>
                </li>
                <!-- Receipts -->
                <li class="sidebar__nav-menu-item <?= (urlIs('/pos/receipts') || urlIs('/pos/receipts')) ? 'active' : '' ?>">
                    <a href="/pos/receipts" class="sidebar__nav-menu-item-link">
                        <img src="/assets/images/money-icon.webp" alt="Money Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                        Receipts
                    </a>
                </li>
                <!-- Back Office - only show if they have access -->
                <?php if ($canAccessBackoffice) : ?>
                    <li class="sidebar__nav-menu-item">
                        <a href="/backoffice/dashboard" class="sidebar__nav-menu-item-link">
                            <img src="/assets/images/gear-icon.webp" alt="Gear Icon" class="sidebar__nav-menu-item-icon" loading="lazy">
                            Back Office
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
    <div class="sidebar__container-bottom">
        <form action="/login" method="POST" class="w-100">
            <input type="hidden" name="_method" value="DELETE">
        
            <button class="btn btn-danger btn-has-icon fw-bold w-100">
                <img src="/assets/images/logout-icon.webp" alt="Logout Icon" class="btn__icon btn__icon--invert" loading="lazy">
                End Shift
            </button>
        </form>
    </div>
</aside>

<!-- Topbar -->
<header class="topbar">
    <button class="topbar__toggle-btn" onclick="toggleSidebar()">
        <img src="/assets/images/hamburger-icon.webp" alt="Hamburger Icon" class="topbar__icon" loading="lazy">
    </button>
</header>