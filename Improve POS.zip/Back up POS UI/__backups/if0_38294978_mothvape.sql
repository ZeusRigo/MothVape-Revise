-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql111.infinityfree.com
-- Generation Time: Feb 12, 2025 at 12:42 AM
-- Server version: 10.6.19-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_38294978_mothvape`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `street_address_line1` varchar(255) DEFAULT NULL,
  `street_address_line2` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `user_id`, `first_name`, `middle_name`, `last_name`, `email`, `phone_number`, `street_address_line1`, `street_address_line2`, `city`, `state`, `postal_code`, `country`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 2, 'Ceejay', NULL, 'Salonga', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-02-11 10:11:10', '2025-02-11 10:11:10', NULL),
(8, 11, 'Zeus', 'John ', 'Rigo', 'rigozeusjohn@gmail.com', '12345677890', 'lagro', 'lagro', 'quezon city', 'manila', '1111', 'philippines', '2025-02-12 02:34:57', '2025-02-12 02:34:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee_shifts`
--

CREATE TABLE `employee_shifts` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `shift_date` date DEFAULT current_timestamp(),
  `clock_in_time` time DEFAULT current_timestamp(),
  `clock_out_time` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee_shifts`
--

INSERT INTO `employee_shifts` (`id`, `employee_id`, `shift_date`, `clock_in_time`, `clock_out_time`, `created_at`, `modified_at`, `archived_at`) VALUES
(4, 1, '2025-02-11', '20:49:05', '20:52:53', '2025-02-11 12:49:05', '2025-02-11 12:52:53', NULL),
(5, 1, '2025-02-11', '20:57:11', '20:57:28', '2025-02-11 12:57:11', '2025-02-11 12:57:28', NULL),
(6, 1, '2025-02-11', '20:57:31', '20:58:16', '2025-02-11 12:57:31', '2025-02-11 12:58:16', NULL),
(7, 1, '2025-02-11', '22:19:31', '22:19:44', '2025-02-11 14:19:31', '2025-02-11 14:19:44', NULL),
(8, 1, '2025-02-11', '22:21:45', '22:39:51', '2025-02-11 14:21:45', '2025-02-11 14:39:51', NULL),
(9, 1, '2025-02-11', '22:39:58', NULL, '2025-02-11 14:39:58', '2025-02-11 14:39:58', NULL),
(10, 1, '2025-02-12', '00:44:13', NULL, '2025-02-11 16:44:13', '2025-02-11 16:44:13', NULL),
(11, 1, '2025-02-12', '03:20:06', '03:20:36', '2025-02-11 19:20:06', '2025-02-11 19:20:36', NULL),
(12, 1, '2025-02-12', '10:32:14', '11:52:02', '2025-02-12 02:32:14', '2025-02-12 03:52:02', NULL),
(13, 8, '2025-02-12', '10:50:29', NULL, '2025-02-12 02:50:29', '2025-02-12 02:50:29', NULL),
(14, 1, '2025-02-12', '11:52:04', '13:02:56', '2025-02-12 03:52:04', '2025-02-12 05:02:55', NULL),
(15, 8, '2025-02-12', '12:37:11', NULL, '2025-02-12 04:37:11', '2025-02-12 04:37:11', NULL),
(16, 1, '2025-02-12', '13:02:58', NULL, '2025-02-12 05:02:58', '2025-02-12 05:02:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `low_stock_quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `sku`, `name`, `description`, `category_id`, `price`, `image_url`, `low_stock_quantity`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 'MOTH-202502-9368', 'E-Liquid Space 30ml 20mg', 'The Space E-Liquid offers a variety of delicious flavors in a premium nicotine salt formulation, perfect for mouth-to-lung (MTL) vaping. With a balanced 50/50 VG/PG ratio, this e-liquid provides smooth throat hits, excellent flavor, and satisfying vapor production. Each 30ml bottle is equipped with an easy-fill nozzle and childproof cap for convenience and safety.', 2, '200.00', 'public/uploads/img_67ac006cc0a510.44090942.webp', 50, '2025-02-11 11:29:58', '2025-02-12 01:59:08', NULL),
(2, 'MOTH-202502-6D7C', 'E-Liquid SHATZE TOTEM 30ml 20mg', 'The SCHATZE TOTEM E-Liquid offers a premium vaping experience with a variety of delicious flavors, perfect for mouth-to-lung (MTL) vaping. Crafted with a balanced 50/50 VG/PG ratio, this nicotine salt e-liquid delivers smooth throat hits and rich flavors. Its easy-fill nozzle and childproof cap ensure convenience and safety, making it an ideal choice for vapers who enjoy flavorful, satisfying nicotine delivery.', 2, '200.00', 'public/uploads/img_67ac0006e688f2.88936247.webp', 50, '2025-02-11 11:31:44', '2025-02-12 01:57:26', NULL),
(3, 'MOTH-202502-D343', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'The NEW BLAST Lemzick E-Liquid is a premium nicotine salt e-liquid designed to deliver a smooth, flavorful vaping experience. With a selection of bold and refreshing flavors, this e-liquid is perfect for mouth-to-lung (MTL) vaping. The 60/40 VG/PG ratio provides excellent vapor production while maintaining intense flavor. Its easy-fill nozzle and childproof cap make it convenient and safe for everyday use.', 2, '200.00', 'public/uploads/img_67ac002aa7ca03.85623049.webp', 50, '2025-02-11 11:32:44', '2025-02-12 01:58:02', NULL),
(4, 'MOTH-202502-A130', 'E-Liquid USALT E-LIQUID 30ml 20mg', 'The USALT E-Liquid is a premium nicotine salt e-liquid designed for a smooth and satisfying vaping experience. With its 20mg nicotine strength and a variety of delicious flavors, this e-liquid caters to vapers who prefer mouth-to-lung (MTL) setups. Packaged in a 30ml bottle, it ensures long-lasting enjoyment and convenience for everyday use.', 2, '200.00', 'public/uploads/img_67ac005bc99256.65628349.webp', 50, '2025-02-11 11:37:15', '2025-02-12 01:58:51', NULL),
(5, 'MOTH-202502-8B9F', 'Neutral X9 Vape Tool', 'The Neutral X9 Vape Tool Kit is a comprehensive set of essential tools designed for DIY vaping enthusiasts. Whether you\'re building, cleaning, or maintaining your coils, this kit provides high-quality, durable tools to make the process efficient and hassle-free. Perfect for both beginners and experienced vapers, the Neutral X9 kit ensures precision and convenience in every build.', 6, '400.00', 'public/uploads/img_67ac03ae048607.55900588.webp', 20, '2025-02-11 11:40:56', '2025-02-12 02:13:02', NULL),
(6, 'MOTH-202502-37A1', 'GeekVape Mini Tool Kit', 'The GeekVape Mini Tool Kit is an essential companion for any DIY vaping enthusiast, designed with precision and durability in mind. This compact and versatile toolkit equips you with all the tools needed for building and maintaining your setups, making it ideal for beginners and advanced users alike. Crafted with high-quality materials, the GeekVape Mini Tool Kit ensures reliability and long-lasting performance.', 6, '500.00', 'public/uploads/img_67ac03cb9f2368.80772218.webp', 20, '2025-02-11 11:42:20', '2025-02-12 02:13:31', NULL),
(7, 'MOTH-202502-6590', 'Vapefly Clouds Cotton 5ft', 'The Vapefly Clouds Cotton is a premium wicking material designed to provide exceptional flavor and consistent performance for rebuildable atomizers. Crafted from high-quality cotton bacon prime, this 5ft roll is easy to work with and ensures efficient wicking for smooth and flavorful vaping experiences. Ideal for DIY enthusiasts, it is compatible with a variety of RDAs, RTAs, and RDTAs.', 6, '50.00', 'public/uploads/img_67ac034657af49.14632454.webp', 50, '2025-02-11 11:43:31', '2025-02-12 02:11:18', NULL),
(8, 'MOTH-202502-63B6', 'LTQ Vapor Stainless Steel Dab Tool', 'The LTQ Vapor Stainless Steel Dab Tool is a versatile and durable tool designed for handling waxes, concentrates, and dabbing needs. Crafted from high-quality stainless steel, this tool ensures precision and durability, making it an essential accessory for concentrate enthusiasts. Its ergonomic design allows for comfortable use and easy handling.', 6, '200.00', 'public/uploads/img_67ac037269bec1.21235817.webp', 20, '2025-02-11 11:44:40', '2025-02-12 02:12:02', NULL),
(9, 'MOTH-202502-871C', 'XTAR VC2 Charger', 'XTAR VC2 Charger', 6, '600.00', 'public/uploads/img_67ac03edc14928.24315510.webp', 10, '2025-02-11 11:46:15', '2025-02-12 02:14:05', NULL),
(10, 'MOTH-202502-6C20', 'Disposable Vozol Star 9000', 'The Vozol Star 9000 is a high-capacity disposable vape device designed for users who seek a long-lasting and satisfying vaping experience. With its combination of ample e-liquid capacity and a rechargeable battery, it is perfect for both casual and frequent vapers.', 3, '600.00', 'public/uploads/img_67ac04e34da9b2.39684397.webp', 20, '2025-02-11 11:48:33', '2025-02-12 20:49:49', NULL),
(11, 'MOTH-202502-8499', 'Disposable Silicone Cap For Alpha', 'Disposable Silicone Cap for Alpha (10pcs/pack)', 6, '40.00', 'public/uploads/img_67ac03ffb83c98.45016283.webp', 20, '2025-02-11 11:51:54', '2025-02-12 02:14:23', NULL),
(12, 'MOTH-202502-DCEC', 'Disposable SPACEMAN SP40000 KIT', 'The SPACEMAN SP40000 Disposable Kit is a revolutionary high-puff disposable vape, designed for extended use and customizable power settings Featuring a massive 40,000 puff lifespan, a 1000mAh rechargeable battery, and a 20ml tank capacity, this device ensures long-lasting performance With its dual mesh coil technology, multiple power modes, and a 2.28-inch OLED display with dynamic rainbow side lighting, the SP40000 combines style with advanced vaping technology', 3, '978.00', 'public/uploads/img_67ac0512b6a7e4.82284607.webp', 40, '2025-02-11 11:52:38', '2025-02-12 02:18:58', NULL),
(13, 'MOTH-202502-124A', 'Disposable UWELL Prime BG 12000', 'The UWELL Prime BG 12000 Disposable is a cutting-edge disposable vaping device designed for users who seek an extended lifespan and superior performance. With an impressive puff count, vibrant flavor options, and advanced technology, it offers convenience and satisfaction for long-term vaping.', 3, '700.00', 'public/uploads/img_67ac0484358a34.63950067.webp', 30, '2025-02-11 11:54:31', '2025-02-12 02:16:36', NULL),
(14, 'MOTH-202502-14A7', 'Disposable Moti Ultra Pro 8000', 'The Moti Ultra Pro 8000 Disposable Vape is a high-capacity, rechargeable disposable device designed for long-lasting performance and convenience. With an impressive 8000 puffs, 14ml e-liquid capacity, and a 500mAh rechargeable battery, this vape ensures an extended vaping experience. The smart screen display provides real-time monitoring of battery and e-liquid levels, while the 20mg nicotine strength delivers a satisfying hit. Available in multiple flavors, the Moti Ultra Pro 8000 is perfect fo', 3, '700.00', 'public/uploads/img_67ac05068068b7.52502917.webp', 40, '2025-02-11 11:56:17', '2025-02-12 02:18:46', NULL),
(15, 'MOTH-202502-A4A1', 'Disposable OX BAR Magic Maze 10000', 'The OXBAR Magic Maze 10000 Puff Disposable Vape is designed to provide a long-lasting and enjoyable vaping experience, perfect for both casual users and vaping enthusiasts.\r\n\r\n', 3, '750.00', 'public/uploads/img_67ac04edac3cb0.36452685.webp', 50, '2025-02-11 11:58:41', '2025-02-12 02:18:21', NULL),
(16, 'MOTH-202502-8473', 'Uwell Caliburn G3 Pod Kit', 'Uwell Caliburn G3 Pod Kit – Compact, Elegant, and High-Performance\r\nThe Uwell Caliburn G3 Pod Kit combines modern aesthetics with cutting-edge technology, making it a standout choice for vapers who prioritize performance and convenience. Featuring a lightweight aluminum alloy body, a robust 900mAh battery, and an integrated 25W output, the Caliburn G3 delivers smooth, flavorful vapor in a sleek and portable design. Its 2.5ml pod capacity, side-filling system, and mesh coil technology ensure an ex', 5, '868.46', 'public/uploads/img_67ac017fe0c667.33028622.webp', 40, '2025-02-11 11:59:39', '2025-02-12 02:03:44', NULL),
(17, 'MOTH-202502-A90A', 'Disposable UWELL VISCORE Vi25000', 'The UWELL VISCORE Vi25000 is a high-capacity disposable vape designed for vapers looking for exceptional longevity, powerful performance, and customizable settings Featuring a massive 20ml e-liquid capacity and an 800mAh rechargeable battery, this device delivers up to 25,000 puffs, ensuring an extended and hassle-free vaping experience\r\n\r\nWith three adjustable power modes (Rocket, Boost, and Normal), users can tailor their vaping experience to suit their preference for vapor production, flavor in', 3, '900.00', 'public/uploads/img_67ac041830e0d5.98344942.webp', 30, '2025-02-11 11:59:42', '2025-02-12 02:14:48', NULL),
(18, 'MOTH-202502-F734', 'Glass Tube For Vaporesso ITank', 'Vaporesso Pyrex Glass Tube for iTank Atomizer / iTank 2 Atomizer (5ml / 8ml)\r\nIntroduction\r\nThe Vaporesso Pyrex Glass Tube is a high-quality replacement glass designed specifically for the iTank Atomizer and iTank 2 Atomizer. Made from durable Pyrex glass, this replacement tube ensures a long-lasting and reliable vaping experience. Whether you\'re looking for the standard 5ml capacity or the larger 8ml bubble variant, this glass tube provides a perfect fit for your device. Keep your vape in top con', 6, '112.53', 'public/uploads/img_67ac0429cb85f6.48227520.webp', 16, '2025-02-11 12:01:14', '2025-02-12 02:15:05', NULL),
(19, 'MOTH-202502-C9E3', 'Disposable AIM Plus Mythology 800', 'Disposable AIM Plus Mythology 800 – A Sweet & Mesmerizing Vaping Experience\r\nThe AIM Plus Mythology 800 is a compact and flavorful disposable vape, delivering 800 smooth puffs with a rich selection of sweet and satisfying flavors Designed for MTL (Mouth-To-Lung) vaping, this device provides a satisfying nicotine hit with 2% (20mg) nicotine strength, making it a great choice for both new and experienced vapers\r\n\r\nWith a 3.2ml e-liquid capacity, the AIM Plus Mythology 800 offers a long-lasting and ha', 3, '300.00', 'public/uploads/img_67ac04d279c6f5.66015322.webp', 50, '2025-02-11 12:01:45', '2025-02-12 02:17:54', NULL),
(20, 'MOTH-202502-10C4', '65W PD Charger', 'Geekvape Charger 65W is designed for Geekvape Type-C (USB Unfit) with Safe Fast/Unfast Charging. (According to the product whether with fast charging function).\r\n\r\nUnit: 1 Set\r\nCapable of charging the Obelisk 120FC Mod in under 15 minutes\r\nWall charger with interchangeable adapter (AU Version/US Version)\r\nOutput Voltage: 5V, 3A/9V, 3A/12V, 3A/15, 3A/20V, 3.25A\r\nInput voltage: 100-240V\r\nFast charging protocols: Support PD2.0, PD3.0, QC2.0, QC3.0, QC4.0\r\nPackage: Simple Packing\r\n\r\nEach set contain:\r\n1pc 65W ', 6, '240.97', 'public/uploads/img_67ac0467ad9c74.48392307.webp', 56, '2025-02-11 12:02:49', '2025-02-12 02:16:07', NULL),
(21, 'MOTH-202502-FA32', 'Disposable UDN H6000', 'UDN HERO 6000 Disposable Vape – 6000 Puffs of Pure Pleasure\r\nThe UDN HERO 6000 is a next-generation disposable vape, offering 6000 puffs of rich flavor and satisfaction Designed with state-of-the-art technology, this device provides an intense, long-lasting vaping experience without the need for constant replacements.\r\n\r\nEquipped with adjustable puff intensity, the UDN HERO 6000 lets you customize your vaping experience to suit your preferences. Its integrated charging and liquid level indicators h', 3, '600.00', 'public/uploads/img_67ac03db9b6b91.69272952.webp', 30, '2025-02-11 12:03:39', '2025-02-12 02:13:47', NULL),
(22, 'MOTH-202502-BEF9', 'Bubble 100ml Shortfill 0mg (70VG/30PG)', 'You like your vaping to have a more chewy and gooey goodness to it? Then the Bubble 100ml nicotine free Shortfills will provide such vaping delights. With 3 juicy flavours that are blended with that classic American bubblegum taste in their respective way for pure mouth watering results.\r\n\r\nAs high VG e-liquids, each flavour of the Bubble 100ml Shortfills are totally compatible with Sub-Ohm vaping tanks and devices for great vapour cloud production and avoids giving users irritable hits to the thr', 2, '700.00', 'public/uploads/img_67ac0093ee4072.90424127.webp', 50, '2025-02-11 12:06:14', '2025-02-12 20:43:20', NULL),
(23, 'MOTH-202502-B23C', '12mg Signature Vapours TPD 10ml E-Liquid ', 'Signature Vapours, a UK brand, offers an extensive line of flavours that cater to diverse preferences. From the sweet and refreshing Apple & Blackcurrant to the cool and minty Ice Menthol, their range ensures a delightful vaping experience. With options like Mothers Milk, a combination of rich strawberry and creamy vanilla, and Vamp Toes, a cordial-inspired blend of berries, Signature Vapours provides an array of enticing flavours that are sure to satisfy any vaper\'s cravings.\r\n\r\n12mg strength\r\n50V', 2, '50.00', 'public/uploads/img_67ac012110bca1.61585396.webp', 40, '2025-02-11 12:08:59', '2025-02-12 02:02:09', NULL),
(24, 'MOTH-202502-F79C', 'Aspire Zero.G Mod 510 Adaptor', 'Zero G 510 Adaptor is designed for Aspire Zero. G Kit to make 510 tanks compatible with Zero. G Mod. It is perfect to fit any 510 tanks. Just get it! 1pc each pack.\r\n\r\nAspire Zero G Replacement 510 Adaptor Parameters:\r\n\r\nBrand	Aspire\r\nProduct Name	Zero G Mod 510 Adaptor\r\nFit for	Aspire Zero. G Kit\r\nColour	Black, Stainless Steel\r\nQuantity	1pc each pack\r\n', 6, '533.31', 'public/uploads/img_67ac0484f3a169.15074358.webp', 15, '2025-02-11 12:09:27', '2025-02-12 02:16:37', NULL),
(25, 'MOTH-202502-5F6B', 'A-Steam Fruit Flavours 18MG 10ML (50VG/50PG)', '– Made in the UK\r\n\r\n– 18mg Nicotine Salt\r\n\r\n– 10ml per Bottle\r\n\r\n– 50VG/50PG\r\n\r\n– Ideal for Mouth to Lung Vaping\r\n\r\n– Childproof and Tamper evident cap\r\n\r\n– Recyclable Bottle and Box\r\n\r\n– TPD compliant', 2, '150.00', 'public/uploads/img_67ac00cd077f98.61697136.webp', 40, '2025-02-11 12:10:56', '2025-02-12 02:00:45', NULL),
(26, 'MOTH-202502-FF3D', 'VOOPOO Vmate Cartridge V2', 'VOOPOO Vmate Cartridge V2 (2pcs/Pack)\r\nThe VOOPOO Vmate Cartridge V2 is a high-quality pod designed to provide a smooth and satisfying vaping experience. With a 3ml capacity, side-filling design, and advanced silver ion material for enhanced hygiene, this cartridge is perfect for various VOOPOO devices. Available in two resistance options, the Vmate Cartridge V2 caters to different vaping preferences, offering excellent flavor and vapor production.\r\n\r\n\r\n', 5, '400.00', 'public/uploads/img_67ac01a2679d19.78674380.webp', 40, '2025-02-11 12:14:43', '2025-02-12 02:04:18', NULL),
(27, 'MOTH-202502-3EBB', 'Vaporesso XROS Pod Cartridge 3ml 4pcs', 'Vaporesso XROS Pod Cartridge (3ml, 4pcs)\r\nThe Vaporesso XROS Pod Cartridge is designed for optimal flavor and vapor production, offering versatility with multiple resistance options. With a 3ml e-liquid capacity and convenient filling options, it provides a smooth vaping experience and compatibility with a wide range of Vaporesso XROS devices.', 5, '600.00', 'public/uploads/img_67ac01c52078a4.66576849.webp', 40, '2025-02-11 12:16:25', '2025-02-12 02:04:53', NULL),
(29, 'MOTH-202502-4181', 'VOOPOO PnP Coil for Argus/Drag/Vinci Series', 'VOOPOO PnP Coil for Argus/Drag/Vinci Series\r\nThe VOOPOO PnP Coil Series offers a variety of resistances and coil types designed for versatile vaping experiences, ranging from mouth-to-lung (MTL) to direct-to-lung (DL). Compatible with numerous VOOPOO devices, these coils ensure excellent flavor and vapor production.', 5, '700.00', 'public/uploads/img_67ac01e55c3d59.70880006.webp', 30, '2025-02-11 12:18:45', '2025-02-12 02:05:25', NULL),
(30, 'MOTH-202502-1865', 'Vandy Vape Pulse AIO V2 Kit DIY Accessory', 'andy Vape Pulse AIO V2 Kit DIY Accessory Description:\r\n\r\nPulse AIO V2 DIY Accessory is suitable for Vandy Vape Pulse AIO V2 Kit. You can use it to enjoy DIY vape experience. There are three accessories options for you to choose. The options A and B include panel/one set, button panel/one set, fire button, up/down button, airflow pipe(6pcs). The option C includes panel/one set, button panel, airflow pipe(10pcs).', 4, '964.48', 'public/uploads/img_67ac055c93aa53.15815222.webp', 13, '2025-02-11 12:19:30', '2025-02-12 02:20:12', NULL),
(31, 'MOTH-202502-9B36', 'Uwell Nunchaku Replacement Coil 4pc', 'Uwell Nunchaku Replacement Coil (4pcs)\r\nThe Uwell Nunchaku Replacement Coils are designed to provide exceptional flavor and vapor production for the Uwell Nunchaku and Nunchaku 2 Tanks. Available in multiple resistances and coil types, these coils cater to a range of vaping preferences, from smooth flavor to dense clouds. With advanced Claptonized A1 and UN2 Meshed designs, they ensure consistent performance and long-lasting durability.', 5, '500.00', 'public/uploads/img_67ac02053bff69.92037682.webp', 35, '2025-02-11 12:19:45', '2025-02-12 02:05:57', NULL),
(32, 'MOTH-202502-FF7C', 'Hellvape Dead Rabbit Pro RDA DIY Combo', 'Hellvape DIY Combo for Dead Rabbit Pro RDA Short Description:\r\n\r\nDead Rabbit Pro RDA DIY Combo includes side AFC ring, bottom AFC ring and 810 drip tip of different colors to customize your RDA further.', 4, '361.45', 'public/uploads/img_67ac05459fc738.56682077.webp', 3, '2025-02-11 12:21:34', '2025-02-12 02:19:49', NULL),
(34, 'MOTH-202502-5BCC', 'Lost Vape Centaurus N100 Mod Kit', 'Lost Vape Centaurus N100 Mod Kit with Centaurus Sub Ohm Tank - 5ml\r\nThe Lost Vape Centaurus N100 Mod Kit combines sleek design, powerful performance, and advanced features to deliver an exceptional vaping experience. Powered by a single 21700 or 18650 battery (not included), the Centaurus N100 Mod supports up to 100W of output, while the 5ml Centaurus Sub Ohm Tank ensures rich flavor and dense vapor. With features like precise airflow control, top-filling design, and compatibility with UB Max Coi', 1, '2300.00', 'public/uploads/img_67ac02ad9652e3.69332322.webp', 30, '2025-02-11 12:23:44', '2025-02-12 02:08:45', NULL),
(35, 'MOTH-202502-A576', 'SMOK Nord 5 Kit', 'SMOK Nord 5 Kit\r\nThe SMOK Nord 5 Kit is an advanced pod system that combines cutting-edge performance with a sleek and stylish design. With its powerful 2000mAh battery, adjustable power range of 5W-80W, and large 5ml e-liquid capacity, the Nord 5 is perfect for vapers seeking versatility and convenience. Available in both Regular and Leather Series, this kit offers an exceptional vaping experience for direct-to-lung (DL) enthusiasts.', 1, '1500.00', 'public/uploads/img_67ac026d701786.85495400.webp', 30, '2025-02-11 12:25:12', '2025-02-12 02:07:41', NULL),
(36, 'MOTH-202502-D97A', 'VOOPOO Filter Drip Tip for Doric Galaxy', 'The VOOPOO Filter Drip Tip is a high-quality accessory designed exclusively for the VOOPOO Doric Galaxy Pod Cartridge. Crafted from cotton, this drip tip enhances the mouth-to-lung (MTL) vaping experience by offering a smooth and comfortable draw. Its compact design and lightweight construction make it a practical choice for daily use. The pack includes 20 drip tips, making it an ideal option for vapers who value convenience and hygiene.', 7, '200.00', 'public/uploads/img_67ac0311bb5562.87336161.webp', 30, '2025-02-11 12:27:18', '2025-02-12 02:10:25', NULL),
(37, 'MOTH-202502-9F6F', 'Smoant Pasito II 510 Adapter', 'The Smoant Pasito II 510 Adapter is a must-have accessory designed to expand the compatibility of your Smoant Pasito II Kit This adapter allows users to attach 510-threaded tanks, RDAs, and RTAs to their Pasito II device, providing greater flexibility and customization in their vaping experience. Made from high-quality materials, it ensures a secure and stable connection for reliable performance.', 7, '300.00', 'public/uploads/img_67ac02ef809b17.84047594.webp', 60, '2025-02-11 12:29:07', '2025-02-12 02:09:51', NULL),
(38, 'MOTH-202502-B58C', 'GeekVape Max100 Kit', 'The GeekVape Max100 Kit is a durable and versatile vaping device designed for both beginners and advanced vapers. Featuring a robust 100W output, compatibility with single 21700 or 18650 batteries (not included), and a generous 5.5ml tank capacity, this kit delivers outstanding performance and reliability. With advanced temperature control options and a stylish design, the Max100 Kit is built for a superior vaping experience.', 1, '3000.00', 'public/uploads/img_67ac02471c2c50.05507727.webp', 50, '2025-02-11 12:34:54', '2025-02-12 02:07:03', NULL),
(39, 'MOTH-202502-A81B', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'This classic series of Billionaire Juice\'s own 10ml Nic Salts offers to vapers six great flavours to experience at 20mg. Each flavour offers a truly distinctive tastes ranging from lush sweetness to refreshing coolness that will smack your taste buds right from the first puff.\r\n\r\nBy containing a stronger dose of nicotine than traditional e-liquids that will be absorbed into the body quicker, these Billionaire Juice Nicotine Salts are an ideal choice for ex-smokers who\'ve made the switch to vaping.', 2, '250.00', 'public/uploads/img_67ac00f491b0c6.60472898.webp', 250, '2025-02-11 12:38:03', '2025-02-12 02:01:24', NULL),
(40, 'MOTH-202502-A53B', 'Lost Vape Ursa Nano Pod', 'The Lost Vape Ursa Pod Cartridge is a versatile and high-quality replacement pod designed for a wide range of Lost Vape kits. With a 2.5ml e-liquid capacity and multiple resistance options, these pods cater to both mouth-to-lung (MTL) and restricted direct-to-lung (RDTL) vaping styles. Their compatibility with a variety of Lost Vape devices makes them a convenient and essential accessory for vapers seeking consistent performance and exceptional flavor.\r\n\r\n', 5, '450.00', 'public/uploads/img_67ac014a8c1532.78377269.webp', 12, '2025-02-11 12:38:37', '2025-02-12 02:02:50', NULL),
(43, 'MOTH-202502-BB49', 'Vaporesso BARR Kit', 'The Vaporesso BARR Pod Kit is a sleek and ultra-portable pod system designed for a smooth and flavorful MTL (Mouth-to-Lung) vaping experience. Featuring a unique adjustable airflow system, a long-lasting 350mAh battery, and a 1.2Ω mesh coil, the BARR delivers consistent performance in a stylish and compact design. With Type-C charging for quick power-ups and a leak-resistant 1.2ml pod, this device is perfect for discreet and on-the-go vaping.', 1, '400.00', 'public/uploads/img_67ac0f75144a40.89023710.webp', 50, '2025-02-12 03:03:16', '2025-02-12 03:03:16', NULL),
(44, 'MOTH-202502-31E0', 'Vaporesso GTX Coil for LUXE XR (Max)/GEN Fit 40', 'The Vaporesso GTX Coils are designed to deliver superior flavor and dense vapor production, making them an excellent choice for the LUXE XR (Max) and GEN Fit 40 devices. Available in various resistance options, these coils cater to different vaping styles, whether you prefer direct-lung (DL) or restricted direct-lung (RDL) experiences.', 5, '500.00', 'public/uploads/img_67ac12cceec402.55091542.webp', 50, '2025-02-12 03:05:58', '2025-02-12 03:17:32', NULL),
(45, 'MOTH-202502-52B6', 'Innokin Prism T22 Tank', 'The Innokin Prism T22 Tank is a high-performance mouth-to-lung (MTL) tank designed for simplicity, durability, and exceptional flavor delivery. With its robust construction and user-friendly features, this tank is perfect for both new and seasoned vapers seeking a smooth and satisfying vaping experience.', 7, '650.00', 'public/uploads/img_67ac260d9fc157.37876560.webp', 20, '2025-02-12 04:39:41', '2025-02-12 04:39:41', NULL),
(47, 'MOTH-202502-2F5F', 'Sample', '', NULL, '100.00', NULL, 0, '2025-02-12 21:13:56', '2025-02-12 05:31:11', '2025-02-12 21:31:11');

-- --------------------------------------------------------

--
-- Table structure for table `item_batches`
--

CREATE TABLE `item_batches` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `batch_sku` varchar(50) NOT NULL,
  `batch_number` varchar(50) NOT NULL,
  `quantity` int(11) DEFAULT 0,
  `expiration_date` date DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_batches`
--

INSERT INTO `item_batches` (`id`, `item_id`, `batch_sku`, `batch_number`, `quantity`, `expiration_date`, `supplier_id`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 18, 'MOTH-202502-F734-JUA', '2025-0211-B09', 50, NULL, 1, '2025-02-11 12:01:34', '2025-02-11 12:01:56', NULL),
(2, 21, 'MOTH-202502-FA32-MAR', '2025-0211-BE5', 30, NULL, 2, '2025-02-11 12:16:52', '2025-02-11 12:16:52', NULL),
(3, 3, 'MOTH-202502-D343-ANT', '2025-0211-B1D', 100, '2028-11-15', 3, '2025-02-11 12:18:08', '2025-02-11 12:18:20', NULL),
(4, 3, 'MOTH-202502-D343-JUA', '2025-0211-B97', 30, '2027-07-21', 1, '2025-02-11 12:19:32', '2025-02-11 14:40:54', NULL),
(5, 3, 'MOTH-202502-D343-JUA', '2025-0211-B98', 100, '2027-06-21', 1, '2025-02-11 12:19:32', '2025-02-11 12:35:14', NULL),
(6, 3, 'MOTH-202502-D343-JUA1', '2025-0211-BE6', 0, '2025-02-12', 7, '2025-02-11 12:26:22', '2025-02-11 12:52:34', NULL),
(7, 3, 'MOTH-202502-D343-JUA2', '2025-0211-B35', 45, '2026-05-11', 8, '2025-02-11 12:34:24', '2025-02-11 12:35:51', NULL),
(8, 1, 'MOTH-202502-9368-ANT', '2025-0211-B36', 65, '2025-09-11', 3, '2025-02-11 12:46:36', '2025-02-12 05:02:30', NULL),
(9, 2, 'MOTH-202502-6D7C-JUA', '2025-0211-B28', 70, '2025-06-11', 1, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(10, 4, 'MOTH-202502-A130-ELI', '2025-0211-B06', 27, '2025-07-11', 4, '2025-02-11 12:46:36', '2025-02-12 04:48:15', NULL),
(11, 5, 'MOTH-202502-8B9F-JUA2', '2025-0211-BA3', 30, NULL, 8, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(12, 6, 'MOTH-202502-37A1-MAR1', '2025-0211-B54', 20, NULL, 5, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(13, 7, 'MOTH-202502-6590-MAR', '2025-0211-B1C', 50, NULL, 2, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(14, 8, 'MOTH-202502-63B6-MAR1', '2025-0211-BCE', 40, NULL, 5, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(15, 9, 'MOTH-202502-871C-ELI', '2025-0211-B21', 15, NULL, 4, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(16, 10, 'MOTH-202502-6C20-JUA', '2025-0211-BBA', 45, '2025-02-19', 1, '2025-02-11 12:46:36', '2025-02-12 03:17:15', NULL),
(17, 12, 'MOTH-202502-DCEC-MAR1', '2025-0211-BCB', 40, '2025-06-11', 5, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(18, 13, 'MOTH-202502-124A-JAS', '2025-0211-B82', 60, '2025-06-11', 6, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(19, 15, 'MOTH-202502-A4A1-JUA', '2025-0211-B1A', 15, '2025-06-11', 1, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(20, 16, 'MOTH-202502-8473-JUA', '2025-0211-BAE', 20, '2025-06-27', 1, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(21, 17, 'MOTH-202502-A90A-JAS', '2025-0211-B5A', 85, '2025-08-21', 6, '2025-02-11 12:46:36', '2025-02-11 12:46:36', NULL),
(24, 1, 'MOTH-202502-9368-ANT', '2025-0211-B79', 5, '2026-06-15', 3, '2025-02-11 13:42:36', '2025-02-11 13:42:36', NULL),
(25, 2, 'MOTH-202502-6D7C-JUA2', '2025-0211-BC0', 4, '2025-05-07', 8, '2025-02-11 13:42:36', '2025-02-12 03:01:38', NULL),
(26, 3, 'MOTH-202502-D343-MAR', '2025-0211-BE9', 8, '2025-07-16', 2, '2025-02-11 13:42:36', '2025-02-12 04:37:42', NULL),
(27, 4, 'MOTH-202502-A130-ELI', '2025-0211-BB9', 21, '2025-11-02', 4, '2025-02-11 13:42:36', '2025-02-11 13:42:36', NULL),
(28, 5, 'MOTH-202502-8B9F-JAS', '2025-0211-BBD', 47, '2025-06-27', 6, '2025-02-11 13:42:36', '2025-02-12 04:52:37', NULL),
(29, 6, 'MOTH-202502-37A1-JUA', '2025-0211-BC5', 68, '2025-09-27', 1, '2025-02-11 13:42:36', '2025-02-12 05:00:35', NULL),
(30, 7, 'MOTH-202502-6590-JUA', '2025-0211-B74', 28, '2025-08-04', 1, '2025-02-11 13:42:36', '2025-02-12 05:00:35', NULL),
(31, 8, 'MOTH-202502-63B6-JUA2', '2025-0211-B26', 16, '2025-02-28', 8, '2025-02-11 13:42:36', '2025-02-12 04:52:37', NULL),
(32, 9, 'MOTH-202502-871C-MAR1', '2025-0211-B1E', 89, '2025-04-28', 5, '2025-02-11 13:42:36', '2025-02-12 05:03:04', NULL),
(33, 10, 'MOTH-202502-6C20-JAS', '2025-0211-B76', 24, '2025-09-26', 6, '2025-02-11 13:42:36', '2025-02-11 13:42:36', NULL),
(34, 11, 'MOTH-202502-8499-MAR', '2025-0211-BEA', 11, '2025-12-15', 2, '2025-02-11 13:42:36', '2025-02-12 03:17:15', NULL),
(35, 12, 'MOTH-202502-DCEC-ELI', '2025-0211-BB6', 63, '2025-04-17', 4, '2025-02-11 13:42:36', '2025-02-12 04:42:29', NULL),
(36, 13, 'MOTH-202502-124A-JAS', '2025-0211-B8D', 85, '2025-02-21', 6, '2025-02-11 13:42:36', '2025-02-12 04:48:15', NULL),
(37, 14, 'MOTH-202502-14A7-JUA2', '2025-0211-BAD', 50, '2025-04-29', 8, '2025-02-11 13:42:36', '2025-02-12 03:20:45', NULL),
(38, 15, 'MOTH-202502-A4A1-ELI', '2025-0211-BD6', 75, '2025-03-28', 4, '2025-02-11 13:42:36', '2025-02-12 04:38:07', NULL),
(39, 16, 'MOTH-202502-8473-JUA1', '2025-0211-BF0', 41, '2025-04-15', 7, '2025-02-11 13:42:36', '2025-02-12 05:02:30', NULL),
(40, 17, 'MOTH-202502-A90A-ELI', '2025-0211-BF1', 32, '2025-06-20', 4, '2025-02-11 13:42:36', '2025-02-12 04:46:29', NULL),
(41, 18, 'MOTH-202502-F734-ANT', '2025-0211-BE3', 6, '2025-10-24', 3, '2025-02-11 13:42:36', '2025-02-12 04:58:07', NULL),
(42, 19, 'MOTH-202502-C9E3-MAR', '2025-0211-B0E', 7, '2025-05-22', 2, '2025-02-11 13:42:36', '2025-02-12 02:50:55', NULL),
(43, 20, 'MOTH-202502-10C4-ELI', '2025-0211-B2F', 56, '2025-07-22', 4, '2025-02-11 13:42:36', '2025-02-12 03:04:43', NULL),
(44, 21, 'MOTH-202502-FA32-JUA1', '2025-0211-B7E', 41, '2025-06-16', 7, '2025-02-11 13:42:36', '2025-02-12 04:20:28', NULL),
(45, 22, 'MOTH-202502-BEF9-JAS', '2025-0211-BB8', 90, '2025-02-28', 6, '2025-02-11 13:42:36', '2025-02-12 02:36:29', NULL),
(46, 23, 'MOTH-202502-B23C-MAR1', '2025-0211-BE7', 46, '2025-06-24', 5, '2025-02-11 13:42:36', '2025-02-12 03:39:40', NULL),
(47, 24, 'MOTH-202502-F79C-JUA', '2025-0211-B4E', 80, '2025-11-28', 1, '2025-02-11 13:42:36', '2025-02-12 03:04:43', NULL),
(48, 25, 'MOTH-202502-5F6B-JUA2', '2025-0211-B1F', 25, '2025-06-23', 8, '2025-02-11 13:42:36', '2025-02-12 02:52:12', NULL),
(49, 26, 'MOTH-202502-FF3D-ANT', '2025-0211-B78', 68, '2025-05-21', 3, '2025-02-11 13:42:36', '2025-02-12 04:49:05', NULL),
(50, 27, 'MOTH-202502-3EBB-JUA2', '2025-0211-BF8', 6, '2025-02-28', 8, '2025-02-11 13:42:36', '2025-02-12 04:51:28', NULL),
(52, 29, 'MOTH-202502-4181-JAS', '2025-0211-BA0', 90, '2025-07-21', 6, '2025-02-11 13:42:36', '2025-02-12 04:53:41', NULL),
(57, 23, 'MOTH-202502-B23C-ANT', '2025-0212-B84', 57, NULL, 3, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(58, 39, 'MOTH-202502-A81B-ELI', '2025-0212-BC6', 80, NULL, 4, '2025-02-12 02:29:11', '2025-02-12 04:51:28', NULL),
(59, 20, 'MOTH-202502-10C4-JAS', '2025-0212-B31', 17, NULL, 6, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(60, 25, 'MOTH-202502-5F6B-JUA2', '2025-0212-B8A', 185, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(61, 24, 'MOTH-202502-F79C-JAS', '2025-0212-BF3', 21, NULL, 6, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(62, 22, 'MOTH-202502-BEF9-JUA1', '2025-0212-B2B', 186, NULL, 7, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(63, 19, 'MOTH-202502-C9E3-MAR1', '2025-0212-BA5', 145, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(64, 14, 'MOTH-202502-14A7-JUA1', '2025-0212-BDE', 85, NULL, 7, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(65, 15, 'MOTH-202502-A4A1-JAS', '2025-0212-BCD', 17, NULL, 6, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(66, 11, 'MOTH-202502-8499-ANT', '2025-0212-BB9', 196, NULL, 3, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(67, 12, 'MOTH-202502-DCEC-MAR', '2025-0212-B7A', 17, NULL, 2, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(68, 21, 'MOTH-202502-FA32-MAR1', '2025-0212-BBE', 198, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(69, 13, 'MOTH-202502-124A-JAS', '2025-0212-B30', 186, NULL, 6, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(70, 17, 'MOTH-202502-A90A-JUA', '2025-0212-BB8', 16, NULL, 1, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(71, 10, 'MOTH-202502-6C20-JUA', '2025-0212-B4F', 71, NULL, 1, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(72, 3, 'MOTH-202502-D343-JUA', '2025-0212-B64', 96, NULL, 1, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(73, 2, 'MOTH-202502-6D7C-JUA2', '2025-0212-BAD', 65, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(74, 1, 'MOTH-202502-9368-MAR1', '2025-0212-BD5', 154, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(75, 4, 'MOTH-202502-A130-JUA1', '2025-0212-B88', 78, NULL, 7, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(76, 38, 'MOTH-202502-B58C-JUA1', '2025-0212-B37', 59, NULL, 7, '2025-02-12 02:29:11', '2025-02-12 04:37:42', NULL),
(78, 6, 'MOTH-202502-37A1-MAR', '2025-0212-BE2', 71, NULL, 2, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(79, 18, 'MOTH-202502-F734-JAS', '2025-0212-B57', 81, NULL, 6, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(80, 32, 'MOTH-202502-FF7C-JUA', '2025-0212-B8B', 79, NULL, 1, '2025-02-12 02:29:11', '2025-02-12 04:55:24', NULL),
(81, 34, 'MOTH-202502-5BCC-JUA2', '2025-0212-B4A', 78, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:55:51', NULL),
(82, 40, 'MOTH-202502-A53B-MAR1', '2025-0212-B63', 28, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 04:49:51', NULL),
(83, 8, 'MOTH-202502-63B6-JUA2', '2025-0212-B97', 31, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(85, 5, 'MOTH-202502-8B9F-JUA2', '2025-0212-B82', 51, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(86, 37, 'MOTH-202502-9F6F-JUA1', '2025-0212-B95', 47, NULL, 7, '2025-02-12 02:29:11', '2025-02-12 04:46:29', NULL),
(87, 35, 'MOTH-202502-A576-JUA1', '2025-0212-B7E', 47, NULL, 7, '2025-02-12 02:29:11', '2025-02-12 04:53:41', NULL),
(88, 16, 'MOTH-202502-8473-JUA2', '2025-0212-B81', 51, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(89, 31, 'MOTH-202502-9B36-JAS', '2025-0212-BAA', 48, NULL, 6, '2025-02-12 02:29:11', '2025-02-12 03:20:01', NULL),
(90, 30, 'MOTH-202502-1865-JUA2', '2025-0212-BA6', 49, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 05:03:04', NULL),
(91, 7, 'MOTH-202502-6590-MAR1', '2025-0212-BA3', 51, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(92, 27, 'MOTH-202502-3EBB-JUA', '2025-0212-B09', 51, NULL, 1, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(93, 36, 'MOTH-202502-D97A-MAR1', '2025-0212-B2C', 46, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 04:55:24', NULL),
(94, 29, 'MOTH-202502-4181-MAR1', '2025-0212-B89', 51, NULL, 5, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(95, 26, 'MOTH-202502-FF3D-JUA2', '2025-0212-B6A', 51, NULL, 8, '2025-02-12 02:29:11', '2025-02-12 02:29:11', NULL),
(97, 43, 'MOTH-202502-BB49-MAR', '2025-0212-BDF', 95, NULL, 2, '2025-02-12 03:16:37', '2025-02-12 20:57:54', NULL),
(98, 44, 'MOTH-202502-31E0-MAR1', '2025-0212-BEA', 149, NULL, 5, '2025-02-12 03:16:37', '2025-02-12 03:22:53', NULL),
(99, 23, 'MOTH-202502-B23C-MAR', '2025-0212-B21', 200, '2026-02-12', 2, '2025-02-12 20:58:38', '2025-02-12 20:58:38', NULL),
(100, 47, 'MOTH-202502-2F5F-ANT', '2025-0212-B06', 1, '2025-02-13', 3, '2025-02-12 21:14:21', '2025-02-12 05:31:03', '2025-02-12 21:31:03'),
(101, 47, 'MOTH-202502-2F5F-ANT', '2025-0212-B93', 0, '2025-02-12', 3, '2025-02-12 21:14:21', '2025-02-12 05:31:06', '2025-02-12 21:31:06');

-- --------------------------------------------------------

--
-- Table structure for table `item_categories`
--

CREATE TABLE `item_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_categories`
--

INSERT INTO `item_categories` (`id`, `name`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 'Vape & Devices', '2025-02-11 10:59:10', '2025-02-11 10:59:10', NULL),
(2, 'E-Liquid', '2025-02-11 11:00:07', '2025-02-11 11:00:07', NULL),
(3, 'Disposables', '2025-02-11 11:00:20', '2025-02-11 11:00:20', NULL),
(4, 'D.I.Y', '2025-02-11 11:00:30', '2025-02-11 11:00:30', NULL),
(5, 'Coils & Pods', '2025-02-11 11:01:03', '2025-02-11 11:01:03', NULL),
(6, 'Accessories', '2025-02-11 11:01:53', '2025-02-11 11:01:53', NULL),
(7, 'Parts', '2025-02-11 11:02:11', '2025-02-11 11:02:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_receipt_id` int(11) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_receipt_id`, `sku`, `batch_number`, `name`, `category`, `price`, `quantity`) VALUES
(1, 1, 'MOTH-202502-D343', '2025-0211-B98', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 3),
(2, 2, 'MOTH-202502-D343', '2025-0211-BE6', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(3, 3, 'MOTH-202502-D1BA', '2025-0211-B94', 'This is a Test', 'Sample', '100.00', 100),
(4, 4, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(5, 4, 'MOTH-202502-10C4', '2025-0211-B2F', '65W PD Charger', 'Accessories', '240.97', 1),
(6, 4, 'MOTH-202502-C9E3', '2025-0211-B0E', 'Disposable AIM Plus Mythology 800', 'Disposables', '300.00', 1),
(7, 5, 'MOTH-202502-D343', '2025-0211-BE9', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(8, 6, 'MOTH-202502-C9E3', '2025-0211-B0E', 'Disposable AIM Plus Mythology 800', 'Disposables', '300.00', 1),
(9, 6, 'MOTH-202502-D343', '2025-0211-BE9', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(10, 6, 'MOTH-202502-6C20', '2025-0211-BBA', 'Disposable Vozol Star 9000', 'Disposables', '600.00', 1),
(11, 7, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(12, 7, 'MOTH-202502-A81B', '2025-0212-BC6', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'E-Liquid', '250.00', 1),
(13, 7, 'MOTH-202502-BEF9', '2025-0211-BB8', 'Bubble 100ml Shortfill 0mg (70VG/30PG)', 'E-Liquid', '700.00', 1),
(14, 8, 'MOTH-202502-08FF', '2025-0212-BCC', 'GeekVape Mini Tool Kit', 'D.I.Y', '947.36', 1),
(15, 8, 'MOTH-202502-F734', '2025-0211-BE3', 'Glass Tube For Vaporesso ITank', 'Accessories', '112.53', 1),
(16, 8, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(17, 8, 'MOTH-202502-9269', '2025-0211-BD1', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '217.11', 1),
(18, 9, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 10),
(19, 10, 'MOTH-202502-5BCC', '2025-0212-B4A', 'Lost Vape Centaurus N100 Mod Kit', 'Vape & Devices', '2300.00', 1),
(20, 10, 'MOTH-202502-9F6F', '2025-0212-B95', 'Smoant Pasito II 510 Adapter', 'Parts', '300.00', 1),
(21, 11, 'MOTH-202502-F79C', '2025-0211-B4E', 'Aspire Zero.G Mod 510 Adaptor', 'Accessories', '533.31', 1),
(22, 11, 'MOTH-202502-A4A1', '2025-0211-BD6', 'Disposable OX BAR Magic Maze 10000', 'Disposables', '750.00', 1),
(23, 12, 'MOTH-202502-A90A', '2025-0211-BF1', 'Disposable UWELL VISCORE Vi25000', 'Disposables', '900.00', 1),
(24, 12, 'MOTH-202502-6C20', '2025-0211-BBA', 'Disposable Vozol Star 9000', 'Disposables', '600.00', 1),
(25, 13, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(26, 13, 'MOTH-202502-124A', '2025-0211-B8D', 'Disposable UWELL Prime BG 12000', 'Disposables', '700.00', 1),
(27, 14, 'MOTH-202502-5F6B', '2025-0211-B1F', 'A-Steam Fruit Flavours 18MG 10ML (50VG/50PG)', 'E-Liquid', '150.00', 1),
(28, 14, 'MOTH-202502-8499', '2025-0211-BEA', 'Disposable Silicone Cap For Alpha', 'Accessories', '40.00', 1),
(29, 14, 'MOTH-202502-DCEC', '2025-0211-BB6', 'Disposable SPACEMAN SP40000 KIT', 'Disposables', '978.00', 1),
(30, 15, 'MOTH-202502-D343', '2025-0211-BE9', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(31, 15, 'MOTH-202502-6C20', '2025-0211-BBA', 'Disposable Vozol Star 9000', 'Disposables', '600.00', 1),
(32, 15, 'MOTH-202502-5BCC', '2025-0212-B4A', 'Lost Vape Centaurus N100 Mod Kit', 'Vape & Devices', '2300.00', 1),
(33, 16, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(34, 16, 'MOTH-202502-C9E3', '2025-0211-B0E', 'Disposable AIM Plus Mythology 800', 'Disposables', '300.00', 1),
(35, 16, 'MOTH-202502-14A7', '2025-0211-BAD', 'Disposable Moti Ultra Pro 8000', 'Disposables', '700.00', 1),
(36, 17, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(37, 17, 'MOTH-202502-D97A', '2025-0212-B2C', 'VOOPOO Filter Drip Tip for Doric Galaxy', 'Parts', '200.00', 1),
(38, 18, 'MOTH-202502-5F6B', '2025-0211-B1F', 'A-Steam Fruit Flavours 18MG 10ML (50VG/50PG)', 'E-Liquid', '150.00', 1),
(39, 18, 'MOTH-202502-10C4', '2025-0211-B2F', '65W PD Charger', 'Accessories', '240.97', 1),
(40, 18, 'MOTH-202502-A81B', '2025-0212-BC6', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'E-Liquid', '250.00', 1),
(41, 19, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(42, 19, 'MOTH-202502-D97A', '2025-0212-B2C', 'VOOPOO Filter Drip Tip for Doric Galaxy', 'Parts', '200.00', 1),
(43, 20, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(44, 20, 'MOTH-202502-6590', '2025-0211-B74', 'Vapefly Clouds Cotton 5ft', 'Accessories', '50.00', 1),
(45, 20, 'MOTH-202502-14A7', '2025-0211-BAD', 'Disposable Moti Ultra Pro 8000', 'Disposables', '700.00', 1),
(46, 20, 'MOTH-202502-B58C', '2025-0212-B37', 'GeekVape Max100 Kit', 'Vape & Devices', '3000.00', 1),
(47, 21, 'MOTH-202502-4181', '2025-0211-BA0', 'VOOPOO PnP Coil for Argus/Drag/Vinci Series', 'Coils & Pods', '700.00', 1),
(48, 21, 'MOTH-202502-9B36', '2025-0212-BAA', 'Uwell Nunchaku Replacement Coil 4pc', 'Coils & Pods', '500.00', 1),
(49, 21, 'MOTH-202502-5BCC', '2025-0212-B4A', 'Lost Vape Centaurus N100 Mod Kit', 'Vape & Devices', '2300.00', 1),
(50, 22, 'MOTH-202502-A53B', '2025-0212-B63', 'Lost Vape Ursa Nano Pod', 'Coils & Pods', '450.00', 1),
(51, 22, 'MOTH-202502-8B9F', '2025-0211-BBD', 'Neutral X9 Vape Tool', 'Accessories', '400.00', 1),
(52, 23, 'MOTH-202502-F79C', '2025-0211-B4E', 'Aspire Zero.G Mod 510 Adaptor', 'Accessories', '533.31', 1),
(53, 23, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(54, 23, 'MOTH-202502-D343', '2025-0211-BE9', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(55, 24, 'MOTH-202502-F734', '2025-0211-BE3', 'Glass Tube For Vaporesso ITank', 'Accessories', '112.53', 1),
(56, 24, 'MOTH-202502-A81B', '2025-0212-BC6', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'E-Liquid', '250.00', 1),
(57, 25, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(58, 25, 'MOTH-202502-14A7', '2025-0211-BAD', 'Disposable Moti Ultra Pro 8000', 'Disposables', '700.00', 1),
(59, 26, 'MOTH-202502-6D7C', '2025-0211-BC0', 'E-Liquid SHATZE TOTEM 30ml 20mg', 'E-Liquid', '200.00', 1),
(60, 26, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(61, 27, 'MOTH-202502-9B36', '2025-0212-BAA', 'Uwell Nunchaku Replacement Coil 4pc', 'Coils & Pods', '500.00', 1),
(62, 28, 'MOTH-202502-A53B', '2025-0212-B63', 'Lost Vape Ursa Nano Pod', 'Coils & Pods', '450.00', 1),
(63, 29, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(64, 29, 'MOTH-202502-6C20', '2025-0211-BBA', 'Disposable Vozol Star 9000', 'Disposables', '600.00', 1),
(65, 30, 'MOTH-202502-F734', '2025-0211-BE3', 'Glass Tube For Vaporesso ITank', 'Accessories', '112.53', 1),
(66, 30, 'MOTH-202502-3EBB', '2025-0211-BF8', 'Vaporesso XROS Pod Cartridge 3ml 4pcs', 'Coils & Pods', '600.00', 1),
(67, 31, 'MOTH-202502-10C4', '2025-0211-B2F', '65W PD Charger', 'Accessories', '240.97', 1),
(68, 31, 'MOTH-202502-F79C', '2025-0211-B4E', 'Aspire Zero.G Mod 510 Adaptor', 'Accessories', '533.31', 1),
(69, 32, 'MOTH-202502-FF3D', '2025-0211-B78', 'VOOPOO Vmate Cartridge V2', 'Coils & Pods', '400.00', 1),
(70, 32, 'MOTH-202502-1865', '2025-0212-BA6', 'Vandy Vape Pulse AIO V2 Kit DIY Accessory', 'D.I.Y', '964.48', 1),
(71, 33, 'MOTH-202502-3EBB', '2025-0211-BF8', 'Vaporesso XROS Pod Cartridge 3ml 4pcs', 'Coils & Pods', '600.00', 1),
(72, 33, 'MOTH-202502-A576', '2025-0212-B7E', 'SMOK Nord 5 Kit', 'Vape & Devices', '1500.00', 1),
(73, 34, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(74, 34, 'MOTH-202502-9F6F', '2025-0212-B95', 'Smoant Pasito II 510 Adapter', 'Parts', '300.00', 1),
(75, 35, 'MOTH-202502-124A', '2025-0211-B8D', 'Disposable UWELL Prime BG 12000', 'Disposables', '700.00', 1),
(76, 35, 'MOTH-202502-D343', '2025-0211-BE9', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(77, 36, 'MOTH-202502-A90A', '2025-0211-BF1', 'Disposable UWELL VISCORE Vi25000', 'Disposables', '900.00', 1),
(78, 36, 'MOTH-202502-9368', '2025-0211-B36', 'E-Liquid Space 30ml 20mg', 'E-Liquid', '200.00', 1),
(79, 37, 'MOTH-202502-D97A', '2025-0212-B2C', 'VOOPOO Filter Drip Tip for Doric Galaxy', 'Parts', '200.00', 1),
(80, 37, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(81, 37, 'MOTH-202502-A576', '2025-0212-B7E', 'SMOK Nord 5 Kit', 'Vape & Devices', '1500.00', 1),
(82, 38, 'MOTH-202502-9368', '2025-0211-B36', 'E-Liquid Space 30ml 20mg', 'E-Liquid', '200.00', 1),
(83, 38, 'MOTH-202502-8B9F', '2025-0211-BBD', 'Neutral X9 Vape Tool', 'Accessories', '400.00', 1),
(84, 39, 'MOTH-202502-A4A1', '2025-0211-BD6', 'Disposable OX BAR Magic Maze 10000', 'Disposables', '750.00', 1),
(85, 40, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(86, 41, 'MOTH-202502-8499', '2025-0211-BEA', 'Disposable Silicone Cap For Alpha', 'Accessories', '40.00', 1),
(87, 41, 'MOTH-202502-6C20', '2025-0211-BBA', 'Disposable Vozol Star 9000', 'Disposables', '600.00', 1),
(88, 42, 'MOTH-202502-FF3D', '2025-0211-B78', 'VOOPOO Vmate Cartridge V2', 'Coils & Pods', '400.00', 1),
(89, 42, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(90, 43, 'MOTH-202502-A130', '2025-0211-B06', 'E-Liquid USALT E-LIQUID 30ml 20mg', 'E-Liquid', '200.00', 1),
(91, 44, 'MOTH-202502-9B36', '2025-0212-BAA', 'Uwell Nunchaku Replacement Coil 4pc', 'Coils & Pods', '500.00', 1),
(92, 44, 'MOTH-202502-9F6F', '2025-0212-B95', 'Smoant Pasito II 510 Adapter', 'Parts', '300.00', 1),
(93, 44, 'MOTH-202502-8B9F', '2025-0211-BBD', 'Neutral X9 Vape Tool', 'Accessories', '400.00', 1),
(94, 45, 'MOTH-202502-FA32', '2025-0211-B7E', 'Disposable UDN H6000', 'Disposables', '600.00', 1),
(95, 45, 'MOTH-202502-14A7', '2025-0211-BAD', 'Disposable Moti Ultra Pro 8000', 'Disposables', '700.00', 1),
(96, 46, 'MOTH-202502-FF7C', '2025-0212-B8B', 'Hellvape Dead Rabbit Pro RDA DIY Combo', 'D.I.Y', '361.45', 1),
(97, 46, 'MOTH-202502-3EBB', '2025-0211-BF8', 'Vaporesso XROS Pod Cartridge 3ml 4pcs', 'Coils & Pods', '600.00', 1),
(98, 47, 'MOTH-202502-31E0', '2025-0212-BEA', 'Vaporesso GTX Coil for LUXE XR (Max)/GEN Fit 40', 'Coils & Pods', '500.00', 1),
(99, 48, 'MOTH-202502-37A1', '2025-0211-BC5', 'GeekVape Mini Tool Kit', 'Accessories', '500.00', 1),
(100, 48, 'MOTH-202502-8473', '2025-0211-BF0', 'Uwell Caliburn G3 Pod Kit', 'Coils & Pods', '868.46', 1),
(101, 49, 'MOTH-202502-F734', '2025-0211-BE3', 'Glass Tube For Vaporesso ITank', 'Accessories', '112.53', 1),
(102, 49, 'MOTH-202502-BB49', '2025-0212-BDF', 'Vaporesso BARR Kit', 'Vape & Devices', '400.00', 1),
(103, 49, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(104, 50, 'MOTH-202502-F734', '2025-0211-BE3', 'Glass Tube For Vaporesso ITank', 'Accessories', '112.53', 1),
(105, 51, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(106, 52, 'MOTH-202502-B23C', '2025-0211-BE7', '12mg Signature Vapours TPD 10ml E-Liquid ', 'E-Liquid', '50.00', 1),
(107, 53, 'MOTH-202502-FA32', '2025-0211-B7E', 'Disposable UDN H6000', 'Disposables', '600.00', 1),
(108, 54, 'MOTH-202502-A81B', '2025-0212-BC6', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'E-Liquid', '250.00', 1),
(109, 55, 'MOTH-202502-D343', '2025-0211-BE9', 'E-Liquid NEW BLAST Lemzick 30ml 20mg', 'E-Liquid', '200.00', 1),
(110, 55, 'MOTH-202502-B58C', '2025-0212-B37', 'GeekVape Max100 Kit', 'Vape & Devices', '3000.00', 1),
(111, 56, 'MOTH-202502-A81B', '2025-0212-BC6', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'E-Liquid', '250.00', 1),
(112, 56, 'MOTH-202502-DCEC', '2025-0211-BB6', 'Disposable SPACEMAN SP40000 KIT', 'Disposables', '978.00', 1),
(113, 57, 'MOTH-202502-A4A1', '2025-0211-BD6', 'Disposable OX BAR Magic Maze 10000', 'Disposables', '750.00', 1),
(114, 58, 'MOTH-202502-A130', '2025-0211-B06', 'E-Liquid USALT E-LIQUID 30ml 20mg', 'E-Liquid', '200.00', 1),
(115, 58, 'MOTH-202502-3EBB', '2025-0211-BF8', 'Vaporesso XROS Pod Cartridge 3ml 4pcs', 'Coils & Pods', '600.00', 1),
(116, 58, 'MOTH-202502-BB49', '2025-0212-BDF', 'Vaporesso BARR Kit', 'Vape & Devices', '400.00', 1),
(117, 59, 'MOTH-202502-BB49', '2025-0212-BDF', 'Vaporesso BARR Kit', 'Vape & Devices', '400.00', 1),
(118, 59, 'MOTH-202502-FF3D', '2025-0211-B78', 'VOOPOO Vmate Cartridge V2', 'Coils & Pods', '400.00', 1),
(119, 60, 'MOTH-202502-DCEC', '2025-0211-BB6', 'Disposable SPACEMAN SP40000 KIT', 'Disposables', '978.00', 2),
(120, 61, 'MOTH-202502-A90A', '2025-0211-BF1', 'Disposable UWELL VISCORE Vi25000', 'Disposables', '900.00', 1),
(121, 61, 'MOTH-202502-9368', '2025-0211-B36', 'E-Liquid Space 30ml 20mg', 'E-Liquid', '200.00', 1),
(122, 62, 'MOTH-202502-A90A', '2025-0211-BF1', 'Disposable UWELL VISCORE Vi25000', 'Disposables', '900.00', 1),
(123, 62, 'MOTH-202502-9368', '2025-0211-B36', 'E-Liquid Space 30ml 20mg', 'E-Liquid', '200.00', 1),
(124, 62, 'MOTH-202502-9F6F', '2025-0212-B95', 'Smoant Pasito II 510 Adapter', 'Parts', '300.00', 1),
(125, 63, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 2),
(126, 64, 'MOTH-202502-8473', '2025-0211-BF0', 'Uwell Caliburn G3 Pod Kit', 'Coils & Pods', '868.46', 1),
(127, 64, 'MOTH-202502-BB49', '2025-0212-BDF', 'Vaporesso BARR Kit', 'Vape & Devices', '400.00', 1),
(128, 65, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(129, 66, 'MOTH-202502-124A', '2025-0211-B8D', 'Disposable UWELL Prime BG 12000', 'Disposables', '700.00', 1),
(130, 66, 'MOTH-202502-A130', '2025-0211-B06', 'E-Liquid USALT E-LIQUID 30ml 20mg', 'E-Liquid', '200.00', 1),
(131, 67, 'MOTH-202502-A576', '2025-0212-B7E', 'SMOK Nord 5 Kit', 'Vape & Devices', '1500.00', 1),
(132, 67, 'MOTH-202502-FF3D', '2025-0211-B78', 'VOOPOO Vmate Cartridge V2', 'Coils & Pods', '400.00', 1),
(133, 68, 'MOTH-202502-A53B', '2025-0212-B63', 'Lost Vape Ursa Nano Pod', 'Coils & Pods', '450.00', 1),
(134, 68, 'MOTH-202502-D97A', '2025-0212-B2C', 'VOOPOO Filter Drip Tip for Doric Galaxy', 'Parts', '200.00', 1),
(135, 69, 'MOTH-202502-3EBB', '2025-0211-BF8', 'Vaporesso XROS Pod Cartridge 3ml 4pcs', 'Coils & Pods', '600.00', 1),
(136, 69, 'MOTH-202502-A81B', '2025-0212-BC6', '20mg Billionaire Juice Salt Series 10ml Nic Salts ', 'E-Liquid', '250.00', 1),
(137, 70, 'MOTH-202502-63B6', '2025-0211-B26', 'LTQ Vapor Stainless Steel Dab Tool', 'Accessories', '200.00', 1),
(138, 70, 'MOTH-202502-8B9F', '2025-0211-BBD', 'Neutral X9 Vape Tool', 'Accessories', '400.00', 1),
(139, 71, 'MOTH-202502-A576', '2025-0212-B7E', 'SMOK Nord 5 Kit', 'Vape & Devices', '1500.00', 1),
(140, 71, 'MOTH-202502-4181', '2025-0211-BA0', 'VOOPOO PnP Coil for Argus/Drag/Vinci Series', 'Coils & Pods', '700.00', 1),
(141, 72, 'MOTH-202502-FF7C', '2025-0212-B8B', 'Hellvape Dead Rabbit Pro RDA DIY Combo', 'D.I.Y', '361.45', 1),
(142, 72, 'MOTH-202502-D97A', '2025-0212-B2C', 'VOOPOO Filter Drip Tip for Doric Galaxy', 'Parts', '200.00', 1),
(143, 73, 'MOTH-202502-BB49', '2025-0212-BDF', 'Vaporesso BARR Kit', 'Vape & Devices', '400.00', 1),
(144, 74, 'MOTH-202502-F734', '2025-0211-BE3', 'Glass Tube For Vaporesso ITank', 'Accessories', '112.53', 1),
(145, 75, 'MOTH-202502-6590', '2025-0211-B74', 'Vapefly Clouds Cotton 5ft', 'Accessories', '50.00', 1),
(146, 75, 'MOTH-202502-37A1', '2025-0211-BC5', 'GeekVape Mini Tool Kit', 'Accessories', '500.00', 1),
(147, 76, 'MOTH-202502-8473', '2025-0211-BF0', 'Uwell Caliburn G3 Pod Kit', 'Coils & Pods', '868.46', 1),
(148, 76, 'MOTH-202502-9368', '2025-0211-B36', 'E-Liquid Space 30ml 20mg', 'E-Liquid', '200.00', 1),
(149, 77, 'MOTH-202502-1865', '2025-0212-BA6', 'Vandy Vape Pulse AIO V2 Kit DIY Accessory', 'D.I.Y', '964.48', 1),
(150, 77, 'MOTH-202502-871C', '2025-0211-B1E', 'XTAR VC2 Charger', 'Accessories', '600.00', 1),
(151, 78, 'MOTH-202502-2F5F', '2025-0212-B93', 'Sample', NULL, '100.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_receipts`
--

CREATE TABLE `order_receipts` (
  `id` int(11) NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `employee_name` varchar(255) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `payment_amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_receipts`
--

INSERT INTO `order_receipts` (`id`, `reference_number`, `customer_name`, `employee_name`, `discount`, `total_price`, `payment_method`, `payment_amount`, `created_at`, `archived_at`) VALUES
(1, 'REF-202502-7E3D', 'Zeus', 'Ceejay Salonga', 0, '600.00', 'Cash', '800.00', '2025-02-11 12:20:38', NULL),
(2, 'REF-202502-3E1E', 'Hans', 'Ceejay Salonga', 0, '200.00', 'Cash', '200.00', '2025-02-11 12:52:34', NULL),
(3, 'REF-202502-8C16', NULL, NULL, 0, '10000.00', 'Cash', '10000.00', '2025-02-11 13:50:10', NULL),
(4, 'REF-202502-E78E', NULL, 'Ceejay Salonga', 0, '590.97', 'Cash', '591.00', '2025-02-11 15:09:06', NULL),
(5, 'REF-202502-427E', 'Gelo', 'Ceejay Salonga', 0, '200.00', 'Cash', '300.00', '2025-02-12 02:32:32', NULL),
(6, 'REF-202502-F091', 'Ron', 'Ceejay Salonga', 20, '880.00', 'G-Cash', '880.00', '2025-02-12 02:36:07', NULL),
(7, 'REF-202502-77A6', 'Zeus', 'Ceejay Salonga', 20, '800.00', 'Cash', '1000.00', '2025-02-12 02:36:29', NULL),
(8, 'REF-202502-676F', NULL, 'Ceejay Salonga', 0, '1477.00', 'Cash', '1500.00', '2025-02-12 02:37:29', NULL),
(9, 'REF-202502-FF18', 'Ceejay', 'Ceejay Salonga', 0, '500.00', 'Cash', '500.00', '2025-02-12 02:37:50', NULL),
(10, 'REF-202502-6EE9', NULL, 'Ceejay Salonga', 0, '2600.00', 'Cash', '3000.00', '2025-02-12 02:45:55', NULL),
(11, 'REF-202502-7456', NULL, 'Ceejay Salonga', 0, '1283.31', 'Cash', '2000.00', '2025-02-12 02:46:06', NULL),
(12, 'REF-202502-1AE2', NULL, 'Ceejay Salonga', 0, '1500.00', 'G-Cash', '1500.00', '2025-02-12 02:46:18', NULL),
(13, 'REF-202502-0358', NULL, NULL, 0, '750.00', 'G-Cash', '1000.00', '2025-02-12 02:46:39', NULL),
(14, 'REF-202502-4081', NULL, NULL, 0, '1168.00', 'Cash', '1200.00', '2025-02-12 02:47:09', NULL),
(15, 'REF-202502-B667', NULL, NULL, 0, '3100.00', 'Cash', '3500.00', '2025-02-12 02:49:17', NULL),
(16, 'REF-202502-F2FF', 'Zeus', 'Zeus Rigo', 0, '1050.00', 'Cash', '1100.00', '2025-02-12 02:50:55', NULL),
(17, 'REF-202502-4704', NULL, 'Zeus Rigo', 0, '400.00', 'G-Cash', '500.00', '2025-02-12 02:51:30', NULL),
(18, 'REF-202502-647F', NULL, 'Zeus Rigo', 0, '640.97', 'G-Cash', '650.00', '2025-02-12 02:52:12', NULL),
(19, 'REF-202502-2E41', NULL, 'Zeus Rigo', 0, '400.00', 'Cash', '400.00', '2025-02-12 02:54:35', NULL),
(20, 'REF-202502-5DD8', NULL, 'Zeus Rigo', 0, '4350.00', 'Cash', '4500.00', '2025-02-12 02:55:14', NULL),
(21, 'REF-202502-16C6', NULL, 'Zeus Rigo', 0, '3500.00', 'G-Cash', '3500.00', '2025-02-12 02:55:51', NULL),
(22, 'REF-202502-A743', NULL, 'Zeus Rigo', 0, '850.00', 'G-Cash', '1000.00', '2025-02-12 02:56:29', NULL),
(23, 'REF-202502-50FA', NULL, 'Zeus Rigo', 0, '933.31', 'Cash', '1000.00', '2025-02-12 02:57:20', NULL),
(24, 'REF-202502-006A', NULL, 'Zeus Rigo', 0, '362.53', 'Cash', '400.00', '2025-02-12 03:00:01', NULL),
(25, 'REF-202502-A102', NULL, 'Zeus Rigo', 0, '750.00', 'G-Cash', '1000.00', '2025-02-12 03:01:13', NULL),
(26, 'REF-202502-1DB4', NULL, 'Zeus Rigo', 0, '400.00', 'Cash', '500.00', '2025-02-12 03:01:38', NULL),
(27, 'REF-202502-B574', NULL, 'Zeus Rigo', 0, '500.00', 'Cash', '500.00', '2025-02-12 03:01:53', NULL),
(28, 'REF-202502-D74A', NULL, 'Zeus Rigo', 0, '450.00', 'G-Cash', '450.00', '2025-02-12 03:02:44', NULL),
(29, 'REF-202502-5B23', NULL, 'Zeus Rigo', 0, '1200.00', 'Cash', '1200.00', '2025-02-12 03:03:38', NULL),
(30, 'REF-202502-2AEC', NULL, 'Zeus Rigo', 0, '712.53', 'Cash', '800.00', '2025-02-12 03:03:57', NULL),
(31, 'REF-202502-FEB0', NULL, 'Zeus Rigo', 0, '774.28', 'Cash', '800.00', '2025-02-12 03:04:43', NULL),
(32, 'REF-202502-B592', NULL, 'Zeus Rigo', 0, '1364.48', 'G-Cash', '1500.00', '2025-02-12 03:05:19', NULL),
(33, 'REF-202502-1CC1', NULL, 'Zeus Rigo', 0, '2100.00', 'Cash', '3000.00', '2025-02-12 03:07:44', NULL),
(34, 'REF-202502-F844', NULL, 'Zeus Rigo', 0, '500.00', 'G-Cash', '500.00', '2025-02-12 03:07:58', NULL),
(35, 'REF-202502-99ED', NULL, 'Zeus Rigo', 0, '900.00', 'G-Cash', '900.00', '2025-02-12 03:09:18', NULL),
(36, 'REF-202502-FB6D', NULL, 'Zeus Rigo', 0, '1100.00', 'G-Cash', '1100.00', '2025-02-12 03:09:38', NULL),
(37, 'REF-202502-66CE', NULL, 'Zeus Rigo', 0, '2300.00', 'Cash', '2500.00', '2025-02-12 03:13:33', NULL),
(38, 'REF-202502-E746', NULL, 'Zeus Rigo', 0, '600.00', 'G-Cash', '600.00', '2025-02-12 03:15:14', NULL),
(39, 'REF-202502-8464', NULL, 'Zeus Rigo', 0, '750.00', 'Cash', '800.00', '2025-02-12 03:15:31', NULL),
(40, 'REF-202502-9A28', NULL, 'Zeus Rigo', 0, '600.00', 'G-Cash', '600.00', '2025-02-12 03:16:16', NULL),
(41, 'REF-202502-D6D9', NULL, 'Zeus Rigo', 0, '640.00', 'Cash', '650.00', '2025-02-12 03:17:15', NULL),
(42, 'REF-202502-0EE5', NULL, 'Zeus Rigo', 0, '1000.00', 'Cash', '1000.00', '2025-02-12 03:18:35', NULL),
(43, 'REF-202502-8320', NULL, 'Zeus Rigo', 0, '200.00', 'Cash', '200.00', '2025-02-12 03:19:13', NULL),
(44, 'REF-202502-BFE5', NULL, 'Zeus Rigo', 0, '1200.00', 'G-Cash', '1200.00', '2025-02-12 03:20:01', NULL),
(45, 'REF-202502-AEE0', NULL, 'Zeus Rigo', 0, '1300.00', 'Cash', '1500.00', '2025-02-12 03:20:45', NULL),
(46, 'REF-202502-1807', NULL, 'Zeus Rigo', 0, '961.45', 'Cash', '1000.00', '2025-02-12 03:21:22', NULL),
(47, 'REF-202502-4F8C', NULL, 'Zeus Rigo', 0, '500.00', 'G-Cash', '500.00', '2025-02-12 03:22:53', NULL),
(48, 'REF-202502-3769', NULL, 'Zeus Rigo', 0, '1368.46', 'Cash', '1500.00', '2025-02-12 03:25:08', NULL),
(49, 'REF-202502-12E1', NULL, 'Zeus Rigo', 0, '1112.53', 'Cash', '1500.00', '2025-02-12 03:26:02', NULL),
(50, 'REF-202502-087B', NULL, 'Zeus Rigo', 0, '112.53', 'Cash', '1200.00', '2025-02-12 03:27:47', NULL),
(51, 'REF-202502-1C29', NULL, 'Ceejay Salonga', 0, '50.00', 'G-Cash', '50.00', '2025-02-12 03:35:03', NULL),
(52, 'REF-202502-AE99', NULL, 'Ceejay Salonga', 0, '50.00', 'Cash', '100.00', '2025-02-12 03:39:40', NULL),
(53, 'REF-202502-39A6', NULL, 'Ceejay Salonga', 0, '600.00', 'Cash', '600.00', '2025-02-12 04:20:28', NULL),
(54, 'REF-202502-ACC7', NULL, 'Ceejay Salonga', 10, '225.00', 'Cash', '250.00', '2025-02-12 20:36:09', NULL),
(55, 'REF-202502-B785', NULL, 'Ceejay Salonga', 0, '3200.00', 'Cash', '4000.00', '2025-02-12 20:37:42', NULL),
(56, 'REF-202502-3E47', NULL, 'Zeus Rigo', 0, '1228.00', 'Cash', '1500.00', '2025-02-12 20:37:51', NULL),
(57, 'REF-202502-4838', NULL, 'Zeus Rigo', 0, '750.00', 'G-Cash', '750.00', '2025-02-12 20:38:07', NULL),
(58, 'REF-202502-8E4A', NULL, 'Zeus Rigo', 0, '1200.00', 'G-Cash', '1200.00', '2025-02-12 20:38:21', NULL),
(59, 'REF-202502-0081', NULL, 'Zeus Rigo', 0, '800.00', 'Cash', '1000.00', '2025-02-12 20:41:12', NULL),
(60, 'REF-202502-774E', NULL, 'Zeus Rigo', 0, '1956.00', 'Cash', '2000.00', '2025-02-12 20:42:29', NULL),
(61, 'REF-202502-945E', NULL, 'Zeus Rigo', 0, '1100.00', 'Cash', '1100.00', '2025-02-12 20:43:29', NULL),
(62, 'REF-202502-A014', NULL, 'Zeus Rigo', 0, '1400.00', 'Cash', '1500.00', '2025-02-12 20:46:29', NULL),
(63, 'REF-202502-4C0C', NULL, 'Zeus Rigo', 0, '400.00', 'G-Cash', '400.00', '2025-02-12 20:46:48', NULL),
(64, 'REF-202502-7A83', NULL, 'Zeus Rigo', 0, '1268.46', 'Cash', '1300.00', '2025-02-12 20:47:33', NULL),
(65, 'REF-202502-B97A', NULL, 'Zeus Rigo', 0, '600.00', 'Cash', '600.00', '2025-02-12 20:48:03', NULL),
(66, 'REF-202502-40C1', NULL, 'Zeus Rigo', 0, '900.00', 'Cash', '1000.00', '2025-02-12 20:48:15', NULL),
(67, 'REF-202502-ED0E', NULL, 'Zeus Rigo', 0, '1900.00', 'Cash', '2000.00', '2025-02-12 20:49:05', NULL),
(68, 'REF-202502-424F', NULL, 'Zeus Rigo', 0, '650.00', 'G-Cash', '650.00', '2025-02-12 20:49:51', NULL),
(69, 'REF-202502-290D', NULL, 'Zeus Rigo', 0, '850.00', 'Cash', '1000.00', '2025-02-12 20:51:28', NULL),
(70, 'REF-202502-B8DB', NULL, 'Zeus Rigo', 0, '600.00', 'G-Cash', '600.00', '2025-02-12 20:52:37', NULL),
(71, 'REF-202502-AA8D', NULL, 'Zeus Rigo', 0, '2200.00', 'Cash', '2500.00', '2025-02-12 20:53:41', NULL),
(72, 'REF-202502-9C07', NULL, 'Zeus Rigo', 0, '561.45', 'Cash', '600.00', '2025-02-12 20:55:24', NULL),
(73, 'REF-202502-F381', NULL, 'Zeus Rigo', 0, '400.00', 'Cash', '400.00', '2025-02-12 20:56:25', NULL),
(74, 'REF-202502-32DB', NULL, 'Zeus Rigo', 0, '112.53', 'Cash', '150.00', '2025-02-12 20:58:07', NULL),
(75, 'REF-202502-90E9', NULL, 'Zeus Rigo', 0, '550.00', 'Cash', '550.00', '2025-02-12 21:00:35', NULL),
(76, 'REF-202502-B7C8', NULL, 'Zeus Rigo', 0, '1068.46', 'Cash', '1500.00', '2025-02-12 21:02:30', NULL),
(77, 'REF-202502-9B7E', NULL, 'Zeus Rigo', 0, '1564.48', 'Cash', '2000.00', '2025-02-12 21:03:04', NULL),
(78, 'REF-202502-C91B', NULL, 'Ceejay Salonga', 0, '100.00', 'Cash', '200.00', '2025-02-12 21:14:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 'Cash', '2025-02-11 11:26:56', '2025-02-11 11:26:56', NULL),
(2, 'G-Cash', '2025-02-11 11:27:03', '2025-02-11 11:27:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `is_admin` tinyint(4) DEFAULT NULL,
  `access_backoffice` tinyint(4) DEFAULT NULL,
  `manage_sales` tinyint(4) DEFAULT NULL,
  `manage_inventory` tinyint(4) DEFAULT NULL,
  `manage_users` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_admin`, `access_backoffice`, `manage_sales`, `manage_inventory`, `manage_users`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 'Admin', 1, 0, NULL, NULL, NULL, '2025-02-02 06:55:08', '2025-02-02 06:55:08', NULL),
(2, 'Employee', NULL, 1, 1, 0, 0, '2025-02-11 10:09:51', '2025-02-11 12:38:26', NULL),
(3, 'Supervisor', NULL, 1, 1, 1, 0, '2025-02-11 10:10:26', '2025-02-11 12:38:26', NULL),
(4, 'Manager', NULL, 1, 1, 1, 1, '2025-02-11 10:10:35', '2025-02-11 12:38:26', NULL),
(5, 'Inventory', NULL, 1, 0, 1, 0, '2025-02-11 10:24:05', '2025-02-11 12:38:26', NULL),
(6, 'User Manager', NULL, 1, 0, 0, 1, '2025-02-11 10:24:15', '2025-02-11 14:28:29', NULL),
(11, 'Cashier', NULL, 0, 0, 0, 0, '2025-02-11 14:51:20', '2025-02-11 14:51:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `supplier_code` varchar(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `street_address_line1` varchar(255) DEFAULT NULL,
  `street_address_line2` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_code`, `name`, `email`, `phone_number`, `street_address_line1`, `street_address_line2`, `city`, `state`, `postal_code`, `country`, `notes`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 'JUA', 'Juan Dela Cruz', 'juan.delacruz@juanenterprises.ph', '+63 912 345 6789', '123 Mabini Street', '', 'Quezon City', 'NCR', '1100', 'Philippines', '', '2025-02-11 10:35:35', '2025-02-11 10:35:35', NULL),
(2, 'MAR', 'Maria Santos', 'maria.santos@msantosgroup.ph', '+63 915 678 1234', '456 Rizal Avenue', '', 'Makati', 'NCR', '1210', 'Philippines', '', '2025-02-11 10:36:19', '2025-02-11 10:36:19', NULL),
(3, 'ANT', 'Antonio Reyes', 'antonio.reyes@reyeslogistics.ph', '+63 918 234 5678', '789 Katipunan Road', '', 'Pasig', 'NCR', '1600', 'Philippines', '', '2025-02-11 10:37:13', '2025-02-11 10:37:13', NULL),
(4, 'ELI', 'Elisa Mendoza', 'elisa.mendoza@mendozaco.ph', '+63 923 456 7890', '101 Bonifacio Street', 'Suite 3', 'Davao City', 'Davao del Sur', '8000', 'Philippines', '', '2025-02-11 10:37:59', '2025-02-11 10:37:59', NULL),
(5, 'MAR1', 'Marco Villanueva', 'marco.villanueva@villanuevaexports.ph', '+63 922 345 6789', '202 Quezon Boulevard', '', 'Cebu City', 'Cebu', '6000', 'Philippines', '', '2025-02-11 10:38:40', '2025-02-11 10:38:40', NULL),
(6, 'JAS', 'Jasmine Cruz', 'jasmine.cruz@cruztrading.ph', '+63 917 890 1234', '333 EDSA Extension', 'Unit 4', 'Taguig', 'NCR', '1630', 'Philippines', '', '2025-02-11 10:39:25', '2025-02-11 10:39:25', NULL),
(7, 'JUA1', 'Juan De Leon', 'juandeleon@gmail.com', '+63 123 456 7890', '', '', '', '', '', '', '', '2025-02-11 12:24:42', '2025-02-12 20:55:27', NULL),
(8, 'JUA2', 'Juan Tamad', '', '', '', '', '', '', '', '', '', '2025-02-11 12:29:35', '2025-02-11 12:29:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `archived_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role_id`, `last_login`, `created_at`, `modified_at`, `archived_at`) VALUES
(1, 'mothvapeadmin', '$2y$10$KteyJI43p//Oqa.u8Aa8B.XlutvIw.BVWDv3eMuSBssP4703E6QDW', 1, NULL, '2025-02-08 01:10:52', '2025-02-11 04:21:58', NULL),
(2, 'ceejaysalonga', '$2y$10$MV4gNP.xc2Qt7qSEePMZhONpZv4wNM8a2jIVoI4tkXQ0Fo6GrQkHy', 4, NULL, '2025-02-11 10:11:10', '2025-02-11 16:44:02', NULL),
(10, 'testtest', '$2y$10$GX1ijkD.tUpRB5IqyQ5odOVjQyBu91MsQ.QL3j8dNR9pTIFE4P8kS', 4, NULL, '2025-02-11 16:41:03', '2025-02-11 16:43:06', '2025-02-11 16:43:06'),
(11, 'zeus', '$2y$10$e0U8IHYmjOH0Zp8rOEHHXO/6wph5bCw3U9K1hzxPIRowiAq5gUG9q', 4, NULL, '2025-02-12 02:34:57', '2025-02-12 02:34:57', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk.employees.user_id` (`user_id`);

--
-- Indexes for table `employee_shifts`
--
ALTER TABLE `employee_shifts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk.employee_shifts.employee_id` (`employee_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `fk.items.item_category_id` (`category_id`);

--
-- Indexes for table `item_batches`
--
ALTER TABLE `item_batches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `batch_number` (`batch_number`),
  ADD KEY `fk.item_batches.item_id` (`item_id`),
  ADD KEY `fk.item_batches.supplier_id` (`supplier_id`);

--
-- Indexes for table `item_categories`
--
ALTER TABLE `item_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk.order_items.order_receipt_id` (`order_receipt_id`);

--
-- Indexes for table `order_receipts`
--
ALTER TABLE `order_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_number` (`reference_number`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`name`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `supplier_code` (`supplier_code`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `fk.users.role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employee_shifts`
--
ALTER TABLE `employee_shifts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `item_batches`
--
ALTER TABLE `item_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `item_categories`
--
ALTER TABLE `item_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `order_receipts`
--
ALTER TABLE `order_receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `fk.employees.user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee_shifts`
--
ALTER TABLE `employee_shifts`
  ADD CONSTRAINT `fk.employee_shifts.employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `fk.items.item_category_id` FOREIGN KEY (`category_id`) REFERENCES `item_categories` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `item_batches`
--
ALTER TABLE `item_batches`
  ADD CONSTRAINT `fk.item_batches.item_id` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `fk.item_batches.supplier_id` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk.order_items.order_receipt_id` FOREIGN KEY (`order_receipt_id`) REFERENCES `order_receipts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk.users.role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
