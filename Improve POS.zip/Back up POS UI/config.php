<?php

return [
    'database' => [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'mothvape',
        'charset' => 'utf8mb4'    
    ],
    'timezone' => 'Asia/Manila'
];