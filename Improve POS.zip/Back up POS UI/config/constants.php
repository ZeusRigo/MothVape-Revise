<?php

// BASE_PATH is already defined in public/index.php
define('PUBLIC_PATH', BASE_PATH . '/public'); 