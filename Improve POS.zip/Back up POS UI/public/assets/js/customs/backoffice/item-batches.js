let batchedItems = [];
let suppliers = [];

let rowIndexId = -1;

function addBatchedItem(itemId, sku, itemName)
{
    rowIndexId++;

    const ROW = `
        <tr class="table__row">
            <td class="table__cell">${sku}</td>
            <td class="table__cell">${itemName}</td>
            <td class="table__cell">
                <div style="display: flex; gap: 1rem;">
                    <input type="text" id="batchNumber${rowIndexId}" name="batch-number[]" class="form-control" style="flex: 1;" placeholder="Enter batch number" required>
                    <button type="button" class="btn btn-info mt-2" onclick="generateBatchNumber('batchNumber${rowIndexId}')">Generate</button>
                </div>
            </td>
            <td class="table__cell">
                <input type="number" name="quantity[]" class="form-control" style="width: 100%" placeholder="0" value="1" min="1" required>
            </td>
            <td class="table__cell">
                <input type="date" name="expiration-date[]" class="form-control" style="width: 100%">
            </td>
            <td class="table__cell">
                <select name="supplier-id[]" class="form-control" style="width: 100%" required>
                    <option value="">--- Select Supplier ---</option>
                    ${suppliers.length > 0 
                        ? suppliers.map(supplier => `<option value="${supplier.id}">${supplier.name}</option>`).join('')
                        : '<option value="">No Suppliers Available</option>'
                    }
                </select>
            </td>
            <td class="table__cell table__cell--actions">
                <button type="button" class="btn btn-danger btn-has-icon" onclick="removeBatchedItem(this)">
                    <img src="/assets/images/trash-icon.webp" alt="Trash Icon" class="btn__icon btn__icon--invert" loading="lazy">
                </button>
            </td>
        </tr>
    `;

    document.getElementById('batched-items-table').insertAdjacentHTML('beforeend', ROW);

    batchedItems.push({
        item_id: itemId,
        batch_number: '',
        sku: sku,
        item_name: itemName,
        quantity: '', 
        expiration_date: '',
        supplier_id: ''
    });
}

function removeBatchedItem(button)
{
    const ROW = button.closest('tr');
    const INDEX = [...ROW.parentNode.children].indexOf(ROW);

    batchedItems.splice(INDEX, 1);

    ROW.remove();
}

function submitBatchedItems()
{
    const ROWS = document.querySelectorAll('#batched-items-table tr');

    ROWS.forEach((row, index) => {
        const BATCH_NUMBER = row.querySelector('[name="batch-number[]"]').value
        const QUANTITY = row.querySelector('[name="quantity[]"]').value;
        const EXPIRATION_DATE = row.querySelector('[name="expiration-date[]"]').value;
        const SUPPLIER_ID = row.querySelector('[name="supplier-id[]"]').value;

        batchedItems[index].batch_number = BATCH_NUMBER;
        batchedItems[index].quantity = QUANTITY;
        batchedItems[index].expiration_date = EXPIRATION_DATE;
        batchedItems[index].supplier_id = SUPPLIER_ID;
    });

    const form = document.getElementById('_form');
    const batchedItemsInput = document.createElement('input');
    batchedItemsInput.type = 'hidden';
    batchedItemsInput.name = 'batched-items';
    batchedItemsInput.value = JSON.stringify(batchedItems);
    form.appendChild(batchedItemsInput);
}

function clearBatchedItems()
{
    batchedItems = [];

    document.getElementById('batched-items-table').innerHTML = '';
    
    rowIndexId = -1;
}

function fetchSuppliers() {
    fetch('/backoffice/inventory/item-batches/fetch-supplier')
        .then(response => response.json())
        .then(data => {
            if (data.length > 0)
            {
                suppliers = [...data];
            }
        })
        .catch(error => {
            console.error('Error fetching suppliers:', error);
        });
}

function generateBatchNumber(inputId) {
    fetch('/backoffice/inventory/item-batches/generate-batch-number', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        if (data.batch_number) 
        {
            document.getElementById(inputId).value = data.batch_number;
        } 
        else 
        {
            alert('Error generating SKU');
        }
    });
}

function filterItems(searchText) {
    const itemRows = document.querySelectorAll('.table__body .table__row');
    const searchLower = searchText.toLowerCase();

    itemRows.forEach(row => {
        const sku = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
        const name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
        
        if (sku.includes(searchLower) || name.includes(searchLower)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Fetch suppliers data when the page is ready
document.addEventListener('DOMContentLoaded', function() {
    fetchSuppliers();
});