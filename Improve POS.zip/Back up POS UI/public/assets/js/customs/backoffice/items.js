function autoGenerateSKU()
{
    fetch('/backoffice/inventory/items/generate-sku', {  // This is the route that will trigger SKU generation
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({})  // Sending an empty body for SKU generation
    })
    .then(response => response.json())
    .then(data => {
        if (data.sku) 
        {
            document.getElementById('sku').value = data.sku;  // Set the SKU input field
        } 
        else 
        {
            alert('Error generating SKU');
        }
    });
}