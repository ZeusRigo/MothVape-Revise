function openModalSingle(tableName, rowID, homeURI, modalId)
{
    const modal = document.getElementById(modalId);
    const modalItemList = modal.querySelector('#modal-item-list');
    const form = modal.querySelector('form');

    // Clear previous items
    modalItemList.innerHTML = '';

    // Add item to modal list
    const li = document.createElement('li');
    li.textContent = `Item #${rowID}`;
    modalItemList.appendChild(li);

    // Set form values
    modal.querySelector('#table-name').value = tableName;
    modal.querySelector('#row-id').value = rowID;
    modal.querySelector('#home-uri').value = homeURI;

    // Show modal
    modal.style.display = 'flex';

    // Handle form submission
    form.onsubmit = handleModalSubmit;
}

function openModalMultiple(tableName, homeUri, modalId) {
    const modal = document.getElementById(modalId);
    const selectedItems = document.querySelectorAll('.js-table__select:checked');
    const modalItemList = modal.querySelector('#modal-item-list');
    const form = modal.querySelector('form');

    // Clear previous items
    modalItemList.innerHTML = '';

    // Get selected IDs
    const selectedIds = Array.from(selectedItems).map(item => item.dataset.id);

    if (selectedIds.length === 0) {
        alert('Please select at least one item.');
        return;
    }

    // Add items to modal list
    selectedIds.forEach(id => {
        const li = document.createElement('li');
        li.textContent = `Item #${id}`;
        modalItemList.appendChild(li);
    });

    // Set form values
    modal.querySelector('#table-name').value = tableName;
    modal.querySelector('#row-id').value = selectedIds.join(',');
    modal.querySelector('#home-uri').value = homeUri;

    // Show modal
    modal.style.display = 'flex';

    // Handle form submission
    form.onsubmit = handleModalSubmit;
}

// Common form submission handler for both archive and restore
async function handleModalSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const modal = form.closest('.modal');

    try {
        const response = await fetch(form.action, {
            method: 'POST',
            body: new FormData(form)
        });

        if (response.ok) {
            // Close modal and reload page
            modal.style.display = 'none';
            window.location.reload();
        } else {
            throw new Error('Operation failed');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while processing your request.');
    }
}

function initializeModal(itemList, selectedItems)
{
    itemList.innerHTML = selectedItems.map(item => `<li>- ID: ${item.rowID}</li>`).join('');
}

function closeModal(modalId)
{
    const modal = document.getElementById(modalId);
    const modalItemList = modal.querySelector('#modal-item-list');
    const rowIdInput = modal.querySelector('#row-id');
    const tableNameInput = modal.querySelector('#table-name');

    modal.style.display = 'none';
    modalItemList.innerHTML = '';

    rowIdInput.value = null;
    tableNameInput.value = null;
}

// Close modal when clicking close button or outside
document.addEventListener('DOMContentLoaded', function() {
    const modals = document.querySelectorAll('.modal');
    
    modals.forEach(modal => {
        const closeBtn = modal.querySelector('#modal-close-btn');
        
        closeBtn.onclick = function() {
            modal.style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    });
});