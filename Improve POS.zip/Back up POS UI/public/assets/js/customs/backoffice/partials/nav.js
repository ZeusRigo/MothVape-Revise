const dateTxt = document.getElementById("date-txt");
const timeTxt = document.getElementById("time-txt");

function dateAndTimeInterval()
{
    updateDate(dateTxt);
    updateTime(timeTxt);
}

function updateDate()
{
    let currentDate = new Date();
    let day = String(currentDate.getDate()).padStart(2, '0');
    let month = String(currentDate.getMonth() + 1).padStart(2, '0');
    let year = currentDate.getFullYear();

    let formattedDate = `${month}/${day}/${year}`;

    dateTxt.innerText = formattedDate;
}

function updateTime()
{
    let currentTime = new Date()
    let hours = currentTime.getHours()
    let minutes = currentTime.getMinutes()
    let seconds = currentTime.getSeconds();

    if (hours < 10)
    {
        hours = `0${hours}`;
    }

    if (minutes < 10)
    {
        minutes = `0${minutes}`;
    }

    if (seconds < 10)
    {
        seconds = `0${seconds}`;
    }
    
    let formattedTime = `${hours}:${minutes}:${seconds} `;

    if (hours > 11)
    {
        formattedTime += "PM";
    } 
    else
    {
        formattedTime += "AM";
    }

    timeTxt.innerText = formattedTime;
}

function toggleSubmenu(button) {
    const allSubMenus = document.querySelectorAll(".sidebar__nav-submenu");
    const allButtons = document.querySelectorAll(".sidebar__nav-menu-item-btn");

    allSubMenus.forEach((menu) => {
        if (menu !== button.nextElementSibling) {
            menu.classList.remove('show');
        }
    });

    allButtons.forEach((btn) => {
        if (btn !== button) {
            btn.classList.remove('sidebar__nav-menu-item-btn--rotate');
        }
    });
    
    button.nextElementSibling.classList.toggle('show');
    button.classList.toggle('sidebar__nav-menu-item-btn--rotate');
}

function initializeSubmenus() 
{
    const allButtons = document.querySelectorAll(".sidebar__nav-menu-item-btn");

    allButtons.forEach(button => {
        const submenu = button.nextElementSibling;

        // If the submenu has the 'show' class, rotate the arrow initially
        if (submenu.classList.contains('show')) 
        {
            button.classList.add('sidebar__nav-menu-item-btn--rotate');
        }
    });
}

// Add this helper function to manage dropdowns
function closeAllSubmenus() {
    const allSubMenus = document.querySelectorAll(".sidebar__nav-submenu");
    const allButtons = document.querySelectorAll(".sidebar__nav-menu-item-btn");
    
    allSubMenus.forEach((menu) => {
        if (!menu.classList.contains('show-active')) { // Don't close active page submenu
            menu.classList.remove('show');
        }
    });

    allButtons.forEach((btn) => {
        if (!btn.nextElementSibling.classList.contains('show-active')) { // Don't remove rotation from active submenu button
            btn.classList.remove('sidebar__nav-menu-item-btn--rotate');
        }
    });
}

// Update toggleSidebar function
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const main = document.querySelector('.main');
    const mainTables = document.querySelector('.main-tables');
    const overlay = document.querySelector('.sidebar-overlay');
    const toggleBtn = document.querySelector('.topbar__toggle-btn');
    
    sidebar.classList.toggle('show');
    main.classList.toggle('shifted');
    mainTables.classList.toggle('shifted');
    overlay.classList.toggle('show');
    toggleBtn.classList.toggle('active');
    
    // Close all dropdowns except active one when opening sidebar
    if (sidebar.classList.contains('show')) {
        closeAllSubmenus();
    }
    
    // Prevent body scroll when sidebar is open
    document.body.style.overflow = sidebar.classList.contains('show') ? 'hidden' : '';
}

// Close sidebar when clicking outside
document.addEventListener('click', (e) => {
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.topbar__toggle-btn');
    
    if (!sidebar.contains(e.target) && 
        !toggleBtn.contains(e.target) && 
        sidebar.classList.contains('show')) {
        toggleSidebar();
    }
});

// Close sidebar on escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && document.querySelector('.sidebar').classList.contains('show')) {
        toggleSidebar();
    }
});

// Update handleResponsiveLayout function
function handleResponsiveLayout() {
    const sidebar = document.querySelector('.sidebar');
    
    // Only proceed if sidebar exists
    if (!sidebar) return;
    
    const main = document.querySelector('.main');
    const overlay = document.querySelector('.sidebar-overlay');
    const toggleBtn = document.querySelector('.topbar__toggle-btn');
    
    // Reset sidebar state when resizing
    sidebar.classList.remove('show');
    main.classList.remove('shifted');
    overlay.classList.remove('show');
    toggleBtn.classList.remove('active');
    document.body.style.overflow = '';
    
    // Close all dropdowns except active one
    closeAllSubmenus();
}

// Handle window resize
window.addEventListener('resize', handleResponsiveLayout);

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if we're on a page with sidebar
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        handleResponsiveLayout();
        // ... other sidebar related initializations ...
    }
});

// Initialize submenus on page load
document.addEventListener("DOMContentLoaded", () => {
    initializeSubmenus();
    dateAndTimeInterval();
    setInterval(dateAndTimeInterval, 1000);
});