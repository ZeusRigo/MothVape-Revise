function clearInputs() 
{
    document.getElementById('payment-form').reset();
    document.getElementById('change-amount').value = '₱0.00';
}

function calculateOutstandingBalance()
{
    // Get the total amount from the price breakdown section
    const totalAmountText = document.querySelector('.pos__order-ticket-section:last-of-type .txt--1p5em.txt--bold:last-child').textContent.trim();
    
    // Remove the peso sign and any commas, then parse as float
    const totalAmount = parseFloat(totalAmountText.replace('₱', '').replace(/,/g, '')) || 0;
    
    // Get payment amount and parse as float, default to 0 if invalid
    const paymentInput = document.getElementById('payment-amount');
    const cleanedPaymentInput = paymentInput.value.trim().replace(/[^0-9.]/g, '');
    const paymentAmount = parseFloat(cleanedPaymentInput) || 0;
    
    // Calculate change (payment - total)
    const change = paymentAmount - totalAmount;
    
    // Format the output with peso sign and commas
    const formattedChange = `₱${Math.max(0, change).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })}`;
    
    // Display the change amount
    document.getElementById('change-amount').value = formattedChange;

    // Enable/disable checkout button and show visual feedback
    const checkoutBtn = document.querySelector('button[type="submit"]');
    const errorMessage = document.querySelector('.form__error-message');
    
    if (paymentAmount < totalAmount) {
        checkoutBtn.disabled = true;
        paymentInput.classList.add('form__input--invalid');
        if (!errorMessage) {
            const error = document.createElement('p');
            error.className = 'form__error-message txt-danger fw-bold';
            error.textContent = 'Payment amount must be greater than or equal to the total amount';
            paymentInput.parentNode.appendChild(error);
        }
    } else {
        checkoutBtn.disabled = false;
        paymentInput.classList.remove('form__input--invalid');
        if (errorMessage) {
            errorMessage.remove();
        }
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    const paymentInput = document.getElementById('payment-amount');
    if (paymentInput) {
        paymentInput.addEventListener('input', calculateOutstandingBalance);
    }
}); 