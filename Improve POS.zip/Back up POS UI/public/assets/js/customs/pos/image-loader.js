class ImageLoader {
    constructor() {
        // Bind methods to this instance
        this.handleIntersection = this.handleIntersection.bind(this);
        this.checkImageExists = this.checkImageExists.bind(this);
        this.initializeImages = this.initializeImages.bind(this);

        // Initialize properties
        this.noImageCache = new Set();
        this.observer = new IntersectionObserver(this.handleIntersection, {
            root: null,
            rootMargin: '50px',
            threshold: 0.1
        });

        // Start observing images
        this.initializeImages();
    }

    initializeImages() {
        const images = document.querySelectorAll('.item-card__image');
        images.forEach(img => {
            const imageSrc = img.getAttribute('data-src');
            if (this.noImageCache.has(imageSrc)) {
                img.src = '/assets/images/no-image.webp';
            } else {
                this.observer.observe(img);
            }
        });
    }

    handleIntersection(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const imageSrc = img.getAttribute('data-src');
                
                if (imageSrc) {
                    this.checkImageExists(imageSrc)
                        .then(exists => {
                            if (exists) {
                                img.src = imageSrc;
                            } else {
                                this.noImageCache.add(imageSrc);
                                img.src = '/assets/images/no-image.webp';
                            }
                            img.removeAttribute('data-src');
                            this.observer.unobserve(img);
                        })
                        .catch(() => {
                            this.noImageCache.add(imageSrc);
                            img.src = '/assets/images/no-image.webp';
                            img.removeAttribute('data-src');
                            this.observer.unobserve(img);
                        });
                }
            }
        });
    }

    checkImageExists(url) {
        return new Promise((resolve, reject) => {
            if (!url) {
                resolve(false);
                return;
            }

            const img = new Image();
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
            img.src = url;
        });
    }
} 