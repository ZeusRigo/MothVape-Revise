// Constants for calculations
const VAT_RATE = 12;
const MAX_DISCOUNT = 20;
const PESO_SYMBOL = '&#x20B1;';

// Initialize state
let orderItems = [];

// DOM Elements
const elements = {
    orderPanel: document.querySelector('.pos__panel-right'),
    overlay: document.querySelector('.order-panel-overlay'),
    toggleBtn: document.querySelector('.order-panel__toggle-btn'),
    orderItemsContainer: document.getElementById('order-items-container'),
    discount: document.getElementById('discount'),
    totalPrice: document.getElementById('total-price-txt'),
    subtotal: document.getElementById('subtotal-txt'),
    discountPercentage: document.getElementById('discount-percentage-txt'),
    discountPrice: document.getElementById('discount-price-txt'),
    beforeVAT: document.getElementById('before-vat-txt'),
    afterVAT: document.getElementById('after-vat-txt'),
    clearBtn: document.getElementById('clear-btn'),
    checkoutBtn: document.getElementById('checkout-btn')
};

// Helper functions
const formatPrice = (price) => `${PESO_SYMBOL}${parseFloat(price).toFixed(2)}`;
const parsePrice = (price) => parseFloat(price) || 0;

// Helper function to sanitize price values
const sanitizePrice = (value) => {
    const number = parseFloat(value.replace(/[^\d.-]/g, ''));
    return Number(number.toFixed(2));
};

function toggleOrderPanel() {
    [elements.orderPanel, elements.overlay].forEach(el => el.classList.toggle('show'));
    elements.toggleBtn.classList.toggle('active');
}

function addItemToOrder(item) {
    try {
        const existingItem = orderItems.find(orderItem => orderItem.item_id === item.item_id);

        if (!existingItem) {
            if (item.total_quantity < 1) {
                alert('This item is out of stock.');
                return;
            }
            orderItems.push({
                ...item,
                quantity: 1,
                total_price: parsePrice(item.price)
            });
        } else {
            if (existingItem.quantity >= item.total_quantity) {
                alert('Cannot add more items. Maximum stock reached.');
                return;
            }
            existingItem.quantity += 1;
            existingItem.total_price = parsePrice(existingItem.price) * existingItem.quantity;
        }

        renderOrderItems();
        updateOrderSummary();
    } catch (error) {
        console.error('Error adding item to order:', error);
    }
}

function removeItemFromOrder(id) 
{
    try {
        const itemId = parseInt(id, 10);
        const itemIndex = orderItems.findIndex(orderItem => orderItem.item_id === itemId);

        if (itemIndex !== -1) {
            orderItems.splice(itemIndex, 1);
            renderOrderItems();
            updateOrderSummary();
        }
    } catch (error) {
        console.error('Error removing item from order:', error);
    }
}

function createOrderItemElement(item) 
{
    const itemTotalPrice = parsePrice(item.price) * item.quantity;

    const orderItemElement = document.createElement('div');
    orderItemElement.classList.add('pos__order-item');
    orderItemElement.setAttribute('data-id', item.item_id);
    
    orderItemElement.innerHTML = `
        <p class="pos__order-item-name">${item.name}</p>
        <input 
            type="number" 
            required 
            class="form-control pos__order-item-quantity" 
            value="${item.quantity}" 
            min="1" 
            max="${item.total_quantity}"
            oninput="updateItemQuantity(event, ${item.item_id})"
            onclick="event.stopPropagation()"
            onkeydown="event.stopPropagation()"
        >
        <p class="pos__order-item-price">${formatPrice(itemTotalPrice)}</p>
        <button class="btn btn-danger btn-has-icon" onclick="removeItemFromOrder(${item.item_id})">
            <img src="/assets/images/trash-icon.webp" alt="Trash Icon" 
                class="btn__icon btn__icon--invert">
        </button>
    `;

    return orderItemElement;
}

function updateItemQuantity(event, itemId) {
    event.stopPropagation();
    const input = event.target;
    const item = orderItems.find(orderItem => orderItem.item_id === itemId);
    if (!item) return;

    let value = parseInt(input.value, 10);
    
    // Ensure value is between 1 and total_quantity
    if (isNaN(value) || value < 1) {
        value = 1;
    } else if (value > item.total_quantity) {
        value = item.total_quantity;
    }
    
    // Update input value if it was changed
    input.value = value;
    
    item.quantity = value;
    item.total_price = parsePrice(item.price) * item.quantity;
    
    // Update the price display for this item
    const priceElement = input.closest('.pos__order-item').querySelector('.pos__order-item-price');
    priceElement.innerHTML = formatPrice(item.total_price);
    
    updateOrderSummary();
}

function renderOrderItems() {
    elements.orderItemsContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();
    
    orderItems.forEach(item => {
        fragment.appendChild(createOrderItemElement(item));
    });
    
    elements.orderItemsContainer.appendChild(fragment);
    updateOrderSummary();
}

function updateOrderSummary() 
{
    let discountRate = parseFloat(discount.value) || 0;

    // Ensure the discount rate is capped at 20%
    if (discountRate > 20) {
        discount.value = 20;  // Reset the input to 20% if exceeded
        discountRate = 20;  // Ensure the discount rate is set to 20%
    }

    if (discountRate < 0)
    {
        return;
    }

    let totalPriceWithVAT = 0;
    let totalPriceBeforeVAT = 0;
    let totalVAT = 0;

    let subtotal = 0;
    // Subtotal before VAT
    orderItems.forEach(item => {
        subtotal += item.price * item.quantity;
    });

    orderItems.forEach(item => {
        const priceWithVAT = parseFloat(item.price) || 0;
        totalPriceWithVAT += priceWithVAT * item.quantity;

        // Calculate price before VAT (priceWithVAT / 1.12)
        const priceBeforeVAT = priceWithVAT / 1.12;
        totalPriceBeforeVAT += priceBeforeVAT * item.quantity;

        // VAT is the difference between price with VAT and price before VAT
        const vat = priceWithVAT - priceBeforeVAT;
        totalVAT += vat * item.quantity;
    });

    const subtotalBeforeDiscount = totalPriceWithVAT;

    const discountAmount = (subtotalBeforeDiscount * discountRate) / 100;

    const subtotalVATWithDiscount = subtotalBeforeDiscount - discountAmount;

    const orderTotal = subtotalVATWithDiscount;

    // Update UI
    elements.subtotal.innerHTML = formatPrice(subtotal);
    elements.discountPercentage.innerHTML = discountRate;
    elements.discountPrice.innerHTML = discountAmount > 0 
        ? `-${formatPrice(discountAmount)}` 
        : formatPrice(0);
    elements.beforeVAT.innerHTML = formatPrice(totalPriceBeforeVAT);
    elements.afterVAT.innerHTML = formatPrice(totalVAT);
    elements.totalPrice.innerHTML = formatPrice(orderTotal);

    validateOrderConfirmation();
}

function validateOrderConfirmation() 
{
    const isValid = orderItems.length > 0;
    [elements.clearBtn, elements.checkoutBtn].forEach(btn => {
        btn.disabled = !isValid;
        btn.classList.toggle('btn--disabled', !isValid);
    });
}

function clearOrder() 
{
    orderItems = [];
    elements.orderItemsContainer.innerHTML = '';
    elements.discount.value = '0';
    
    // Reset all price displays
    [elements.subtotal, elements.discountPrice, elements.beforeVAT, 
     elements.afterVAT, elements.totalPrice].forEach(el => {
        el.innerHTML = formatPrice(0);
    });
    elements.discountPercentage.innerHTML = '0';
    
    validateOrderConfirmation();
}

function confirmOrder() {
    // Prepare order data
    const orderData = {
        items: orderItems,
        summary: {
            subtotal: parseFloat(sanitizePrice(elements.subtotal.innerHTML)),
            discountPercentage: parseFloat(elements.discountPercentage.innerHTML),
            discountAmount: Math.abs(parseFloat(sanitizePrice(elements.discountPrice.innerHTML))),
            beforeVAT: parseFloat(sanitizePrice(elements.beforeVAT.innerHTML)),
            VAT: parseFloat(sanitizePrice(elements.afterVAT.innerHTML)),
            total: parseFloat(sanitizePrice(elements.totalPrice.innerHTML))
        }
    };

    // Create a form to post the data
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/pos/checkout';

    // Create hidden input for order data
    const orderInput = document.createElement('input');
    orderInput.type = 'hidden';
    orderInput.name = 'order_data';
    orderInput.value = JSON.stringify(orderData);
    
    form.appendChild(orderInput);
    document.body.appendChild(form);
    form.submit();
}

// Event Listeners
elements.discount.addEventListener('input', (e) => {
    let value = parseInt(e.target.value, 10);
    
    // Ensure value is between 0 and MAX_DISCOUNT
    if (isNaN(value) || value < 0) {
        value = 0;
    } else if (value > MAX_DISCOUNT) {
        value = MAX_DISCOUNT;
    }
    
    // Update input value if it was changed
    e.target.value = value;
    
    updateOrderSummary();
});