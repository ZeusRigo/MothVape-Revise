function clearForm(formId) 
{
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('input, textarea, select');

    inputs.forEach(input => {
        if (input.type !== 'hidden') 
        {
            input.value = '';
            if (input.type === 'checkbox')
            {
                input.checked = false;
            }
        }
    });

    const previewImage = document.getElementById('preview-image');

    if (previewImage)
    {
        previewImage.src = '';
    }

    const existingImageInput = document.getElementById('existing-image-url');

    if (existingImageInput)
    {
        existingImageInput.value = "";
    }
}

function getCurrentTime(timeInputId)
{
    const timeInput = document.getElementById(timeInputId);

    if (timeInput) 
    {
        const currentTime = new Date(); // Get current date and time

        // Get hours and minutes in 24-hour format
        const hours = String(currentTime.getHours()).padStart(2, '0');
        const minutes = String(currentTime.getMinutes()).padStart(2, '0');
        const seconds = String(currentTime.getSeconds()).padStart(2, '0');

        // Set the value of the time input in HH:mm format
        timeInput.value = `${hours}:${minutes}:${seconds}`;
    }
}

function previewImage(event) 
{
    const fileInput = event.target;
    const previewImage = document.getElementById('preview-image');
    const existingImageInput = document.getElementById('existing-image-url');
    
    if (fileInput.files && fileInput.files[0]) 
    {
        const reader = new FileReader();
        reader.onload = function(e) 
        {
            previewImage.src = e.target.result;
        };

        reader.readAsDataURL(fileInput.files[0]);

        // Clear existing image URL when a new file is selected
        existingImageInput.value = "";
    }
}