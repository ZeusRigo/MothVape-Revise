function filterTable(searchValue, tableSelector = '.table__body tr', customFilter = null) {
    const searchTerm = searchValue.toLowerCase();
    const rows = document.querySelectorAll(tableSelector);

    rows.forEach(row => {
        if (customFilter) {
            row.style.display = customFilter(row, searchTerm) ? '' : 'none';
        } else {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        }
    });
}

// Function to handle search input
function initializeSearch(searchInputId = 'search', tableSelector = '.table__body tr', customFilter = null) {
    const searchInput = document.getElementById(searchInputId);
    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            filterTable(e.target.value, tableSelector, customFilter);
        });
    }
} 