const selectCheckboxes = document.querySelectorAll('.js-table__select');
const controlButtons = document.querySelectorAll('.js-control-btn');
const selectAllCheckbox = document.getElementById('select-all-checkbox');

function selectRow()
{
    const selectedCheckboxes = document.querySelectorAll('.js-table__select:checked');
    const isAnyChecked = selectedCheckboxes.length > 0;

    selectAllCheckbox.checked = isAnyChecked;

    toggleControls(controlButtons);
}

function selectAllRows() 
{
    selectCheckboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });

    toggleControls(controlButtons);
}

function toggleControls(buttons)
{
    const selectedCheckboxes = document.querySelectorAll('.js-table__select:checked');
    const isAnyChecked = selectedCheckboxes.length > 0;

    buttons.forEach(button => {
        button.disabled = !isAnyChecked;
        button.classList.toggle('btn--disabled', !isAnyChecked);
    });
}

// Event listener for row clicks
document.querySelectorAll('.table__row').forEach(row => {
    row.addEventListener('click', function(event) {
        const checkbox = row.querySelector('.js-table__select');
        if (event.target !== checkbox && !event.target.closest('.table__action-groups')) {
            checkbox.checked = !checkbox.checked;
            selectRow();
            toggleControls(controlButtons);
        }
    });
});

toggleControls(controlButtons);