<?php

// Authentication ////////////////////////////////////////////////////////////////////////////////////////////////////////////
$router->get('/login', 'auth/create.php')->only('guest');
$router->post('/login', 'auth/store.php')->only('guest');
$router->delete('/login', 'auth/destroy.php')->only('auth');

$router->get('/', 'auth/create.php')->only('guest');
$router->post('/', 'auth/create.php')->only('guest');
$router->delete('/', 'auth/destroy.php');

// Back Office ////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Dashboard
$router->get('/backoffice', 'backoffice/index.php')->only(['auth', 'authBackoffice']);
$router->get('/backoffice/dashboard', 'backoffice/index.php')->only(['auth', 'authBackoffice']);

// Sales ////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Sales Report
$router->get('/backoffice/sales/sales-report', 'backoffice/sales/sales-report/index.php')
    ->only(['auth', 'authBackoffice', 'authSales']);
$router->get('/backoffice/sales/sales-report/show', 'backoffice/sales/sales-report/show.php')->only('auth', 'authSales');
$router->get('/backoffice/sales/sales-report/download-pdf', 'backoffice/sales/sales-report/download-pdf.php');

// Order History
$router->get('/backoffice/sales/order-history', 'backoffice/sales/order-history/index.php')
    ->only(['auth', 'authBackoffice', 'authSales']);
$router->post('/backoffice/sales/order-history', 'backoffice/sales/order-history/store.php')->only('auth', 'authSales');
$router->get('/backoffice/sales/order-history/show', 'backoffice/sales/order-history/show.php')->only('auth', 'authSales');

// Payment Methods
$router->get('/backoffice/sales/payment-methods', 'backoffice/sales/payment-methods/index.php')->only('auth', 'authSales');
$router->post('/backoffice/sales/payment-methods', 'backoffice/sales/payment-methods/store.php')->only('auth', 'authSales');
$router->patch('/backoffice/sales/payment-methods', 'backoffice/sales/payment-methods/update.php')->only('auth', 'authSales');
$router->get('/backoffice/sales/payment-methods/add', 'backoffice/sales/payment-methods/create.php')->only('auth', 'authSales');
$router->get('/backoffice/sales/payment-methods/edit', 'backoffice/sales/payment-methods/edit.php')->only('auth', 'authSales');

// Inventory ////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Items
$router->get('/backoffice/inventory/items', 'backoffice/inventory/items/index.php')
    ->only(['auth', 'authBackoffice', 'authInventory']);
$router->post('/backoffice/inventory/items', 'backoffice/inventory/items/store.php')
    ->only(['auth', 'authBackoffice', 'authInventory']);
$router->patch('/backoffice/inventory/items', 'backoffice/inventory/items/update.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/items/add', 'backoffice/inventory/items/create.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/items/edit', 'backoffice/inventory/items/edit.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/items/show', 'backoffice/inventory/items/show.php')->only('auth', 'authInventory');
$router->post('/backoffice/inventory/items/generate-sku', 'backoffice/inventory/items/generate-sku.php')->only('auth', 'authInventory');

// Item Batches
$router->get('/backoffice/inventory/item-batches', 'backoffice/inventory/item-batches/index.php')->only('auth', 'authInventory');
$router->post('/backoffice/inventory/item-batches', 'backoffice/inventory/item-batches/store.php')->only('auth', 'authInventory');
$router->patch('/backoffice/inventory/item-batches', 'backoffice/inventory/item-batches/update.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/item-batches/add', 'backoffice/inventory/item-batches/create.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/item-batches/edit', 'backoffice/inventory/item-batches/edit.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/item-batches/show', 'backoffice/inventory/item-batches/show.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/item-batches/fetch-supplier', 'backoffice/inventory/item-batches/fetch-supplier.php')->only('auth', 'authInventory');
$router->post('/backoffice/inventory/item-batches/generate-batch-number', 'backoffice/inventory/item-batches/generate-batch-number.php')->only('auth', 'authInventory');

// Item Categories
$router->get('/backoffice/inventory/item-categories', 'backoffice/inventory/item-categories/index.php')->only('auth', 'authInventory');
$router->post('/backoffice/inventory/item-categories', 'backoffice/inventory/item-categories/store.php')->only('auth', 'authInventory');
$router->patch('/backoffice/inventory/item-categories', 'backoffice/inventory/item-categories/update.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/item-categories/add', 'backoffice/inventory/item-categories/create.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/item-categories/edit', 'backoffice/inventory/item-categories/edit.php')->only('auth', 'authInventory');

// Suppliers
$router->get('/backoffice/inventory/suppliers', 'backoffice/inventory/suppliers/index.php')->only('auth', 'authInventory');
$router->post('/backoffice/inventory/suppliers', 'backoffice/inventory/suppliers/store.php')->only('auth', 'authInventory');
$router->patch('/backoffice/inventory/suppliers', 'backoffice/inventory/suppliers/update.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/suppliers/add', 'backoffice/inventory/suppliers/create.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/suppliers/edit', 'backoffice/inventory/suppliers/edit.php')->only('auth', 'authInventory');
$router->get('/backoffice/inventory/suppliers/show', 'backoffice/inventory/suppliers/show.php')->only('auth', 'authInventory');

// Users ////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Employees
$router->get('/backoffice/users/employees', 'backoffice/users/employees/index.php')
    ->only(['auth', 'authBackoffice', 'authUsers']);
$router->post('/backoffice/users/employees', 'backoffice/users/employees/store.php')
    ->only(['auth', 'authBackoffice', 'authUsers']);
$router->patch('/backoffice/users/employees', 'backoffice/users/employees/update.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/employees/add', 'backoffice/users/employees/create.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/employees/edit', 'backoffice/users/employees/edit.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/employees/show', 'backoffice/users/employees/show.php')->only('auth', 'authUsers');

// Employee Shifts
$router->get('/backoffice/users/employee-shifts', 'backoffice/users/employee-shifts/index.php')->only('auth', 'authUsers');
$router->post('/backoffice/users/employee-shifts', 'backoffice/users/employee-shifts/store.php')->only('auth', 'authUsers');
$router->patch('/backoffice/users/employee-shifts', 'backoffice/users/employee-shifts/update.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/employee-shifts/add', 'backoffice/users/employee-shifts/create.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/employee-shifts/edit', 'backoffice/users/employee-shifts/edit.php')->only('auth', 'authUsers');

// Roles
$router->get('/backoffice/users/roles', 'backoffice/users/roles/index.php')->only('auth', 'authUsers');
$router->post('/backoffice/users/roles', 'backoffice/users/roles/store.php')->only('auth', 'authUsers');
$router->patch('/backoffice/users/roles', 'backoffice/users/roles/update.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/roles/add', 'backoffice/users/roles/create.php')->only('auth', 'authUsers');
$router->get('/backoffice/users/roles/edit', 'backoffice/users/roles/edit.php')->only('auth', 'authUsers');

// Archives ////////////////////////////////////////////////////////////////////////////////////////////////////////////
$router->post('/backoffice/archives/archive', 'backoffice/archives/archive.php')->only('auth', 'authBackoffice', 'authUsers');
$router->post('/backoffice/archives/restore', 'backoffice/archives/restore.php')->only('auth', 'authBackoffice', 'authUsers');
$router->post('/backoffice/archives/delete', 'backoffice/archives/delete.php')->only('auth', 'authBackoffice', 'authUsers');

// Employees
$router->get('/backoffice/archives/employees', 'backoffice/archives/employees.php')
    ->only(['auth', 'authBackoffice', 'authUsers']);

// Employee Shifts
$router->get('/backoffice/archives/employee-shifts', 'backoffice/archives/employee-shifts.php')->only('auth', 'authBackoffice', 'authUsers');

// Items
$router->get('/backoffice/archives/items', 'backoffice/archives/items.php')
    ->only(['auth', 'authBackoffice', 'authInventory']);

// Item Batches
$router->get('/backoffice/archives/item-batches', 'backoffice/archives/item-batches.php')->only('auth', 'authBackoffice', 'authInventory');

// Item Categories
$router->get('/backoffice/archives/item-categories', 'backoffice/archives/item-categories.php')->only('auth', 'authBackoffice', 'authInventory');

// Order History
$router->get('/backoffice/archives/order-history', 'backoffice/archives/order-history.php')->only('auth', 'authBackoffice', 'authUsers');

// Payment Methods
$router->get('/backoffice/archives/payment-methods', 'backoffice/archives/payment-methods.php')->only('auth', 'authBackoffice', 'authUsers');

// Roles
$router->get('/backoffice/archives/roles', 'backoffice/archives/roles.php')->only('auth', 'authBackoffice', 'authUsers');

// Suppliers
$router->get('/backoffice/archives/suppliers', 'backoffice/archives/suppliers.php')->only('auth', 'authBackoffice', 'authInventory');

// POS ////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Main POS routes
$router->get('/pos', 'pos/index.php')->only('auth');
$router->get('/pos/checkout', 'pos/checkout.php')->only('auth');
$router->post('/pos/checkout', 'pos/checkout.php')->only('auth');
$router->post('/pos/process-checkout', 'pos/process-checkout.php')->only('auth');

// Receipts - accessible to anyone who can access POS
$router->get('/pos/receipts', 'pos/receipts/index.php')->only('auth');
$router->get('/pos/receipts/show', 'pos/receipts/show.php')->only('auth');