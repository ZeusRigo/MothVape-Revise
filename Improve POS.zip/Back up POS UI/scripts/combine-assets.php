<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Add logging function
function logDebug($message) {
    file_put_contents(__DIR__ . '/debug.log', date('[Y-m-d H:i:s] ') . $message . "\n", FILE_APPEND);
}

// Directory containing your JS files
$jsDir = __DIR__ . '/../public/assets/js/customs/backoffice/';
$cssDir = __DIR__ . '/../public/assets/css/';

logDebug("JS Directory: " . $jsDir);
logDebug("CSS Directory: " . $cssDir);

// Output files
$combinedJsFile = __DIR__ . '/../public/assets/js/combined.min.js';
$combinedCssFile = __DIR__ . '/../public/assets/css/combined.min.css';

// Create directories if they don't exist
if (!file_exists(dirname($combinedJsFile))) {
    mkdir(dirname($combinedJsFile), 0777, true);
    logDebug("Created JS directory: " . dirname($combinedJsFile));
}
if (!file_exists(dirname($combinedCssFile))) {
    mkdir(dirname($combinedCssFile), 0777, true);
    logDebug("Created CSS directory: " . dirname($combinedCssFile));
}

// Combine JS files
$jsContent = '';
// First add utility scripts
$utilityScripts = [
    __DIR__ . '/../public/assets/js/utilities/tables.js',
    __DIR__ . '/../public/assets/js/utilities/forms.js',
    __DIR__ . '/../public/assets/js/utilities/search.js'
];

foreach ($utilityScripts as $file) {
    if (file_exists($file)) {
        $jsContent .= file_get_contents($file) . ";\n";
        logDebug("Added utility script: " . $file);
    } else {
        logDebug("Warning: Utility script not found: " . $file);
    }
}

// Then add custom scripts
foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($jsDir)) as $file) {
    if ($file->isFile() && $file->getExtension() === 'js') {
        $jsContent .= file_get_contents($file) . ";\n";
        logDebug("Added custom script: " . $file->getPathname());
    }
}

if (empty($jsContent)) {
    logDebug("Warning: No JS content was combined!");
} else {
    file_put_contents($combinedJsFile, $jsContent);
    logDebug("Combined JS file created: " . $combinedJsFile);
}

// Combine CSS files
$cssContent = '';
$mainCssFiles = glob($cssDir . '*.css');
logDebug("Found main CSS files: " . print_r($mainCssFiles, true));

foreach ($mainCssFiles as $file) {
    $cssContent .= file_get_contents($file) . "\n";
    logDebug("Added CSS file: " . $file);
}

// Add custom backoffice CSS
$backofficeCss = $cssDir . 'customs/backoffice/main.css';
if (file_exists($backofficeCss)) {
    $cssContent .= file_get_contents($backofficeCss) . "\n";
    logDebug("Added backoffice CSS: " . $backofficeCss);
} else {
    logDebug("Warning: Backoffice CSS not found: " . $backofficeCss);
}

if (empty($cssContent)) {
    logDebug("Warning: No CSS content was combined!");
} else {
    file_put_contents($combinedCssFile, $cssContent);
    logDebug("Combined CSS file created: " . $combinedCssFile);
} 